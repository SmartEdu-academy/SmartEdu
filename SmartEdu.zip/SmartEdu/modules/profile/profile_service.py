from datetime import datetime
import os
from ...data.firebase_manager import FirebaseManager
from ...data.local_db_manager import LocalDBManager
from ...utils.helpers import FileHandler
from ...constants import USER_TYPES, ERROR_MESSAGES

class ProfileService:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.local_db = LocalDBManager()
        self.file_handler = FileHandler()
        self.created_at = "2025-02-15 16:38:51"
        self.created_by = "SmartEdu-academy"
    
    async def get_profile(self, user_id):
        """Get user profile data"""
        try:
            # Try to get from local DB first
            profile = self._get_local_profile(user_id)
            
            if not profile:
                # Fetch from Firebase if not in local
                profile = await self.firebase.get_user_data(user_id)
                if profile:
                    self._store_local_profile(user_id, profile)
            
            return profile
        except Exception as e:
            print(f"Error getting profile: {str(e)}")
            raise
    
    async def update_profile(self, user_id, profile_data):
        """Update user profile"""
        try:
            # Update in Firebase
            await self.firebase.update_user_data(user_id, {
                'profile': profile_data,
                'updated_at': datetime.utcnow()
            })
            
            # Update local database
            self._update_local_profile(user_id, profile_data)
            
            return True
        except Exception as e:
            print(f"Error updating profile: {str(e)}")
            raise
    
    async def upload_profile_picture(self, user_id, image_path):
        """Upload profile picture"""
        try:
            if not self.file_handler.is_valid_file_size(os.path.getsize(image_path)):
                raise ValueError(ERROR_MESSAGES['FILE']['SIZE_EXCEEDED'])
            
            # Generate unique filename
            filename = self.file_handler.generate_filename(image_path)
            destination_path = f"profile_pictures/{user_id}/{filename}"
            
            # Upload to Firebase Storage
            image_url = await self.firebase.upload_file(
                image_path,
                destination_path
            )
            
            # Update profile with new image URL
            await self.update_profile(user_id, {'picture': image_url})
            
            return image_url
        except Exception as e:
            print(f"Error uploading profile picture: {str(e)}")
            raise
    
    async def link_student_account(self, parent_id, student_id):
        """Link student account to parent account"""
        try:
            # Verify both accounts exist
            parent_data = await self.firebase.get_user_data(parent_id)
            student_data = await self.firebase.get_user_data(student_id)
            
            if not parent_data or parent_data['user_type'] != 'parent':
                raise ValueError(ERROR_MESSAGES['AUTH']['INVALID_PARENT'])
            
            if not student_data or student_data['user_type'] != 'student':
                raise ValueError(ERROR_MESSAGES['AUTH']['INVALID_STUDENT'])
            
            # Update parent's linked students
            linked_students = parent_data.get('linked_students', [])
            if student_id not in linked_students:
                linked_students.append(student_id)
                
            await self.firebase.update_user_data(parent_id, {
                'linked_students': linked_students,
                'updated_at': datetime.utcnow()
            })
            
            # Update student's linked parent
            await self.firebase.update_user_data(student_id, {
                'linked_parent': parent_id,
                'updated_at': datetime.utcnow()
            })
            
            return True
        except Exception as e:
            print(f"Error linking accounts: {str(e)}")
            raise
    
    def _get_local_profile(self, user_id):
        """Get profile from local database"""
        query = "SELECT * FROM users WHERE id = ?"
        result = self.local_db.execute_query(query, (user_id,))
        return result[0] if result else None
    
    def _store_local_profile(self, user_id, profile_data):
        """Store profile in local database"""
        query = '''
            INSERT INTO users 
            (id, email, user_type, last_sync, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        '''
        self.local_db.execute_query(query, (
            user_id,
            profile_data['email'],
            profile_data['user_type'],
            datetime.utcnow(),
            profile_data['created_at'],
            profile_data['updated_at']
        ))
    
    def _update_local_profile(self, user_id, profile_data):
        """Update profile in local database"""
        query = '''
            UPDATE users 
            SET updated_at = ?, last_sync = ?
            WHERE id = ?
        '''
        self.local_db.execute_query(query, (
            datetime.utcnow(),
            datetime.utcnow(),
            user_id
        ))