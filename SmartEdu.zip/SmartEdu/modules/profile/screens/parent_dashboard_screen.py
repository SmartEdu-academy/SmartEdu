from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import OneLineIconListItem, TwoLineIconListItem
from ..profile_service import ProfileService
from ...auth.auth_state import AuthState

class ParentDashboardScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.profile_service = ProfileService()
        self.auth_state = AuthState()
        self.dialog = None
        self.created_at = "2025-02-15 16:58:01"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        self._load_students_data()
    
    async def _load_students_data(self):
        """Load linked students data"""
        try:
            profile = await self.profile_service.get_profile(
                self.auth_state.current_user['id']
            )
            
            if profile and profile.get('linked_students'):
                self.ids.students_container.clear_widgets()
                
                for student_id in profile['linked_students']:
                    student_data = await self.profile_service.get_profile(student_id)
                    if student_data:
                        self._add_student_widget(student_data)
                        
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _add_student_widget(self, student_data):
        """Add student widget to the container"""
        student_item = TwoLineIconListItem(
            text=student_data['profile'].get('name', 'Unknown Student'),
            secondary_text=f"Class: {student_data['profile'].get('class', 'N/A')}",
            on_release=lambda x: self.view_student_details(student_data['id'])
        )
        self.ids.students_container.add_widget(student_item)
    
    async def link_new_student(self):
        """Handle linking new student"""
        try:
            student_email = self.ids.student_email.text
            if not student_email:
                raise ValueError("Please enter student's email")
            
            await self.profile_service.link_student_account(
                self.auth_state.current_user['id'],
                student_email
            )
            
            self.show_success_dialog("Student linked successfully")
            self.ids.student_email.text = ""
            await self._load_students_data()
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def view_student_details(self, student_id):
        """Navigate to student details screen"""
        from kivy.app import App
        app = App.get_running_app()
        app.root.transition.direction = 'left'
        app.root.current = 'student_details'
        app.root.get_screen('student_details').load_student(student_id)
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def show_success_dialog(self, text):
        """Show success dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Success",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()