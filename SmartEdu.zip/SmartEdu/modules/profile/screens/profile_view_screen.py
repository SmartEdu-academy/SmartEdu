from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import OneLineIconListItem
from ..profile_service import ProfileService
from ...auth.auth_state import AuthState

class ProfileViewScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.profile_service = ProfileService()
        self.auth_state = AuthState()
        self.dialog = None
        self.created_at = "2025-02-15 16:38:51"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        self._load_profile_data()
    
    async def _load_profile_data(self):
        """Load profile data"""
        try:
            profile = await self.profile_service.get_profile(
                self.auth_state.current_user['id']
            )
            
            if profile:
                self._update_ui_with_profile(profile)
                
                if profile['user_type'] == 'parent':
                    await self._load_linked_students(profile)
                elif profile['user_type'] == 'student':
                    await self._load_parent_info(profile)
                    
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _update_ui_with_profile(self, profile):
        """Update UI with profile data"""
        self.ids.name_label.text = profile['profile'].get('name', 'N/A')
        self.ids.email_label.text = profile['email']
        self.ids.phone_label.text = profile['profile'].get('phone', 'N/A')
        self.ids.bio_label.text = profile['profile'].get('bio', 'N/A')
        
        if profile.get('profile', {}).get('picture'):
            self.ids.profile_image.source = profile['profile']['picture']
    
    async def _load_linked_students(self, profile):
        """Load linked students for parent account"""
        try:
            linked_students = profile.get('linked_students', [])
            self.ids.linked_accounts_container.clear_widgets()
            
            for student_id in linked_students:
                student_data = await self.profile_service.get_profile(student_id)
                if student_data:
                    self.ids.linked_accounts_container.add_widget(
                        OneLineIconListItem(
                            text=student_data['profile'].get('name', 'Unknown Student'),
                            on_release=lambda x, sid=student_id: self.view_student_profile(sid)
                        )
                    )
        except Exception as e:
            print(f"Error loading linked students: {str(e)}")
    
    async def _load_parent_info(self, profile):
        """Load parent info for student account"""
        try:
            parent_id = profile.get('linked_parent')
            if parent_id:
                parent_data = await self.profile_service.get_profile(parent_id)
                if parent_data:
                    self.ids.parent_name.text = parent_data['profile']
                                        self.ids.parent_name.text = parent_data['profile'].get('name', 'N/A')
                    self.ids.parent_email.text = parent_data['email']
                    self.ids.parent_phone.text = parent_data['profile'].get('phone', 'N/A')
    
    async def link_new_student(self):
        """Handle linking new student account"""
        try:
            if self.auth_state.user_type != 'parent':
                raise ValueError("Only parent accounts can link students")
            
            student_email = self.ids.student_email.text
            if not student_email:
                raise ValueError("Please enter student's email")
            
            # Find student by email
            student_data = await self.profile_service.get_user_by_email(student_email)
            if not student_data or student_data['user_type'] != 'student':
                raise ValueError("Invalid student account")
            
            # Link accounts
            await self.profile_service.link_student_account(
                self.auth_state.current_user['id'],
                student_data['id']
            )
            
            self.show_success_dialog("Student account linked successfully")
            await self._load_profile_data()  # Reload profile data
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def edit_profile(self):
        """Switch to profile edit mode"""
        self.manager.current = 'profile_edit'
    
    async def handle_student_request(self, student_id, accept=True):
        """Handle student linking request"""
        try:
            if accept:
                await self.profile_service.accept_student_request(
                    self.auth_state.current_user['id'],
                    student_id
                )
                self.show_success_dialog("Student request accepted")
            else:
                await self.profile_service.reject_student_request(
                    self.auth_state.current_user['id'],
                    student_id
                )
                self.show_success_dialog("Student request rejected")
            
            await self._load_profile_data()
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def show_success_dialog(self, text):
        """Show success dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Success",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()