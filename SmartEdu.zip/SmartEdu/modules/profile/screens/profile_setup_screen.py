from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.filemanager import MDFileManager
from ..profile_service import ProfileService
from ...auth.auth_state import AuthState

class ProfileSetupScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.profile_service = ProfileService()
        self.auth_state = AuthState()
        self.file_manager = None
        self.dialog = None
        self.created_at = "2025-02-15 16:38:51"
        self.created_by = "SmartEdu-academy"
        self._setup_file_manager()
    
    def _setup_file_manager(self):
        """Initialize file manager for image selection"""
        self.file_manager = MDFileManager(
            exit_manager=self.exit_file_manager,
            select_path=self.select_path,
            preview=True
        )
    
    def on_enter(self):
        """Called when screen is entered"""
        if self.auth_state.current_user:
            self._load_profile_data()
    
    async def _load_profile_data(self):
        """Load existing profile data"""
        try:
            profile = await self.profile_service.get_profile(
                self.auth_state.current_user['id']
            )
            if profile and profile.get('profile'):
                self.ids.name.text = profile['profile'].get('name', '')
                self.ids.phone.text = profile['profile'].get('phone', '')
                self.ids.bio.text = profile['profile'].get('bio', '')
                # Load other fields
        except Exception as e:
            self.show_error_dialog(str(e))
    
    async def save_profile(self):
        """Save profile data"""
        try:
            profile_data = {
                'name': self.ids.name.text,
                'phone': self.ids.phone.text,
                'bio': self.ids.bio.text,
                'education': self.ids.education.text if self.auth_state.user_type == 'teacher' else '',
                'setup_completed': True
            }
            
            await self.profile_service.update_profile(
                self.auth_state.current_user['id'],
                profile_data
            )
            
            self.show_success_dialog("Profile updated successfully")
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_file_manager(self):
        """Show file manager for image selection"""
        self.file_manager.show('/')
    
    def exit_file_manager(self, *args):
        """Close file manager"""
        self.file_manager.close()
    
    async def select_path(self, path):
        """Handle selected image file"""
        self.exit_file_manager()
        try:
            image_url = await self.profile_service.upload_profile_picture(
                self.auth_state.current_user['id'],
                path
            )
            self.ids.profile_image.source = image_url
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def show_success_dialog(self, text):
        """Show success dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Success",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.proceed_to_home()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def proceed_to_home(self):
        """Go to home screen after successful setup"""
        if self.dialog:
            self.dialog.dismiss()
        self.manager.current = 'home'