from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.button import MDIconButton
from ...auth.auth_state import AuthState

class ProfileMenu(MDIconButton):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.icon = "account-circle"
        self.auth_state = AuthState()
        self.menu = None
        self.created_at = "2025-02-15 16:58:01"
        self.created_by = "SmartEdu-academy"
        self._create_menu()
    
    def _create_menu(self):
        """Create dropdown menu items"""
        menu_items = [
            {
                "text": "View Profile",
                "viewclass": "OneLineIconListItem",
                "icon": "account",
                "on_release": lambda x="profile": self.menu_callback(x),
            },
            {
                "text": "Settings",
                "viewclass": "OneLineIconListItem",
                "icon": "cog",
                "on_release": lambda x="settings": self.menu_callback(x),
            },
            {
                "text": "Logout",
                "viewclass": "OneLineIconListItem",
                "icon": "logout",
                "on_release": lambda x="logout": self.menu_callback(x),
            }
        ]
        
        self.menu = MDDropdownMenu(
            caller=self,
            items=menu_items,
            width_mult=4,
        )
    
    def on_release(self):
        """Show menu on button press"""
        self.menu.open()
    
    def menu_callback(self, item_id):
        """Handle menu item selection"""
        self.menu.dismiss()
        if item_id == "profile":
            self.switch_to_profile()
        elif item_id == "settings":
            self.switch_to_settings()
        elif item_id == "logout":
            self.logout()
    
    def switch_to_profile(self):
        """Switch to profile view screen"""
        from kivy.app import App
        App.get_running_app().root.current = 'profile_view'
    
    def switch_to_settings(self):
        """Switch to settings screen"""
        from kivy.app import App
        App.get_running_app().root.current = 'settings'
    
    def logout(self):
        """Handle logout"""
        from kivy.app import App
        self.auth_state.clear_auth_state()
        App.get_running_app().root.current = 'login'