from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.tab import MDTabsBase
from kivymd.uix.floatlayout import MDFloatLayout
from ..services.resource_recommendations import ResourceRecommendations
from ...auth.auth_state import AuthState

class ResourceRecommendationsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.recommendations = ResourceRecommendations()
        self.auth_state = AuthState()
        self.dialog = None
        self.created_at = "2025-02-15 18:00:01"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        self._load_recommendations()
    
    async def _load_recommendations(self):
        """Load personalized recommendations"""
        try:
            # Get user's current topics and level
            user_data = self.auth_state.current_user
            topics = user_data.get('current_topics', [])
            level = user_data.get('level', 'beginner')
            
            resources = await self.recommendations.get_personalized_resources(
                user_data['id'],
                topics,
                level
            )
            
            self._display_recommendations(resources)
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _display_recommendations(self, resources):
        """Display recommendations in categorized tabs"""
        # Clear existing content
        for tab_id in ['video_resources', 'reading_resources', 'practice_resources', 
                      'interactive_resources']:
            if hasattr(self.ids, tab_id):
                self.ids[tab_id].clear_widgets()
        
        # Categorize resources
        for resource in resources:
            container_id = f"{resource['type']}_resources"
            if hasattr(self.ids, container_id):
                self.ids[container_id].add_widget(
                    ResourceCard(
                        title=resource['title'],
                        description=resource['description'],
                        type=resource['type'],
                        difficulty=resource['difficulty'],
                        estimated_time=resource['estimated_time'],
                        url=resource['url'],
                        on_feedback=lambda x, rid=resource['id']: 
                            self._handle_resource_feedback(rid, x)
                    )
                )
    
    async def _handle_resource_feedback(self, resource_id, feedback):
        """Handle user feedback on resources"""
        try:
            await self.recommendations.update_resource_effectiveness(
                self.auth_state.current_user['id'],
                resource_id,
                feedback
            )
            self.show_success_dialog("Thank you for your feedback!")
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def show_success_dialog(self, text):
        """Show success dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Success",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()

class Tab(MDFloatLayout, MDTabsBase):
    """Class for managing tabs"""
    pass