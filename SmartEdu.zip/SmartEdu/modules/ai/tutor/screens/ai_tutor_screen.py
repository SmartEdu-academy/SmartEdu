from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import OneLineIconListItem
from ..ai_service import AIService
from ...auth.auth_state import AuthState

class AITutorScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ai_service = AIService()
        self.auth_state = AuthState()
        self.dialog = None
        self.chat_history = []
        self.created_at = "2025-02-15 17:04:17"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        self._load_chat_history()
    
    async def _load_chat_history(self):
        """Load previous chat history"""
        try:
            # Clear current chat display
            self.ids.chat_container.clear_widgets()
            
            # Add history items
            for message in self.chat_history:
                self._add_message_to_chat(
                    message['text'],
                    message['is_user']
                )
        except Exception as e:
            self.show_error_dialog(str(e))
    
    async def send_message(self):
        """Send message to AI tutor"""
        try:
            message = self.ids.message_input.text
            if not message:
                return
            
            # Add user message to chat
            self._add_message_to_chat(message, True)
            self.chat_history.append({
                'text': message,
                'is_user': True,
                'timestamp': datetime.utcnow().isoformat()
            })
            
            # Clear input
            self.ids.message_input.text = ""
            
            # Get AI response
            response = await self.ai_service.get_personalized_tutor_response(
                self.auth_state.current_user['id'],
                message
            )
            
            # Add AI response to chat
            self._add_message_to_chat(response, False)
            self.chat_history.append({
                'text': response,
                'is_user': False,
                'timestamp': datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _add_message_to_chat(self, text, is_user):
        """Add message to chat container"""
        message_item = ChatMessage(
            text=text,
            is_user=is_user
        )
        self.ids.chat_container.add_widget(message_item)
    
    def clear_chat(self):
        """Clear chat history"""
        self.chat_history = []
        self.ids.chat_container.clear_widgets()
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()

class ChatMessage(OneLineIconListItem):
    def __init__(self, text, is_user=False, **kwargs):
        super().__init__(**kwargs)
        self.text = text
        self.is_user = is_user
        self.theme_text_color = "Primary" if is_user else "Secondary"
        self.pos_hint = {'right': 1} if is_user else {'x': 0}