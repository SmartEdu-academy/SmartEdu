from datetime import datetime
import numpy as np
from ...data.firebase_manager import FirebaseManager
from ...data.cache_manager import CacheManager

class ResourceRecommendations:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.cache = CacheManager()
        self.created_at = "2025-02-15 17:54:16"
        self.created_by = "SmartEdu-academy"
    
    async def get_personalized_resources(self, user_id, topics, difficulty_level):
        """Get personalized learning resources"""
        try:
            cache_key = f"resources_{user_id}_{hash(str(topics))}"
            cached_resources = self.cache.get(cache_key)
            
            if cached_resources:
                return cached_resources
            
            # Get user's learning history
            history = await self.firebase.get_user_learning_history(user_id)
            
            # Get available resources
            all_resources = await self.firebase.get_resources_by_topics(topics)
            
            # Apply personalization filters
            recommended = self._personalize_resources(
                all_resources,
                history,
                difficulty_level
            )
            
            # Cache results
            self.cache.set(cache_key, recommended, expires_in=3600)
            
            return recommended
            
        except Exception as e:
            print(f"Error getting resource recommendations: {str(e)}")
            raise
    
    def _personalize_resources(self, resources, history, difficulty_level):
        """Apply personalization algorithms to resources"""
        scored_resources = []
        
        for resource in resources:
            score = self._calculate_resource_score(
                resource,
                history,
                difficulty_level
            )
            scored_resources.append((score, resource))
        
        # Sort by score and get top recommendations
        scored_resources.sort(reverse=True)
        return [r[1] for r in scored_resources[:20]]
    
    def _calculate_resource_score(self, resource, history, user_level):
        """Calculate relevance score for a resource"""
        score = 0
        
        # Difficulty match
        difficulty_match = {
            'beginner': 1,
            'intermediate': 2,
            'advanced': 3
        }
        
        resource_diff = difficulty_match.get(resource['difficulty'], 2)
        user_diff = difficulty_match.get(user_level, 2)
        
        score += (1 - abs(resource_diff - user_diff) * 0.3)
        
        # Content type preference
        if history.get('preferred_content_types'):
            if resource['type'] in history['preferred_content_types']:
                score += 0.2
        
        # Learning style match
        if history.get('learning_style'):
            if resource.get('learning_style') == history['learning_style']:
                score += 0.2
        
        # Completion rate of similar resources
        if history.get('completed_resources'):
            similar_completed = [
                r for r in history['completed_resources']
                if r['type'] == resource['type']
            ]
            if similar_completed:
                avg_completion = np.mean([r['completion_rate'] for r in similar_completed])
                score += avg_completion * 0.3
        
        return score
    
    async def update_resource_effectiveness(self, user_id, resource_id, feedback):
        """Update resource effectiveness based on user feedback"""
        try:
            await self.firebase.update_resource_metrics(
                resource_id,
                {
                    'feedback': feedback,
                    'updated_at': datetime.utcnow().isoformat()
                }
            )
            
            # Clear cached recommendations
            self.cache.delete_pattern(f"resources_{user_id}_*")
            
        except Exception as e:
            print(f"Error updating resource effectiveness: {str(e)}")
            raise