from datetime import datetime
from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import TwoLineIconListItem, ThreeLineIconListItem
from kivymd.uix.card import MDCard
from ..ai_service import AIService
from ...auth.auth_state import AuthState

class StudyPlanScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ai_service = AIService()
        self.auth_state = AuthState()
        self.dialog = None
        self.plan = None
        self.created_at = "2025-02-15 17:52:24"
        self.created_by = "SmartEdu-academy"
    
    def set_plan(self, plan_data):
        """Set and display study plan data"""
        self.plan = plan_data
        self._display_plan()
        self._save_plan()
    
    async def _save_plan(self):
        """Save study plan to user's profile"""
        try:
            await self.ai_service.save_study_plan(
                self.auth_state.current_user['id'],
                self.plan
            )
        except Exception as e:
            print(f"Error saving study plan: {str(e)}")
    
    def _display_plan(self):
        """Display comprehensive study plan"""
        if not self.plan:
            return
        
        # Display daily tasks with time blocks
        self.ids.daily_tasks_container.clear_widgets()
        for task in self.plan['daily_tasks']:
            self.ids.daily_tasks_container.add_widget(
                StudyTaskCard(
                    title=task['title'],
                    duration=task['duration'],
                    priority=task['priority'],
                    description=task['description'],
                    resources=task.get('resources', []),
                    on_complete=self.mark_task_complete
                )
            )
        
        # Display weekly goals with progress tracking
        self.ids.weekly_goals_container.clear_widgets()
        for goal in self.plan['weekly_goals']:
            self.ids.weekly_goals_container.add_widget(
                WeeklyGoalCard(
                    description=goal['description'],
                    target=goal['target'],
                    current_progress=goal.get('progress', 0),
                    deadline=goal['deadline'],
                    on_update=self.update_goal_progress
                )
            )
        
        # Display recommended resources
        self.ids.resources_container.clear_widgets()
        for resource in self.plan['resources']:
            self.ids.resources_container.add_widget(
                ResourceCard(
                    title=resource['title'],
                    type=resource['type'],
                    url=resource['url'],
                    description=resource['description'],
                    difficulty=resource['difficulty'],
                    estimated_time=resource['estimated_time']
                )
            )
    
    async def mark_task_complete(self, task_id):
        """Mark a study task as complete"""
        try:
            await self.ai_service.update_task_status(
                self.auth_state.current_user['id'],
                task_id,
                'completed',
                datetime.utcnow()
            )
            self._refresh_progress()
        except Exception as e:
            self.show_error_dialog(str(e))
    
    async def update_goal_progress(self, goal_id, progress):
        """Update progress for a weekly goal"""
        try:
            await self.ai_service.update_goal_progress(
                self.auth_state.current_user['id'],
                goal_id,
                progress
            )
            self._refresh_progress()
        except Exception as e:
            self.show_error_dialog(str(e))
    
    async def _refresh_progress(self):
        """Refresh progress display"""
        try:
            updated_plan = await self.ai_service.get_study_plan(
                self.auth_state.current_user['id']
            )
            self.plan = updated_plan
            self._display_plan()
        except Exception as e:
            print(f"Error refreshing progress: {str(e)}")

class StudyTaskCard(MDCard):
    def __init__(self, title, duration, priority, description, resources, on_complete, **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.duration = duration
        self.priority = priority
        self.description = description
        self.resources = resources
        self.on_complete = on_complete
        self.orientation = 'vertical'
        self.padding = "10dp"
        self.spacing = "5dp"
        self.elevation = 2
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup task card UI"""
        # Add task details and controls
        self.add_widget(MDLabel(
            text=self.title,
            font_style="H6"
        ))
        self.add_widget(MDLabel(
            text=f"Duration: {self.duration} minutes | Priority: {self.priority}",
            theme_text_color="Secondary"
        ))
        self.add_widget(MDLabel(
            text=self.description,
            theme_text_color="Secondary"
        ))
        
        # Add resources section
        if self.resources:
            resources_box = MDBoxLayout(orientation='vertical', spacing="5dp")
            resources_box.add_widget(MDLabel(
                text="Related Resources:",
                theme_text_color="Primary"
            ))
            for resource in self.resources:
                resources_box.add_widget(MDRaisedButton(
                    text=resource['title'],
                    on_release=lambda x, url=resource['url']: self._open_resource(url)
                ))
            self.add_widget(resources_box)
        
        # Add complete button
        self.add_widget(MDRaisedButton(
            text="Mark Complete",
            on_release=lambda x: self.on_complete(self.title)
        ))
    
    def _open_resource(self, url):
        """Open resource URL"""
        import webbrowser
        webbrowser.open(url)

class WeeklyGoalCard(MDCard):
    def __init__(self, description, target, current_progress, deadline, on_update, **kwargs):
        super().__init__(**kwargs)
        self.description = description
        self.target = target
        self.current_progress = current_progress
        self.deadline = deadline
        self.on_update = on_update
        self.orientation = 'vertical'
        self.padding = "10dp"
        self.spacing = "5dp"
        self.elevation = 2
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup goal card UI"""
        self.add_widget(MDLabel(
            text=self.description,
            font_style="H6"
        ))
        self.add_widget(MDLabel(
            text=f"Target: {self.target}",
            theme_text_color="Secondary"
        ))
        self.add_widget(MDLabel(
            text=f"Deadline: {self.deadline}",
            theme_text_color="Secondary"
        ))
        
        # Add progress bar
        self.progress_bar = MDProgressBar(
            value=self.current_progress,
            max=100
        )
        self.add_widget(self.progress_bar)
        
        # Add update button
        self.add_widget(MDRaisedButton(
            text="Update Progress",
            on_release=lambda x: self._show_progress_dialog()
        ))