from datetime import datetime
import openai
import tensorflow as tf
from ...data.api_client import APIClient
from ...data.cache_manager import CacheManager

class AIService:
    def __init__(self):
        self.api_client = APIClient()
        self.cache_manager = CacheManager()
        self.created_at = "2025-02-15 17:04:17"
        self.created_by = "SmartEdu-academy"
        self._initialize_models()
    
    def _initialize_models(self):
        """Initialize AI models"""
        try:
            # Load local TensorFlow models
            self.recommendation_model = tf.keras.models.load_model('models/recommendation_model')
            self.assessment_model = tf.keras.models.load_model('models/assessment_model')
            
        except Exception as e:
            print(f"Error initializing AI models: {str(e)}")
    
    async def get_personalized_tutor_response(self, user_id, query, context=None):
        """Get AI tutor response"""
        try:
            # Check cache first
            cache_key = f"tutor_response_{user_id}_{hash(query)}"
            cached_response = self.cache_manager.get(cache_key)
            if cached_response:
                return cached_response
            
            # Get response from AI model
            response = await self.api_client.get_ai_response(
                prompt=query,
                context={
                    'user_id': user_id,
                    'user_context': context or {},
                    'timestamp': datetime.utcnow().isoformat()
                }
            )
            
            # Cache response
            self.cache_manager.set(cache_key, response, expires_in=3600)
            return response
            
        except Exception as e:
            print(f"Error getting tutor response: {str(e)}")
            raise
    
    async def generate_quiz(self, topic, difficulty, user_level):
        """Generate personalized quiz"""
        try:
            questions = await self.api_client.get_ai_response(
                prompt=f"Generate quiz for {topic}",
                context={
                    'difficulty': difficulty,
                    'user_level': user_level,
                    'timestamp': datetime.utcnow().isoformat()
                }
            )
            
            # Process and format questions
            formatted_quiz = self._format_quiz(questions)
            return formatted_quiz
            
        except Exception as e:
            print(f"Error generating quiz: {str(e)}")
            raise
    
    async def analyze_performance(self, user_id, quiz_results):
        """Analyze quiz performance and provide feedback"""
        try:
            # Process quiz results
            analysis = self.assessment_model.predict(quiz_results)
            
            # Get detailed feedback
            feedback = await self.api_client.get_ai_response(
                prompt="Generate performance feedback",
                context={
                    'user_id': user_id,
                    'results': quiz_results,
                    'analysis': analysis,
                    'timestamp': datetime.utcnow().isoformat()
                }
            )
            
            return {
                'analysis': analysis,
                'feedback': feedback,
                'recommendations': self._generate_recommendations(analysis)
            }
            
        except Exception as e:
            print(f"Error analyzing performance: {str(e)}")
            raise
    
    async def generate_study_plan(self, user_id, goals, current_level):
        """Generate personalized study plan"""
        try:
            plan = await self.api_client.get_ai_response(
                prompt="Generate study plan",
                context={
                    'user_id': user_id,
                    'goals': goals,
                    'current_level': current_level,
                    'timestamp': datetime.utcnow().isoformat()
                }
            )
            
            return self._format_study_plan(plan)
            
        except Exception as e:
            print(f"Error generating study plan: {str(e)}")
            raise
    
    def _format_quiz(self, raw_questions):
        """Format quiz questions"""
        formatted = {
            'questions': [],
            'metadata': {
                'generated_at': datetime.utcnow().isoformat(),
                'version': '1.0'
            }
        }
        
        for q in raw_questions:
            formatted['questions'].append({
                'question': q['text'],
                'options': q['options'],
                'correct_answer': q['correct'],
                'explanation': q['explanation'],
                'difficulty': q['difficulty']
            })
        
        return formatted
    
    def _generate_recommendations(self, analysis):
        """Generate learning recommendations based on analysis"""
        try:
            recommendations = self.recommendation_model.predict(analysis)
            return [
                {
                    'type': rec['type'],
                    'content': rec['content'],
                    'priority': rec['priority']
                }
                for rec in recommendations
            ]
        except Exception as e:
            print(f"Error generating recommendations: {str(e)}")
            return []
    
    def _format_study_plan(self, raw_plan):
        """Format study plan"""
        return {
            'daily_tasks': raw_plan.get('daily_tasks', []),
            'weekly_goals': raw_plan.get('weekly_goals', []),
            'resources': raw_plan.get('resources', []),
            'assessments': raw_plan.get('assessments', []),
            'generated_at': datetime.utcnow().isoformat()
        }