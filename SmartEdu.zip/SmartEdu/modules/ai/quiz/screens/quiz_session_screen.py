from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.selectioncontrol import MDCheckbox
from ..ai_service import AIService
from ...auth.auth_state import AuthState

class QuizSessionScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ai_service = AIService()
        self.auth_state = AuthState()
        self.dialog = None
        self.quiz_data = None
        self.current_question = 0
        self.user_answers = {}
        self.created_at = "2025-02-15 17:07:34"
        self.created_by = "SmartEdu-academy"
    
    def set_quiz(self, quiz_data):
        """Set quiz data and initialize session"""
        self.quiz_data = quiz_data
        self.current_question = 0
        self.user_answers = {}
        self._show_current_question()
    
    def _show_current_question(self):
        """Display current question"""
        if not self.quiz_data or not self.quiz_data['questions']:
            return
        
        question = self.quiz_data['questions'][self.current_question]
        self.ids.question_label.text = question['question']
        self.ids.options_container.clear_widgets()
        
        for idx, option in enumerate(question['options']):
            checkbox = MDCheckbox(
                group='options',
                size_hint=(None, None),
                size=("48dp", "48dp")
            )
            self.ids.options_container.add_widget(
                OptionItem(
                    text=option,
                    checkbox=checkbox,
                    on_press=lambda x, i=idx: self.select_option(i)
                )
            )
    
    def select_option(self, option_index):
        """Handle option selection"""
        self.user_answers[self.current_question] = option_index
    
    def next_question(self):
        """Move to next question"""
        if self.current_question < len(self.quiz_data['questions']) - 1:
            self.current_question += 1
            self._show_current_question()
        else:
            self.finish_quiz()
    
    def previous_question(self):
        """Move to previous question"""
        if self.current_question > 0:
            self.current_question -= 1
            self._show_current_question()
    
    async def finish_quiz(self):
        """Complete quiz and show results"""
        try:
            # Calculate results
            results = self._calculate_results()
            
            # Get AI analysis
            analysis = await self.ai_service.analyze_performance(
                self.auth_state.current_user['id'],
                results
            )
            
            # Show results screen
            results_screen = self.manager.get_screen('quiz_results')
            results_screen.set_results(results, analysis)
            self.manager.current = 'quiz_results'
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _calculate_results(self):
        """Calculate quiz results"""
        correct_answers = 0
        total_questions = len(self.quiz_data['questions'])
        question_results = []
        
        for i, question in enumerate(self.quiz_data['questions']):
            user_answer = self.user_answers.get(i)
            is_correct = user_answer == question['correct_answer']
            
            if is_correct:
                correct_answers += 1
            
            question_results.append({
                'question': question['question'],
                'user_answer': user_answer,
                'correct_answer': question['correct_answer'],
                'is_correct': is_correct,
                'explanation': question['explanation']
            })
        
        return {
            'score': (correct_answers / total_questions) * 100,
            'correct_answers': correct_answers,
            'total_questions': total_questions,
            'question_results': question_results,
            'completed_at': datetime.utcnow().isoformat()
        }
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()

class OptionItem(MDRaisedButton):
    def __init__(self, text, checkbox, **kwargs):
        super().__init__(**kwargs)
        self.text = text
        self.checkbox = checkbox
        self.add_widget(self.checkbox)