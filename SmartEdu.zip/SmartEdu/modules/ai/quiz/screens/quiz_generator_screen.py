from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.menu import MDDropdownMenu
from ..ai_service import AIService
from ...auth.auth_state import AuthState

class QuizGeneratorScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ai_service = AIService()
        self.auth_state = AuthState()
        self.dialog = None
        self.difficulty_menu = None
        self.created_at = "2025-02-15 17:07:34"
        self.created_by = "SmartEdu-academy"
        self._setup_difficulty_menu()
    
    def _setup_difficulty_menu(self):
        """Setup difficulty level dropdown menu"""
        difficulty_items = [
            {
                "text": level,
                "viewclass": "OneLineListItem",
                "on_release": lambda x=level: self.set_difficulty(x),
            }
            for level in ["Beginner", "Intermediate", "Advanced"]
        ]
        
        self.difficulty_menu = MDDropdownMenu(
            caller=self.ids.difficulty,
            items=difficulty_items,
            width_mult=4,
        )
    
    def set_difficulty(self, level):
        """Set selected difficulty level"""
        self.ids.difficulty.text = level
        self.difficulty_menu.dismiss()
    
    async def generate_quiz(self):
        """Generate quiz based on selected parameters"""
        try:
            topic = self.ids.topic.text
            difficulty = self.ids.difficulty.text.lower()
            
            if not topic or difficulty == "Select Difficulty":
                raise ValueError("Please fill in all fields")
            
            # Get user's current level
            user_level = self.auth_state.current_user.get('level', 'beginner')
            
            # Generate quiz
            quiz = await self.ai_service.generate_quiz(
                topic=topic,
                difficulty=difficulty,
                user_level=user_level
            )
            
            # Store quiz in session and switch to quiz screen
            self.manager.get_screen('quiz_session').set_quiz(quiz)
            self.manager.current = 'quiz_session'
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()