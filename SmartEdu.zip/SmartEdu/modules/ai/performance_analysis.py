from datetime import datetime
import numpy as np
from ..data.firebase_manager import FirebaseManager
from ..data.cache_manager import CacheManager

class PerformanceAnalysis:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.cache = CacheManager()
        self.created_at = "2025-02-15 18:24:30"
        self.created_by = "SmartEdu-academy"
    
    async def analyze_quiz_performance(self, user_id, quiz_result):
        """Analyze quiz performance and provide detailed insights"""
        try:
            # Get user's learning history
            history = await self.firebase.get_user_learning_history(user_id)
            
            analysis = {
                'score_analysis': self._analyze_score(quiz_result),
                'topic_mastery': self._analyze_topic_mastery(quiz_result, history),
                'time_analysis': self._analyze_time_management(quiz_result),
                'misconceptions': self._identify_misconceptions(quiz_result),
                'recommendations': await self._generate_recommendations(quiz_result, history),
                'improvement_areas': self._identify_improvement_areas(quiz_result),
                'progress_indicators': self._calculate_progress_indicators(quiz_result, history),
                'generated_at': datetime.utcnow().isoformat()
            }
            
            # Cache analysis results
            cache_key = f"quiz_analysis_{user_id}_{quiz_result['quiz_id']}"
            self.cache.set(cache_key, analysis, expires_in=3600)
            
            return analysis
            
        except Exception as e:
            print(f"Error analyzing quiz performance: {str(e)}")
            raise
    
    def _analyze_score(self, quiz_result):
        """Analyze quiz score and provide detailed breakdown"""
        total_questions = len(quiz_result['questions'])
        correct_answers = sum(1 for q in quiz_result['questions'] if q['is_correct'])
        
        return {
            'total_score': (correct_answers / total_questions) * 100,
            'correct_answers': correct_answers,
            'total_questions': total_questions,
            'score_breakdown': {
                'easy_questions': self._analyze_difficulty_level(quiz_result, 'easy'),
                'medium_questions': self._analyze_difficulty_level(quiz_result, 'medium'),
                'hard_questions': self._analyze_difficulty_level(quiz_result, 'hard')
            },
            'performance_level': self._determine_performance_level(correct_answers / total_questions)
        }
    
    def _analyze_difficulty_level(self, quiz_result, difficulty):
        """Analyze performance for specific difficulty level"""
        questions = [q for q in quiz_result['questions'] if q['difficulty'] == difficulty]
        if not questions:
            return {'attempted': 0, 'correct': 0, 'accuracy': 0}
        
        correct = sum(1 for q in questions if q['is_correct'])
        return {
            'attempted': len(questions),
            'correct': correct,
            'accuracy': (correct / len(questions)) * 100
        }
    
    def _analyze_topic_mastery(self, quiz_result, history):
        """Analyze mastery level for each topic"""
        topic_results = {}
        
        for question in quiz_result['questions']:
            topic = question['topic']
            if topic not in topic_results:
                topic_results[topic] = {'correct': 0, 'total': 0, 'history': []}
            
            topic_results[topic]['total'] += 1
            if question['is_correct']:
                topic_results[topic]['correct'] += 1
            
            # Include historical performance
            if history and 'topic_performance' in history:
                topic_results[topic]['history'] = history['topic_performance'].get(topic, [])
        
        return {
            topic: {
                'current_mastery': (data['correct'] / data['total']) * 100,
                'historical_trend': self._calculate_trend(data['history']),
                'mastery_level': self._determine_mastery_level(data['correct'] / data['total'])
            }
            for topic, data in topic_results.items()
        }
    
    def _analyze_time_management(self, quiz_result):
        """Analyze time management during quiz"""
        return {
            'total_time': quiz_result['total_time'],
            'average_time_per_question': quiz_result['total_time'] / len(quiz_result['questions']),
            'time_distribution': self._analyze_time_distribution(quiz_result['questions']),
            'efficiency_score': self._calculate_efficiency_score(quiz_result)
        }
    
    def _identify_misconceptions(self, quiz_result):
        """Identify potential misconceptions from incorrect answers"""
        misconceptions = []
        
        for question in quiz_result['questions']:
            if not question['is_correct']:
                misconceptions.append({
                    'topic': question['topic'],
                    'concept': question['concept'],
                    'mistake_pattern': self._analyze_mistake_pattern(question),
                    'correct_concept': question['explanation'],
                    'remediation': self._generate_remediation(question)
                })
        
        return misconceptions
    
    async def _generate_recommendations(self, quiz_result, history):
        """Generate personalized learning recommendations"""
        weak_areas = self._identify_improvement_areas(quiz_result)
        
        recommendations = {
            'study_focus': [
                {
                    'topic': area['topic'],
                    'resources': await self._find_relevant_resources(area['topic']),
                    'practice_exercises': await self._generate_practice_exercises(area['topic']),
                    'priority_level': area['priority']
                }
                for area in weak_areas
            ],
            'learning_strategies': self._suggest_learning_strategies(quiz_result, history),
            'next_steps': self._determine_next_steps(quiz_result)
        }
        
        return recommendations
    
    def _identify_improvement_areas(self, quiz_result):
        """Identify areas needing improvement"""
        topic_performance = {}
        
        for question in quiz_result['questions']:
            topic = question['topic']
            if topic not in topic_performance:
                topic_performance[topic] = {'correct': 0, 'total': 0}
            
            topic_performance[topic]['total'] += 1
            if question['is_correct']:
                topic_performance[topic]['correct'] += 1
        
        improvement_areas = []
        for topic, data in topic_performance.items():
            accuracy = (data['correct'] / data['total']) * 100
            if accuracy < 70:
                improvement_areas.append({
                    'topic': topic,
                    'accuracy': accuracy,
                    'priority': self._calculate_priority(accuracy, data['total']),
                    'suggested_focus': self._suggest_focus_areas(topic, accuracy)
                })
        
        return sorted(improvement_areas, key=lambda x: x['priority'], reverse=True)
    
    def _calculate_progress_indicators(self, quiz_result, history):
        """Calculate various progress indicators"""
        return {
            'overall_progress': self._calculate_overall_progress(quiz_result, history),
            'topic_progress': self._calculate_topic_progress(quiz_result, history),
            'skill_development': self._analyze_skill_development(quiz_result, history),
            'learning_velocity': self._calculate_learning_velocity(history)
        }
    
    def _determine_performance_level(self, accuracy):
        """Determine performance level based on accuracy"""
        if accuracy >= 0.9:
            return "Outstanding"
        elif accuracy >= 0.8:
            return "Excellent"
        elif accuracy >= 0.7:
            return "Good"
        elif accuracy >= 0.6:
            return "Fair"
        else:
            return "Needs Improvement"
    
    def _determine_mastery_level(self, accuracy):
        """Determine mastery level"""
        if accuracy >= 0.9:
            return "Master"
        elif accuracy >= 0.8:
            return "Expert"
        elif accuracy >= 0.7:
            return "Proficient"
        elif accuracy >= 0.6:
            return "Developing"
        else:
            return "Beginner"
    
    def _calculate_trend(self, history):
        """Calculate performance trend from history"""
        if not history:
            return "Not enough data"
        
        scores = [h['score'] for h in history]
        if len(scores) < 2:
            return "Stable"
        
        trend = np.polyfit(range(len(scores)), scores, 1)[0]
        if trend > 0.05:
            return "Improving"
        elif trend < -0.05:
            return "Declining"
        else:
            return "Stable"