from functools import wraps
from kivy.clock import Clock
from .auth_state import AuthState

class AuthMiddleware:
    def __init__(self):
        self.auth_state = AuthState()
        self.created_at = "2025-02-15 05:27:50"
        self.created_by = "SmartEdu-academy"
    
    def require_auth(self, func):
        """Decorator to require authentication"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not self.auth_state.is_authenticated:
                Clock.schedule_once(lambda dt: self.redirect_to_login())
                return
            return func(*args, **kwargs)
        return wrapper
    
    def require_user_type(self, allowed_types):
        """Decorator to require specific user type"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                if not self.auth_state.is_authenticated:
                    Clock.schedule_once(lambda dt: self.redirect_to_login())
                    return
                if self.auth_state.user_type not in allowed_types:
                    Clock.schedule_once(lambda dt: self.show_unauthorized())
                    return
                return func(*args, **kwargs)
            return wrapper
        return decorator
    
    def redirect_to_login(self):
        """Redirect to login screen"""
        from kivy.app import App
        App.get_running_app().root.current = 'login'
    
    def show_unauthorized(self):
        """Show unauthorized access dialog"""
        from kivymd.uix.dialog import MDDialog
        from kivymd.uix.button import MDFlatButton
        
        dialog = MDDialog(
            title="Unauthorized",
            text="You don't have permission to access this feature",
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()