from datetime import datetime
import re
from ...data.firebase_manager import FirebaseManager
from ...data.local_db_manager import LocalDBManager
from ...utils.helpers import Security, IDGenerator
from ...constants import USER_TYPES, ERROR_MESSAGES

class AuthService:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.local_db = LocalDBManager()
        self.security = Security()
        self.id_generator = IDGenerator()
        self.created_at = "2025-02-15 05:26:18"
        self.created_by = "SmartEdu-academy"
    
    async def register_user(self, email, password, user_type, profile_data):
        """Register a new user"""
        try:
            # Validate email format
            if not self._validate_email(email):
                raise ValueError(ERROR_MESSAGES['AUTH']['INVALID_EMAIL'])
            
            # Validate password strength
            if not self._validate_password(password):
                raise ValueError(ERROR_MESSAGES['AUTH']['WEAK_PASSWORD'])
            
            # Generate unique user ID
            user_id = self.id_generator.generate_user_id(user_type)
            
            # Prepare user data
            user_data = {
                'email': email,
                'user_type': user_type,
                'profile': profile_data,
                'created_at': datetime.utcnow(),
                'status': 'active',
                'email_verified': False,
                'account_type': self._get_account_type(user_type)
            }
            
            # Create user in Firebase
            await self.firebase.create_user(email, password, user_data)
            
            # Store user in local database
            self._store_local_user(user_id, user_data)
            
            return user_id
            
        except Exception as e:
            print(f"Registration error: {str(e)}")
            raise
    
    async def login(self, email, password):
        """Login user with email and password"""
        try:
            # Authenticate with Firebase
            user = await self.firebase.sign_in_with_email_password(email, password)
            
            if not user:
                raise ValueError(ERROR_MESSAGES['AUTH']['INVALID_CREDENTIALS'])
            
            # Get user data
            user_data = await self.firebase.get_user_data(user['localId'])
            
            if user_data.get('status') != 'active':
                raise ValueError(ERROR_MESSAGES['AUTH']['ACCOUNT_INACTIVE'])
            
            # Update last login
            await self.firebase.update_user_data(user['localId'], {
                'last_login': datetime.utcnow()
            })
            
            return user_data
            
        except Exception as e:
            print(f"Login error: {str(e)}")
            raise
    
    async def reset_password(self, email):
        """Send password reset email"""
        try:
            await self.firebase.send_password_reset_email(email)
            return True
        except Exception as e:
            print(f"Password reset error: {str(e)}")
            raise
    
    async def verify_email(self, email):
        """Send email verification"""
        try:
            await self.firebase.send_email_verification(email)
            return True
        except Exception as e:
            print(f"Email verification error: {str(e)}")
            raise
    
    async def google_sign_in(self, google_token):
        """Sign in with Google"""
        try:
            # Verify Google token and get user info
            user_info = await self.firebase.verify_google_token(google_token)
            
            # Check if user exists
            user_data = await self.firebase.get_user_by_email(user_info['email'])
            
            if not user_data:
                # Create new user if doesn't exist
                user_id = self.id_generator.generate_user_id('student')
                user_data = {
                    'email': user_info['email'],
                    'user_type': 'student',
                    'profile': {
                        'name': user_info['name'],
                        'picture': user_info['picture']
                    },
                    'created_at': datetime.utcnow(),
                    'status': 'active',
                    'email_verified': True
                }
                await self.firebase.create_user_with_data(user_data)
            
            return user_data
            
        except Exception as e:
            print(f"Google sign-in error: {str(e)}")
            raise
    
    def _validate_email(self, email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    def _validate_password(self, password):
        """
        Validate password strength
        - At least 8 characters
        - Contains uppercase and lowercase letters
        - Contains numbers
        - Contains special characters
        """
        if len(password) < 8:
            return False
        if not re.search(r'[A-Z]', password):
            return False
        if not re.search(r'[a-z]', password):
            return False
        if not re.search(r'[0-9]', password):
            return False
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return False
        return True
    
    def _get_account_type(self, user_type):
        """Get account type based on user type"""
        account_types = {
            USER_TYPES['STUDENT']: 'basic',
            USER_TYPES['TEACHER']: 'professional',
            USER_TYPES['PARENT']: 'family',
            USER_TYPES['ADMIN']: 'admin'
        }
        return account_types.get(user_type, 'basic')
    
    def _store_local_user(self, user_id, user_data):
        """Store user data in local database"""
        query = '''
            INSERT INTO users (id, email, user_type, last_sync, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        '''
        self.local_db.execute_query(query, (
            user_id,
            user_data['email'],
            user_data['user_type'],
            datetime.utcnow(),
            user_data['created_at'],
            user_data['created_at']
        ))