from kivy.event import EventDispatcher
from kivy.properties import BooleanProperty, StringProperty, DictProperty

class AuthState(EventDispatcher):
    is_authenticated = BooleanProperty(False)
    current_user = DictProperty({})
    user_type = StringProperty("")
    access_token = StringProperty("")
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.created_at = "2025-02-15 05:27:50"
        self.created_by = "SmartEdu-academy"
    
    def set_authenticated(self, user_data, access_token):
        """Set user as authenticated"""
        self.is_authenticated = True
        self.current_user = user_data
        self.user_type = user_data.get('user_type', '')
        self.access_token = access_token
    
    def clear_auth_state(self):
        """Clear authentication state"""
        self.is_authenticated = False
        self.current_user = {}
        self.user_type = ""
        self.access_token = ""
    
    def update_user_data(self, user_data):
        """Update current user data"""
        self.current_user.update(user_data)