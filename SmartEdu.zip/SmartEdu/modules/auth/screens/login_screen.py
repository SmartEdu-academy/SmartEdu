from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.textfield import MDTextField
from ...auth.auth_service import AuthService

class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.auth_service = AuthService()
        self.dialog = None
        self.created_at = "2025-02-15 05:26:18"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        self.ids.email.text = ""
        self.ids.password.text = ""
    
    async def login(self):
        """Handle login button press"""
        email = self.ids.email.text
        password = self.ids.password.text
        
        if not email or not password:
            self.show_error_dialog("Please fill in all fields")
            return
        
        try:
            user_data = await self.auth_service.login(email, password)
            self.manager.current = 'home'
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def switch_to_register(self):
        """Switch to registration screen"""
        self.manager.current = 'register'
    
    def forgot_password(self):
        """Handle forgot password button press"""
        if not self.ids.email.text:
            self.show_error_dialog("Please enter your email")
            return
            
        try:
            self.auth_service.reset_password(self.ids.email.text)
            self.show_success_dialog(
                "Password reset instructions have been sent to your email"
            )
        except Exception as e:
            self.show_error_dialog(str(e))