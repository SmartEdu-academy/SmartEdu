from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.menu import MDDropdownMenu
from ...auth.auth_service import AuthService
from ...constants import USER_TYPES

class RegisterScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.auth_service = AuthService()
        self.dialog = None
        self.user_type_menu = None
        self.created_at = "2025-02-15 05:26:18"
        self.created_by = "SmartEdu-academy"
        self._setup_user_type_menu()
    
    def _setup_user_type_menu(self):
        """Setup user type dropdown menu"""
        user_types = [
            {
                "text": "Student",
                "viewclass": "OneLineListItem",
                "on_release": lambda x="student": self.set_user_type(x),
            },
            {
                "text": "Teacher",
                "viewclass": "OneLineListItem",
                "on_release": lambda x="teacher": self.set_user_type(x),
            },
            {
                "text": "Parent",
                "viewclass": "OneLineListItem",
                "on_release": lambda x="parent": self.set_user_type(x),
            }
        ]
        
        self.user_type_menu = MDDropdownMenu(
            caller=self.ids.user_type,
            items=user_types,
            width_mult=4
        )
    
    def set_user_type(self, user_type):
        """Set selected user type"""
        self.ids.user_type.text = user_type.capitalize()
        self.user_type_menu.dismiss()
    
    async def register(self):
        """Handle registration button press"""
        email = self.ids.email.text
        password = self.ids.password.text
        confirm_password = self.ids.confirm_password.text
        user_type = self.ids.user_type.text.lower()
        
        if not all([email, password, confirm_password, user_type]):
            self.show_error_dialog("Please fill in all fields")
            return
        
        if password != confirm_password:
            self.show_error_dialog("Passwords do not match")
            return
        
        try:
            # Prepare profile data
            profile_data = {
                'name': self.ids.name.text,
                'phone': self.ids.phone.text,
                'setup_completed': False
            }
            
            # Register user
            user_id = await self.auth_service.register_user(
                email,
                password,
                user_type,
                profile_data
            )
            
            # Send email verification
            await self.auth_service.verify_email(email)
            
            # Show success message and switch to login screen
            self.show_success_dialog(
                "Registration successful! Please verify your email to continue."
            )
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def show_success_dialog(self, text):
        """Show success dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Success",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.switch_to_login()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def switch_to_login(self):
        """Switch to login screen"""
        if self.dialog:
            self.dialog.dismiss()
        self.manager.current = 'login'