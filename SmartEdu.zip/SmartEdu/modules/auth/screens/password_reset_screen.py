from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.dialog import MDDialog
from ...auth.auth_service import AuthService

class PasswordResetScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.auth_service = AuthService()
        self.dialog = None
        self.created_at = "2025-02-15 05:27:50"
        self.created_by = "SmartEdu-academy"
    
    async def reset_password(self):
        """Handle password reset request"""
        email = self.ids.email.text
        
        if not email:
            self.show_error_dialog("Please enter your email address")
            return
        
        try:
            await self.auth_service.reset_password(email)
            self.show_success_dialog(
                "Password reset instructions have been sent to your email"
            )
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def show_success_dialog(self, text):
        """Show success dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Success",
                text=text,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: self.switch_to_login()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()
    
    def switch_to_login(self):
        """Switch to login screen"""
        if self.dialog:
            self.dialog.dismiss()
        self.manager.current = 'login'