import os
import json
import shutil
from datetime import datetime, timedelta
from ..config import Config

class CacheManager:
    def __init__(self):
        self.config = Config()
        self.cache_dir = self.config.CACHE_DIR
        self.created_at = "2025-02-15 05:18:19"
        self.created_by = "SmartEdu-academy"
        self._ensure_cache_dir()
    
    def _ensure_cache_dir(self):
        """Ensure cache directory exists"""
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
    
    def _get_cache_path(self, key):
        """Get file path for cache key"""
        return os.path.join(self.cache_dir, f"{key}.cache")
    
    def set(self, key, value, expires_in=3600):
        """Store value in cache with expiration"""
        cache_data = {
            'value': value,
            'expires_at': (datetime.utcnow() + timedelta(seconds=expires_in)).isoformat()
        }
        
        with open(self._get_cache_path(key), 'w') as f:
            json.dump(cache_data, f)
    
    def get(self, key):
        """Get value from cache if not expired"""
        try:
            cache_path = self._get_cache_path(key)
            
            if not os.path.exists(cache_path):
                return None
            
            with open(cache_path, 'r') as f:
                cache_data = json.load(f)
            
            expires_at = datetime.fromisoformat(cache_data['expires_at'])
            
            if datetime.utcnow() > expires_at:
                os.remove(cache_path)
                return None
            
            return cache_data['value']
            
        except Exception as e:
            print(f"Cache read error: {str(e)}")
            return None
    
    def delete(self, key):
        """Delete item from cache"""
        try:
            cache_path = self._get_cache_path(key)
            if os.path.exists(cache_path):
                os.remove(cache_path)
        except Exception as e:
            print(f"Cache delete error: {str(e)}")
    
    def clear(self):
        """Clear all cache"""
        try:
            shutil.rmtree(self.cache_dir)
            self._ensure_cache_dir()
        except Exception as e:
            print(f"Cache clear error: {str(e)}")