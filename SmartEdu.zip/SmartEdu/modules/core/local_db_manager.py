import sqlite3
import os
from datetime import datetime
from ..config import Config

class LocalDBManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(LocalDBManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        self.config = Config()
        self.db_path = os.path.join(self.config.DATA_DIR, 'smartedu.db')
        self.created_at = "2025-02-15 05:18:19"
        self.created_by = "SmartEdu-academy"
        self._initialize_db()
        self._initialized = True
    
    def _initialize_db(self):
        """Initialize SQLite database with required tables"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    email TEXT UNIQUE,
                    user_type TEXT,
                    last_sync TIMESTAMP,
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP
                )
            ''')
            
            # Create courses table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS courses (
                    id TEXT PRIMARY KEY,
                    title TEXT,
                    description TEXT,
                    instructor_id TEXT,
                    last_sync TIMESTAMP,
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP
                )
            ''')
            
            # Create progress table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS progress (
                    user_id TEXT,
                    course_id TEXT,
                    progress REAL,
                    last_activity TIMESTAMP,
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP,
                    PRIMARY KEY (user_id, course_id)
                )
            ''')
            
            # Create offline_queue table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS offline_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action TEXT,
                    data TEXT,
                    created_at TIMESTAMP
                )
            ''')
            
            conn.commit()
            
        except Exception as e:
            print(f"Database initialization error: {str(e)}")
            raise
        finally:
            conn.close()
    
    def execute_query(self, query, params=None):
        """Execute SQL query and return results"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
                
            if query.strip().upper().startswith('SELECT'):
                result = cursor.fetchall()
            else:
                conn.commit()
                result = None
                
            return result
            
        except Exception as e:
            print(f"Query execution error: {str(e)}")
            raise
        finally:
            conn.close()
    
    def add_to_offline_queue(self, action, data):
        """Add action to offline queue for later sync"""
        query = '''
            INSERT INTO offline_queue (action, data, created_at)
            VALUES (?, ?, ?)
        '''
        self.execute_query(query, (action, data, datetime.utcnow()))