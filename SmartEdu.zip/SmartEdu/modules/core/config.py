import os
import json
from datetime import datetime

class Config:
    def __init__(self):
        self.APP_NAME = "SmartEdu"
        self.VERSION = "1.0.0"
        self.DEBUG = True
        self.API_VERSION = "v1"
        self.CREATED_AT = "2025-02-15 04:49:23"
        self.CREATED_BY = "SmartEdu-academy"
        
        # Firebase Configuration
        self.FIREBASE_CONFIG = {
            'apiKey': '',  # To be filled
            'authDomain': '',  # To be filled
            'projectId': '',  # To be filled
            'storageBucket': '',  # To be filled
            'messagingSenderId': '',  # To be filled
            'appId': '',  # To be filled
            'measurementId': ''  # To be filled
        }
        
        # API Endpoints
        self.BASE_URL = "https://api.smartedu.com"
        self.API_ENDPOINTS = {
            'auth': f"{self.BASE_URL}/{self.API_VERSION}/auth",
            'users': f"{self.BASE_URL}/{self.API_VERSION}/users",
            'courses': f"{self.BASE_URL}/{self.API_VERSION}/courses",
            'ai': f"{self.BASE_URL}/{self.API_VERSION}/ai"
        }
        
        # App Paths
        self.BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.ASSETS_DIR = os.path.join(self.BASE_DIR, 'assets')
        self.CACHE_DIR = os.path.join(self.BASE_DIR, 'cache')
        self.DATA_DIR = os.path.join(self.BASE_DIR, 'data')
        
        # Create necessary directories
        self._create_directories()
        
    def _create_directories(self):
        """Create necessary directories if they don't exist"""
        directories = [self.ASSETS_DIR, self.CACHE_DIR, self.DATA_DIR]
        for directory in directories:
            if not os.path.exists(directory):
                os.makedirs(directory)
                
    def save_config(self):
        """Save current configuration to a file"""
        config_path = os.path.join(self.DATA_DIR, 'config.json')
        config_data = {
            'app_name': self.APP_NAME,
            'version': self.VERSION,
            'created_at': self.CREATED_AT,
            'created_by': self.CREATED_BY,
            'last_updated': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        with open(config_path, 'w') as f:
            json.dump(config_data, f, indent=4)
            
    # Add to Config class
self.AI_CONFIG = {
    'model_path': 'models/',
    'api_version': 'v1',
    'max_tokens': 1000
}