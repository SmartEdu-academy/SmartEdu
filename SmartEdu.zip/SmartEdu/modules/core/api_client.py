import aiohttp
import asyncio
from datetime import datetime
from ..config import Config

class APIClient:
    def __init__(self):
        self.config = Config()
        self.base_url = self.config.BASE_URL
        self.session = None
        self.created_at = "2025-02-15 05:18:19"
        self.created_by = "SmartEdu-academy"
    
    async def _ensure_session(self):
        """Ensure aiohttp session exists"""
        if self.session is None:
            self.session = aiohttp.ClientSession()
    
    async def close(self):
        """Close the session"""
        if self.session:
            await self.session.close()
            self.session = None
    
    async def _request(self, method, endpoint, **kwargs):
        """Make HTTP request with error handling"""
        await self._ensure_session()
        
        try:
            async with self.session.request(
                method,
                f"{self.base_url}{endpoint}",
                **kwargs
            ) as response:
                response.raise_for_status()
                return await response.json()
                
        except aiohttp.ClientError as e:
            print(f"API request error: {str(e)}")
            raise
    
    async def get_ai_response(self, prompt, context=None):
        """Get AI model response"""
        return await self._request(
            'POST',
            '/ai/generate',
            json={
                'prompt': prompt,
                'context': context or {},
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    async def verify_certificate(self, certificate_id):
        """Verify certificate on blockchain"""
        return await self._request(
            'GET',
            f'/blockchain/verify/{certificate_id}'
        )
    
    async def get_ar_content(self, content_id):
        """Get AR content metadata"""
        return await self._request(
            'GET',
            f'/ar/content/{content_id}'
        )