from datetime import datetime
import json
from .firebase_manager import FirebaseManager
from .local_db_manager import LocalDBManager

class SyncManager:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.local_db = LocalDBManager()
        self.created_at = "2025-02-15 05:18:19"
        self.created_by = "SmartEdu-academy"
    
    async def sync_user_data(self, user_id):
        """Synchronize user data between local and remote databases"""
        try:
            # Get remote data
            remote_data = await self.firebase.get_user_data(user_id)
            
            if remote_data:
                # Update local database
                query = '''
                    INSERT OR REPLACE INTO users 
                    (id, email, user_type, last_sync, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                '''
                self.local_db.execute_query(query, (
                    user_id,
                    remote_data.get('email'),
                    remote_data.get('user_type'),
                    datetime.utcnow(),
                    remote_data.get('created_at'),
                    remote_data.get('updated_at')
                ))
                
            return True
            
        except Exception as e:
            print(f"Error syncing user data: {str(e)}")
            return False
    
    async def process_offline_queue(self):
        """Process pending offline actions"""
        try:
            # Get all pending actions
            query = "SELECT * FROM offline_queue ORDER BY created_at"
            actions = self.local_db.execute_query(query)
            
            for action_id, action_type, data, created_at in actions:
                try:
                    # Process action based on type
                    data_dict = json.loads(data)
                    
                    if action_type == 'UPDATE_USER':
                        await self.firebase.update_user_data(
                            data_dict['user_id'],
                            data_dict['updates']
                        )
                    elif action_type == 'UPDATE_PROGRESS':
                        # Implement progress update logic
                        pass
                    
                    # Remove processed action
                    self.local_db.execute_query(
                        "DELETE FROM offline_queue WHERE id = ?",
                        (action_id,)
                    )
                    
                except Exception as action_error:
                    print(f"Error processing action {action_id}: {str(action_error)}")
                    continue
            
            return True
            
        except Exception as e:
            print(f"Error processing offline queue: {str(e)}")
            return False