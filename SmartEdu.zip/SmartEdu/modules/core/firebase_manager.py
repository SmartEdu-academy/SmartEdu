import firebase_admin
from firebase_admin import credentials, auth, firestore, storage
from datetime import datetime
from ..config import Config

class FirebaseManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(FirebaseManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        self.config = Config()
        self._initialize_firebase()
        self.db = firestore.client()
        self.bucket = storage.bucket()
        self._initialized = True
        self.created_at = "2025-02-15 05:18:19"
        self.created_by = "SmartEdu-academy"
    
    def _initialize_firebase(self):
        """Initialize Firebase with credentials"""
        try:
            cred = credentials.Certificate('path_to_firebase_credentials.json')
            firebase_admin.initialize_app(cred, {
                'storageBucket': self.config.FIREBASE_CONFIG['storageBucket']
            })
        except Exception as e:
            print(f"Firebase initialization error: {str(e)}")
            raise
    
    async def create_user(self, email, password, user_data):
        """Create a new user in Firebase Auth and Firestore"""
        try:
            # Create user in Firebase Auth
            user = auth.create_user(
                email=email,
                password=password,
                email_verified=False
            )
            
            # Add user data to Firestore
            user_data.update({
                'uid': user.uid,
                'created_at': datetime.utcnow(),
                'updated_at': datetime.utcnow()
            })
            
            await self.db.collection('users').document(user.uid).set(user_data)
            return user.uid
            
        except Exception as e:
            print(f"Error creating user: {str(e)}")
            raise
    
    async def get_user_data(self, uid):
        """Retrieve user data from Firestore"""
        try:
            doc = await self.db.collection('users').document(uid).get()
            return doc.to_dict() if doc.exists else None
        except Exception as e:
            print(f"Error getting user data: {str(e)}")
            raise
    
    async def update_user_data(self, uid, data):
        """Update user data in Firestore"""
        try:
            data['updated_at'] = datetime.utcnow()
            await self.db.collection('users').document(uid).update(data)
            return True
        except Exception as e:
            print(f"Error updating user data: {str(e)}")
            raise
    
    async def upload_file(self, file_path, destination_path):
        """Upload file to Firebase Storage"""
        try:
            blob = self.bucket.blob(destination_path)
            blob.upload_from_filename(file_path)
            return blob.public_url
        except Exception as e:
            print(f"Error uploading file: {str(e)}")
            raise