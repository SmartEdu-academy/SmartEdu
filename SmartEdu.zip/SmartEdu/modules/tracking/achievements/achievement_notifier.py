from datetime import datetime
from ...notifications.notification_manager import NotificationManager

class AchievementNotifier:
    def __init__(self):
        self.notification_manager = NotificationManager()
        self.created_at = "2025-02-15 19:35:52"
        self.created_by = "SmartEdu-academy"

    async def notify_achievement(self, user_id, achievement):
        """Send achievement notification to user"""
        try:
            notification_data = {
                'type': 'achievement',
                'title': f'New Achievement: {achievement["name"]}',
                'message': (
                    f'Congratulations! You\'ve earned the "{achievement["name"]}" '
                    f'achievement. {achievement["description"]}'
                ),
                'icon': achievement['icon'],
                'data': {
                    'achievement_id': achievement['achievement_id'],
                    'points': achievement['points'],
                    'category': achievement['category']
                },
                'timestamp': datetime.utcnow().isoformat()
            }
            
            await self.notification_manager.send_notification(
                user_id,
                notification_data
            )
            
        except Exception as e:
            print(f"Error sending achievement notification: {str(e)}")
            raise