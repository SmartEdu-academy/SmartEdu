from datetime import datetime
from ...data.firebase_manager import FirebaseManager
from ...data.cache_manager import CacheManager

class AchievementSystem:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.cache = CacheManager()
        self.created_at = "2025-02-15 19:35:52"
        self.created_by = "SmartEdu-academy"
        
        # Achievement categories and their weights
        self.achievement_categories = {
            'learning_progress': 1.0,
            'skill_mastery': 1.2,
            'consistency': 1.1,
            'quiz_performance': 1.0,
            'study_habits': 0.9,
            'collaboration': 0.8
        }

    async def check_achievements(self, user_id, activity_data):
        """Check and award achievements based on activity"""
        try:
            # Get user's current achievements
            current_achievements = await self.firebase.get_user_achievements(user_id)
            
            # Get available achievements
            available_achievements = await self._get_available_achievements()
            
            # Check for new achievements
            new_achievements = []
            for achievement in available_achievements:
                if (achievement['id'] not in current_achievements and 
                    await self._check_achievement_criteria(user_id, achievement, activity_data)):
                    new_achievement = await self._award_achievement(user_id, achievement)
                    new_achievements.append(new_achievement)
            
            # Clear achievement cache
            self.cache.delete_pattern(f"achievements_{user_id}_*")
            
            return new_achievements
            
        except Exception as e:
            print(f"Error checking achievements: {str(e)}")
            raise

    async def get_user_achievements(self, user_id):
        """Get user's earned achievements"""
        try:
            cache_key = f"achievements_{user_id}"
            cached_achievements = self.cache.get(cache_key)
            
            if cached_achievements:
                return cached_achievements
            
            achievements = await self.firebase.get_user_achievements(user_id)
            self.cache.set(cache_key, achievements, expires_in=3600)
            
            return achievements
            
        except Exception as e:
            print(f"Error getting user achievements: {str(e)}")
            raise

    async def _check_achievement_criteria(self, user_id, achievement, activity_data):
        """Check if achievement criteria are met"""
        try:
            criteria = achievement['criteria']
            criteria_type = criteria['type']
            
            if criteria_type == 'count':
                return await self._check_count_criteria(user_id, criteria)
            elif criteria_type == 'streak':
                return await self._check_streak_criteria(user_id, criteria)
            elif criteria_type == 'score':
                return await self._check_score_criteria(user_id, criteria)
            elif criteria_type == 'time':
                return await self._check_time_criteria(user_id, criteria)
            elif criteria_type == 'composite':
                return await self._check_composite_criteria(user_id, criteria)
            else:
                raise ValueError(f"Unknown criteria type: {criteria_type}")
                
        except Exception as e:
            print(f"Error checking achievement criteria: {str(e)}")
            raise

    async def _award_achievement(self, user_id, achievement):
        """Award achievement to user"""
        try:
            award_data = {
                'achievement_id': achievement['id'],
                'name': achievement['name'],
                'description': achievement['description'],
                'category': achievement['category'],
                'points': achievement['points'],
                'icon': achievement['icon'],
                'earned_at': datetime.utcnow().isoformat(),
                'level': achievement.get('level', 1)
            }
            
            # Save achievement to user's record
            await self.firebase.save_user_achievement(user_id, award_data)
            
            # Update user's points
            await self._update_user_points(user_id, achievement['points'])
            
            return award_data
            
        except Exception as e:
            print(f"Error awarding achievement: {str(e)}")
            raise

    async def _get_available_achievements(self):
        """Get list of available achievements"""
        try:
            cache_key = "available_achievements"
            cached_achievements = self.cache.get(cache_key)
            
            if cached_achievements:
                return cached_achievements
            
            achievements = [
                {
                    'id': 'first_quiz',
                    'name': 'Quiz Pioneer',
                    'description': 'Complete your first quiz',
                    'category': 'learning_progress',
                    'points': 10,
                    'icon': 'medal',
                    'criteria': {
                        'type': 'count',
                        'activity': 'quiz',
                        'threshold': 1
                    }
                },
                {
                    'id': 'perfect_score',
                    'name': 'Perfect Score',
                    'description': 'Get 100% on any quiz',
                    'category': 'quiz_performance',
                    'points': 50,
                    'icon': 'star',
                    'criteria': {
                        'type': 'score',
                        'threshold': 100
                    }
                },
                {
                    'id': 'study_streak_7',
                    'name': 'Weekly Warrior',
                    'description': 'Maintain a 7-day study streak',
                    'category': 'consistency',
                    'points': 30,
                    'icon': 'fire',
                    'criteria': {
                        'type': 'streak',
                        'days': 7
                    }
                },
                # Add more achievements as needed
            ]
            
            self.cache.set(cache_key, achievements, expires_in=86400)  # Cache for 24 hours
            return achievements
            
        except Exception as e:
            print(f"Error getting available achievements: {str(e)}")
            raise

    async def _check_count_criteria(self, user_id, criteria):
        """Check count-based criteria"""
        try:
            activity_count = await self.firebase.get_activity_count(
                user_id,
                criteria['activity']
            )
            return activity_count >= criteria['threshold']
        except Exception as e:
            print(f"Error checking count criteria: {str(e)}")
            raise

    async def _check_streak_criteria(self, user_id, criteria):
        """Check streak-based criteria"""
        try:
            current_streak = await self.firebase.get_user_streak(user_id)
            return current_streak >= criteria['days']
        except Exception as e:
            print(f"Error checking streak criteria: {str(e)}")
            raise

    async def _check_score_criteria(self, user_id, criteria):
        """Check score-based criteria"""
        try:
            scores = await self.firebase.get_user_scores(user_id)
            return any(score >= criteria['threshold'] for score in scores)
        except Exception as e:
            print(f"Error checking score criteria: {str(e)}")
            raise

    async def _check_time_criteria(self, user_id, criteria):
        """Check time-based criteria"""
        try:
            total_time = await self.firebase.get_total_study_time(user_id)
            return total_time >= criteria['minutes']
        except Exception as e:
            print(f"Error checking time criteria: {str(e)}")
            raise

    async def _check_composite_criteria(self, user_id, criteria):
        """Check composite criteria (multiple conditions)"""
        try:
            results = []
            for subcriteria in criteria['conditions']:
                if subcriteria['type'] == 'count':
                    result = await self._check_count_criteria(user_id, subcriteria)
                elif subcriteria['type'] == 'streak':
                    result = await self._check_streak_criteria(user_id, subcriteria)
                elif subcriteria['type'] == 'score':
                    result = await self._check_score_criteria(user_id, subcriteria)
                elif subcriteria['type'] == 'time':
                    result = await self._check_time_criteria(user_id, subcriteria)
                results.append(result)
            
            return all(results) if criteria.get('operator') == 'AND' else any(results)
            
        except Exception as e:
            print(f"Error checking composite criteria: {str(e)}")
            raise

    async def _update_user_points(self, user_id, points):
        """Update user's achievement points"""
        try:
            await self.firebase.update_user_points(user_id, points)
        except Exception as e:
            print(f"Error updating user points: {str(e)}")
            raise