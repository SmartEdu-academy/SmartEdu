from datetime import datetime
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

class ProgressVisualizer:
    def __init__(self):
        self.created_at = "2025-02-15 19:31:57"
        self.created_by = "SmartEdu-academy"
        self.chart_theme = "plotly_white"
        self.color_palette = px.colors.qualitative.Set3

    def create_progress_timeline(self, activities_data):
        """Create interactive timeline of learning progress"""
        df = pd.DataFrame(activities_data)
        
        fig = px.timeline(
            df,
            x_start="start_time",
            x_end="end_time",
            y="subject",
            color="activity_type",
            hover_data=["score", "completion_status"],
            title="Learning Progress Timeline"
        )
        
        fig.update_layout(
            template=self.chart_theme,
            showlegend=True,
            height=400
        )
        
        return fig.to_html(full_html=False)

    def create_mastery_radar(self, mastery_data):
        """Create radar chart for skill/topic mastery"""
        categories = list(mastery_data.keys())
        values = list(mastery_data.values())
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself',
            name='Current Mastery'
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 100]
                )
            ),
            showlegend=True,
            title="Skills Mastery Overview"
        )
        
        return fig.to_html(full_html=False)

    def create_progress_heatmap(self, activity_data):
        """Create heatmap showing activity intensity"""
        df = pd.DataFrame(activity_data)
        pivot_table = df.pivot_table(
            values='duration',
            index=pd.to_datetime(df['date']).dt.day_name(),
            columns=pd.to_datetime(df['time']).dt.hour,
            aggfunc='sum'
        )
        
        fig = go.Figure(data=go.Heatmap(
            z=pivot_table.values,
            x=pivot_table.columns,
            y=pivot_table.index,
            colorscale='Viridis'
        ))
        
        fig.update_layout(
            title='Learning Activity Heatmap',
            xaxis_title='Hour of Day',
            yaxis_title='Day of Week'
        )
        
        return fig.to_html(full_html=False)

    def create_performance_trend(self, performance_data):
        """Create line chart showing performance trends"""
        df = pd.DataFrame(performance_data)
        
        fig = px.line(
            df,
            x='timestamp',
            y='score',
            color='subject',
            title='Performance Trends by Subject',
            labels={'score': 'Score (%)', 'timestamp': 'Date'}
        )
        
        fig.update_layout(
            template=self.chart_theme,
            hovermode='x unified'
        )
        
        return fig.to_html(full_html=False)

    def create_skill_tree(self, skills_data):
        """Create interactive skill tree visualization"""
        nodes = []
        edges = []
        
        for skill, data in skills_data.items():
            nodes.append({
                'id': skill,
                'label': skill,
                'level': data['level'],
                'progress': data['progress']
            })
            
            for prerequisite in data.get('prerequisites', []):
                edges.append({
                    'from': prerequisite,
                    'to': skill
                })
        
        # Convert to visualization format
        fig = go.Figure()
        
        # Add nodes
        fig.add_trace(go.Scatter(
            x=[node['level'] for node in nodes],
            y=[node['progress'] for node in nodes],
            mode='markers+text',
            text=[node['label'] for node in nodes],
            textposition='bottom center'
        ))
        
        # Add edges
        for edge in edges:
            start_node = next(n for n in nodes if n['id'] == edge['from'])
            end_node = next(n for n in nodes if n['id'] == edge['to'])
            
            fig.add_trace(go.Scatter(
                x=[start_node['level'], end_node['level']],
                y=[start_node['progress'], end_node['progress']],
                mode='lines',
                line=dict(color='gray', width=1),
                showlegend=False
            ))
        
        fig.update_layout(
            title='Skill Progression Tree',
            showlegend=False,
            hovermode='closest'
        )
        
        return fig.to_html(full_html=False)

    def create_achievement_showcase(self, achievements_data):
        """Create visual showcase of achievements"""
        df = pd.DataFrame(achievements_data)
        
        fig = px.timeline(
            df,
            x_start='earned_date',
            y='category',
            color='difficulty',
            hover_data=['name', 'description', 'points'],
            title='Achievement Timeline'
        )
        
        fig.update_layout(
            template=self.chart_theme,
            showlegend=True
        )
        
        return fig.to_html(full_html=False)

    def create_comparison_chart(self, user_data, peer_average):
        """Create comparison chart between user and peers"""
        categories = list(user_data.keys())
        user_values = list(user_data.values())
        peer_values = [peer_average.get(cat, 0) for cat in categories]
        
        fig = go.Figure(data=[
            go.Bar(name='Your Score', x=categories, y=user_values),
            go.Bar(name='Peer Average', x=categories, y=peer_values)
        ])
        
        fig.update_layout(
            barmode='group',
            title='Performance Comparison with Peers',
            yaxis_title='Score (%)'
        )
        
        return fig.to_html(full_html=False)

    def create_learning_path_progress(self, path_data):
        """Create visual representation of learning path progress"""
        df = pd.DataFrame(path_data)
        
        fig = px.scatter(
            df,
            x='complexity',
            y='mastery',
            size='time_spent',
            color='status',
            hover_data=['topic', 'prerequisites'],
            title='Learning Path Progress'
        )
        
        fig.update_layout(
            template=self.chart_theme,
            xaxis_title='Topic Complexity',
            yaxis_title='Mastery Level (%)'
        )
        
        return fig.to_html(full_html=False)