from datetime import datetime
import numpy as np
from ..data.firebase_manager import FirebaseManager
from ..data.cache_manager import CacheManager
from ..ai.performance_analysis import PerformanceAnalysis

class StudentPerformanceTracker:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.cache = CacheManager()
        self.performance_analyzer = PerformanceAnalysis()
        self.created_at = "2025-02-15 19:24:34"
        self.created_by = "SmartEdu-academy"

    async def track_learning_activity(self, user_id, activity_data):
        """Track any learning activity and store analytics"""
        try:
            activity_record = {
                'user_id': user_id,
                'activity_type': activity_data['type'],
                'timestamp': datetime.utcnow().isoformat(),
                'duration': activity_data.get('duration', 0),
                'content_id': activity_data.get('content_id'),
                'progress': activity_data.get('progress', 0),
                'score': activity_data.get('score'),
                'difficulty_level': activity_data.get('difficulty_level', 'medium'),
                'subject': activity_data.get('subject'),
                'topics': activity_data.get('topics', []),
                'completion_status': activity_data.get('completion_status', 'in_progress'),
                'metadata': activity_data.get('metadata', {})
            }

            await self.firebase.save_learning_activity(user_id, activity_record)
            await self._update_performance_metrics(user_id, activity_record)
            self.cache.delete_pattern(f"performance_{user_id}_*")
            
            return activity_record

        except Exception as e:
            print(f"Error tracking learning activity: {str(e)}")
            raise

    async def track_quiz_performance(self, user_id, quiz_data):
        """Track quiz performance and analytics"""
        try:
            quiz_record = {
                'user_id': user_id,
                'quiz_id': quiz_data['quiz_id'],
                'timestamp': datetime.utcnow().isoformat(),
                'score': quiz_data['score'],
                'total_questions': quiz_data['total_questions'],
                'correct_answers': quiz_data['correct_answers'],
                'time_taken': quiz_data['time_taken'],
                'subject': quiz_data['subject'],
                'topics': quiz_data['topics'],
                'difficulty_level': quiz_data['difficulty_level'],
                'answers': quiz_data.get('answers', []),
                'mistakes': quiz_data.get('mistakes', [])
            }

            await self.firebase.save_quiz_performance(user_id, quiz_record)
            await self._update_quiz_metrics(user_id, quiz_record)
            self.cache.delete_pattern(f"quiz_performance_{user_id}_*")
            
            return quiz_record

        except Exception as e:
            print(f"Error tracking quiz performance: {str(e)}")
            raise

    async def track_study_session(self, user_id, session_data):
        """Track study session analytics"""
        try:
            session_record = {
                'user_id': user_id,
                'session_id': session_data['session_id'],
                'timestamp': datetime.utcnow().isoformat(),
                'start_time': session_data['start_time'],
                'end_time': session_data['end_time'],
                'duration': session_data['duration'],
                'topics': session_data['topics'],
                'resources_used': session_data['resources'],
                'completion_status': session_data['completion_status'],
                'focus_score': session_data.get('focus_score', 0),
                'notes': session_data.get('notes', '')
            }

            await self.firebase.save_study_session(user_id, session_record)
            await self._update_study_metrics(user_id, session_record)
            self.cache.delete_pattern(f"study_session_{user_id}_*")
            
            return session_record

        except Exception as e:
            print(f"Error tracking study session: {str(e)}")
            raise

    async def get_performance_report(self, user_id, time_range=None):
        """Generate comprehensive performance report"""
        try:
            cache_key = f"performance_report_{user_id}_{time_range}"
            cached_report = self.cache.get(cache_key)
            
            if cached_report:
                return cached_report

            # Get all necessary data
            activities = await self.firebase.get_learning_activities(user_id, time_range)
            quiz_results = await self.firebase.get_quiz_results(user_id, time_range)
            study_sessions = await self.firebase.get_study_sessions(user_id, time_range)
            
            # Generate comprehensive report
            report = {
                'overview': self._generate_overview(activities, quiz_results, study_sessions),
                'subject_analysis': self._analyze_subjects(activities, quiz_results),
                'topic_mastery': self._analyze_topic_mastery(quiz_results),
                'skill_progression': self._analyze_skill_progression(activities),
                'learning_patterns': self._analyze_learning_patterns(study_sessions),
                'recommendations': self._generate_recommendations(activities, quiz_results, study_sessions),
                'generated_at': datetime.utcnow().isoformat()
            }
            
            self.cache.set(cache_key, report, expires_in=3600)
            return report

        except Exception as e:
            print(f"Error generating performance report: {str(e)}")
            raise

    def _generate_overview(self, activities, quiz_results, study_sessions):
        """Generate overview metrics"""
        total_time = sum(session['duration'] for session in study_sessions)
        return {
            'total_learning_time': {
                'hours': total_time // 3600,
                'minutes': (total_time % 3600) // 60
            },
            'total_activities_completed': len(activities),
            'active_subjects': len(set(a['subject'] for a in activities if 'subject' in a)),
            'average_quiz_score': self._calculate_average_score(quiz_results),
            'current_streak': self._calculate_current_streak(activities),
            'completion_rate': self._calculate_completion_rate(activities),
            'overall_progress': self._calculate_overall_progress(activities, quiz_results)
        }

    def _analyze_subjects(self, activities, quiz_results):
        """Analyze performance by subject"""
        subjects = {}
        for activity in activities:
            if 'subject' not in activity:
                continue
                
            subject = activity['subject']
            if subject not in subjects:
                subjects[subject] = {
                    'activities_count': 0,
                    'total_time': 0,
                    'quiz_scores': [],
                    'completion_rate': 0
                }
            
            subjects[subject]['activities_count'] += 1
            subjects[subject]['total_time'] += activity.get('duration', 0)
            
        # Add quiz scores
        for quiz in quiz_results:
            if 'subject' in quiz:
                subject = quiz['subject']
                if subject in subjects:
                    subjects[subject]['quiz_scores'].append(quiz['score'])

        # Calculate averages and trends
        for subject in subjects.values():
            subject['average_score'] = np.mean(subject['quiz_scores']) if subject['quiz_scores'] else 0
            subject['score_trend'] = self._calculate_trend(subject['quiz_scores'])
        
        return subjects

    def _analyze_topic_mastery(self, quiz_results):
        """Analyze mastery level by topic"""
        topics = {}
        for quiz in quiz_results:
            for topic in quiz.get('topics', []):
                if topic not in topics:
                    topics[topic] = {
                        'attempts': 0,
                        'correct_answers': 0,
                        'scores': []
                    }
                
                topics[topic]['attempts'] += 1
                topics[topic]['correct_answers'] += quiz.get('correct_answers', 0)
                topics[topic]['scores'].append(quiz['score'])

        # Categorize topics
        mastery_data = {
            'mastered_topics': [],
            'in_progress_topics': [],
            'need_attention_topics': []
        }

        for topic, data in topics.items():
            mastery_level = (data['correct_answers'] / data['attempts']) * 100 if data['attempts'] > 0 else 0
            topic_info = {
                'name': topic,
                'mastery_level': mastery_level,
                'average_score': np.mean(data['scores']),
                'attempts': data['attempts']
            }

            if mastery_level >= 80:
                mastery_data['mastered_topics'].append(topic_info)
            elif mastery_level >= 50:
                mastery_data['in_progress_topics'].append(topic_info)
            else:
                mastery_data['need_attention_topics'].append(topic_info)

        return mastery_data

    def _analyze_learning_patterns(self, study_sessions):
        """Analyze learning patterns and habits"""
        if not study_sessions:
            return {
                'peak_hours': {},
                'session_length_distribution': {},
                'consistency_score': 0
            }

        # Analyze peak hours
        hour_counts = {}
        for session in study_sessions:
            start_hour = datetime.fromisoformat(session['start_time']).hour
            hour_counts[start_hour] = hour_counts.get(start_hour, 0) + 1

        # Analyze session lengths
        session_lengths = [session['duration'] / 60 for session in study_sessions]  # Convert to minutes
        
        return {
            'peak_hours': hour_counts,
            'average_session_length': np.mean(session_lengths),
            'session_length_distribution': self._categorize_session_lengths(session_lengths),
            'consistency_score': self._calculate_consistency_score(study_sessions)
        }

    def _generate_recommendations(self, activities, quiz_results, study_sessions):
        """Generate personalized recommendations"""
        recommendations = {
            'focus_areas': [],
            'study_habits': [],
            'next_steps': []
        }

        # Identify weak areas from quiz results
        subject_performance = self._analyze_subjects(activities, quiz_results)
        for subject, data in subject_performance.items():
            if data['average_score'] < 70:
                recommendations['focus_areas'].append({
                    'subject': subject,
                    'current_score': data['average_score'],
                    'suggested_activities': self._suggest_activities(subject)
                })

        # Analyze study habits
        patterns = self._analyze_learning_patterns(study_sessions)
        if patterns['consistency_score'] < 0.7:
            recommendations['study_habits'].extend([
                'Set regular study times',
                'Take shorter, more frequent breaks',
                'Review material more consistently'
            ])

        # Generate next steps
        topic_mastery = self._analyze_topic_mastery(quiz_results)
        for topic in topic_mastery['need_attention_topics']:
            recommendations['next_steps'].append({
                'topic': topic['name'],
                'action': 'Review fundamentals',
                'resources': self._suggest_resources(topic['name'])
            })

        return recommendations

    def _calculate_trend(self, scores, window_size=5):
        """Calculate trend from recent scores"""
        if len(scores) < 2:
            return "Not enough data"
            
        recent_scores = scores[-window_size:]
        if len(recent_scores) < 2:
            return "Stable"
            
        slope = np.polyfit(range(len(recent_scores)), recent_scores, 1)[0]
        
        if slope > 2:
            return "Rapidly improving"
        elif slope > 0:
            return "Gradually improving"
        elif slope < -2:
            return "Needs attention"
        elif slope < 0:
            return "Slightly declining"
        else:
            return "Stable"

    def _suggest_activities(self, subject):
        """Suggest learning activities for a subject"""
        return [
            "Review core concepts",
            "Practice with interactive exercises",
            "Watch video tutorials",
            "Take practice quizzes"
        ]

    def _suggest_resources(self, topic):
        """Suggest learning resources for a topic"""
        return [
            "Video lectures",
            "Practice problems",
            "Reading materials",
            "Interactive tutorials"
        ]

    def _calculate_consistency_score(self, study_sessions):
        """Calculate learning consistency score"""
        if not study_sessions:
            return 0
            
        # Analyze daily activity
        daily_sessions = {}
        for session in study_sessions:
            date = datetime.fromisoformat(session['start_time']).date()
            if date not in daily_sessions:
                daily_sessions[date] = 0
            daily_sessions[date] += session['duration']
            
        # Calculate consistency
        active_days = len(daily_sessions)
        total_days = (max(daily_sessions.keys()) - min(daily_sessions.keys())).days + 1
        
        return active_days / total_days if total_days > 0 else 0

    def _categorize_session_lengths(self, session_lengths):
        """Categorize study sessions by length"""
        categories = {
            'short': 0,    # < 30 minutes
            'medium': 0,   # 30-60 minutes
            'long': 0      # > 60 minutes
        }
        
        for length in session_lengths:
            if length < 30:
                categories['short'] += 1
            elif length < 60:
                categories['medium'] += 1
            else:
                categories['long'] += 1
                
        return categories