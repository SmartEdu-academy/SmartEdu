from kivy.uix.screenmanager import Screen
from kivymd.uix.tab import MDTabsBase
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.dialog import MDDialog
from ..monitoring.parent_monitoring import ParentMonitoringSystem

class ParentMonitoringScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.monitoring_system = ParentMonitoringSystem()
        self.current_student_id = None
        self.dialog = None
        self.created_at = "2025-02-15 19:41:40"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        if self.current_student_id:
            self._load_student_data()
    
    async def _load_student_data(self):
        """Load student monitoring data"""
        try:
            overview = await self.monitoring_system.get_student_overview(
                self.parent_id,
                self.current_student_id
            )
            self._update_dashboard(overview)
            
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _update_dashboard(self, overview):
        """Update dashboard with student data"""
        # Update general info
        self.ids.student_name.text = overview['general_info']['name']
        self.ids.grade_level.text = overview['general_info']['grade']
        
        # Update academic progress
        self._update_academic_progress(overview['academic_progress'])
        
        # Update recent activities
        self._update_recent_activities(overview['recent_activities'])
        
        # Update performance metrics
        self._update_performance_metrics(overview['performance_metrics'])
        
        # Update concerns and recommendations
        self._update_concerns(overview['areas_of_concern'])
        self._update_recommendations(overview['recommendations'])
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDRaisedButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()