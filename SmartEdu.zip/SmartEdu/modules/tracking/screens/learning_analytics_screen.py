from kivy.uix.screenmanager import Screen
from kivymd.uix.tab import MDTabsBase
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.card import MDCard
from ..student_performance_tracker import StudentPerformanceTracker
from ...auth.auth_state import AuthState

class LearningAnalyticsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.performance_tracker = StudentPerformanceTracker()
        self.auth_state = AuthState()
        self.dialog = None
        self.current_time_range = 'month'
        self.created_at = "2025-02-15 19:19:31"
        self.created_by = "SmartEdu-academy"
    
    def on_enter(self):
        """Called when screen is entered"""
        self._load_analytics()
    
    async def _load_analytics(self):
        """Load analytics data"""
        try:
            report = await self.performance_tracker.get_performance_report(
                self.auth_state.current_user['id'],
                self.current_time_range
            )
            self._update_dashboard(report)
        except Exception as e:
            self.show_error_dialog(str(e))
    
    def _update_dashboard(self, report):
        """Update dashboard with analytics data"""
        # Update overview metrics
        self.ids.total_time.text = f"{report['overview']['total_learning_time']['hours']}h {report['overview']['total_learning_time']['minutes']}m"
        self.ids.total_activities.text = str(report['overview']['total_activities_completed'])
        self.ids.active_subjects.text = str(report['overview']['active_subjects'])
        self.ids.current_streak.text = f"{report['overview']['current_streak']} days"
        
        # Update progress bars
        self.ids.overall_progress.value = report['overview']['overall_progress']
        self.ids.consistency_score.value = report['learning_patterns']['consistency_score'] * 100
        
        # Update subject performance
        self._update_subject_cards(report['subject_analysis'])
        
        # Update topic mastery
        self._update_topic_mastery(report['topic_mastery'])
        
        # Update skill progression
        self._update_skill_progress(report['skill_progression'])
        
        # Update recommendations
        self._update_recommendations(report['recommendations'])
    
    def _update_subject_cards(self, subject_data):
        """Update subject performance cards"""
        subjects_container = self.ids.subjects_container
        subjects_container.clear_widgets()
        
        for subject, data in subject_data.items():
            card = SubjectPerformanceCard(
                subject_name=subject,
                average_score=data['average_score'],
                proficiency=data['proficiency_level'],
                trend=data['score_trend'],
                time_spent=f"{data['time_invested']['hours']}h {data['time_invested']['minutes']}m"
            )
            subjects_container.add_widget(card)
    
    def _update_topic_mastery(self, mastery_data):
        """Update topic mastery section"""
        mastery_container = self.ids.topic_mastery_container
        mastery_container.clear_widgets()
        
        for category in ['mastered_topics', 'in_progress_topics', 'need_attention_topics']:
            for topic in mastery_data[category]:
                card = TopicMasteryCard(
                    topic_name=topic['name'],
                    mastery_level=topic['mastery_level'],
                    category=topic['category']
                )
                mastery_container.add_widget(card)
    
    def _update_skill_progress(self, skill_data):
        """Update skill progression section"""
        skills_container = self.ids.skills_container
        skills_container.clear_widgets()
        
        for skill, data in skill_data['skill_levels'].items():
            card = SkillProgressCard(
                skill_name=skill,
                current_level=data,
                progress=skill_data['skills_in_progress'].get(skill, 0),
                next_milestone=skill_data['next_level_predictions'].get(skill)
            )
            skills_container.add_widget(card)
    
    def _update_recommendations(self, recommendations):
        """Update recommendations section"""
        recommendations_container = self.ids.recommendations_container
        recommendations_container.clear_widgets()
        
        # Add focus areas
        for area in recommendations['focus_areas']:
            card = RecommendationCard(
                title=f"Focus on {area['subject']}",
                description=f"Current Score: {area['current_score']}%",
                suggested_activities=area['suggested_activities']
            )
            recommendations_container.add_widget(card)
        
        # Add study habits
        for habit in recommendations['study_habits']:
            card = RecommendationCard(
                title="Study Habit Suggestion",
                description=habit,
                icon="school"
            )
            recommendations_container.add_widget(card)
    
    def show_error_dialog(self, text):
        """Show error dialog"""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Error",
                text=text,
                buttons=[
                    MDRaisedButton(
                        text="OK",
                        on_release=lambda x: self.dialog.dismiss()
                    )
                ]
            )
        self.dialog.text = text
        self.dialog.open()

# Custom Widget Classes
class SubjectPerformanceCard(MDCard):
    def __init__(self, subject_name, average_score, proficiency, trend, time_spent, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = "15dp"
        self.spacing = "10dp"
        self.elevation = 2
        
        self.subject_name = subject_name
        self.average_score = average_score
        self.proficiency = proficiency
        self.trend = trend
        self.time_spent = time_spent

class TopicMasteryCard(MDCard):
    def __init__(self, topic_name, mastery_level, category, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = "15dp"
        self.spacing = "10dp"
        self.elevation = 2
        
        self.topic_name = topic_name
        self.mastery_level = mastery_level
        self.category = category

class SkillProgressCard(MDCard):
    def __init__(self, skill_name, current_level, progress, next_milestone, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = "15dp"
        self.spacing = "10dp"
        self.elevation = 2
        
        self.skill_name = skill_name
        self.current_level = current_level
        self.progress = progress
        self.next_milestone = next_milestone

class RecommendationCard(MDCard):
    def __init__(self, title, description, suggested_activities=None, icon=None, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = "15dp"
        self.spacing = "10dp"
        self.elevation = 2
        
        self.title = title
        self.description = description
        self.suggested_activities = suggested_activities
        self.icon = icon