from datetime import datetime
from ...data.firebase_manager import FirebaseManager
from ...data.cache_manager import CacheManager
from ..visualization.visualization_manager import VisualizationManager

class ParentMonitoringSystem:
    def __init__(self):
        self.firebase = FirebaseManager()
        self.cache = CacheManager()
        self.visualizer = VisualizationManager()
        self.created_at = "2025-02-15 19:41:40"
        self.created_by = "SmartEdu-academy"

    async def get_student_overview(self, parent_id, student_id):
        """Get comprehensive overview of student's progress"""
        try:
            cache_key = f"student_overview_{parent_id}_{student_id}"
            cached_overview = self.cache.get(cache_key)
            
            if cached_overview:
                return cached_overview
            
            # Verify parent-student relationship
            if not await self._verify_relationship(parent_id, student_id):
                raise ValueError("Unauthorized access: Parent-student relationship not verified")
            
            # Gather all relevant data
            overview = {
                'general_info': await self._get_student_info(student_id),
                'academic_progress': await self._get_academic_progress(student_id),
                'recent_activities': await self._get_recent_activities(student_id),
                'performance_metrics': await self._get_performance_metrics(student_id),
                'upcoming_tasks': await self._get_upcoming_tasks(student_id),
                'areas_of_concern': await self._identify_concerns(student_id),
                'recommendations': await self._generate_recommendations(student_id),
                'generated_at': datetime.utcnow().isoformat()
            }
            
            # Cache for 30 minutes
            self.cache.set(cache_key, overview, expires_in=1800)
            
            return overview
            
        except Exception as e:
            print(f"Error getting student overview: {str(e)}")
            raise

    async def set_monitoring_preferences(self, parent_id, student_id, preferences):
        """Set parent's monitoring preferences for a student"""
        try:
            if not await self._verify_relationship(parent_id, student_id):
                raise ValueError("Unauthorized access: Parent-student relationship not verified")
            
            monitoring_settings = {
                'notification_preferences': preferences.get('notifications', {}),
                'report_frequency': preferences.get('report_frequency', 'weekly'),
                'alert_thresholds': preferences.get('alert_thresholds', {}),
                'monitored_subjects': preferences.get('monitored_subjects', []),
                'updated_at': datetime.utcnow().isoformat()
            }
            
            await self.firebase.update_monitoring_preferences(
                parent_id,
                student_id,
                monitoring_settings
            )
            
            return monitoring_settings
            
        except Exception as e:
            print(f"Error setting monitoring preferences: {str(e)}")
            raise

    async def get_progress_report(self, parent_id, student_id, time_range=None):
        """Generate detailed progress report for parent"""
        try:
            if not await self._verify_relationship(parent_id, student_id):
                raise ValueError("Unauthorized access: Parent-student relationship not verified")
            
            cache_key = f"progress_report_{parent_id}_{student_id}_{time_range}"
            cached_report = self.cache.get(cache_key)
            
            if cached_report:
                return cached_report
            
            report = {
                'academic_performance': await self._get_academic_performance(student_id, time_range),
                'learning_patterns': await self._get_learning_patterns(student_id, time_range),
                'achievements': await self._get_achievements(student_id),
                'attendance': await self._get_attendance_data(student_id, time_range),
                'skill_development': await self._get_skill_development(student_id),
                'visualizations': await self._get_visualizations(student_id, time_range),
                'generated_at': datetime.utcnow().isoformat()
            }
            
            # Cache for 1 hour
            self.cache.set(cache_key, report, expires_in=3600)
            
            return report
            
        except Exception as e:
            print(f"Error generating progress report: {str(e)}")
            raise

    async def set_alerts(self, parent_id, student_id, alert_settings):
        """Configure alert settings for student monitoring"""
        try:
            if not await self._verify_relationship(parent_id, student_id):
                raise ValueError("Unauthorized access: Parent-student relationship not verified")
            
            alerts_config = {
                'performance_threshold': alert_settings.get('performance_threshold', 70),
                'absence_threshold': alert_settings.get('absence_threshold', 2),
                'inactivity_threshold': alert_settings.get('inactivity_threshold', 3),
                'achievement_alerts': alert_settings.get('achievement_alerts', True),
                'quiz_completion_alerts': alert_settings.get('quiz_completion_alerts', True),
                'updated_at': datetime.utcnow().isoformat()
            }
            
            await self.firebase.update_alert_settings(
                parent_id,
                student_id,
                alerts_config
            )
            
            return alerts_config
            
        except Exception as e:
            print(f"Error setting alerts: {str(e)}")
            raise

    async def get_intervention_suggestions(self, parent_id, student_id):
        """Get suggestions for parent intervention based on student performance"""
        try:
            if not await self._verify_relationship(parent_id, student_id):
                raise ValueError("Unauthorized access: Parent-student relationship not verified")
            
            performance_data = await self._get_performance_metrics(student_id)
            
            suggestions = []
            
            # Check for low performance areas
            for subject, data in performance_data.items():
                if data['average_score'] < 70:
                    suggestions.append({
                        'type': 'academic_support',
                        'subject': subject,
                        'current_score': data['average_score'],
                        'suggested_actions': [
                            'Schedule a parent-teacher conference',
                            'Consider additional tutoring support',
                            'Review study materials together',
                            'Set up a regular study schedule'
                        ]
                    })
            
            # Check study patterns
            study_patterns = await self._get_learning_patterns(student_id)
            if study_patterns['consistency_score'] < 0.7:
                suggestions.append({
                    'type': 'study_habits',
                    'concern': 'Inconsistent study patterns',
                    'suggested_actions': [
                        'Help establish a regular study routine',
                        'Create a dedicated study space',
                        'Set daily learning goals',
                        'Use the app\'s reminder features'
                    ]
                })
            
            return suggestions
            
        except Exception as e:
            print(f"Error getting intervention suggestions: {str(e)}")
            raise

    async def _verify_relationship(self, parent_id, student_id):
        """Verify parent-student relationship"""
        try:
            relationships = await self.firebase.get_parent_student_relationships(parent_id)
            return student_id in relationships
        except Exception as e:
            print(f"Error verifying relationship: {str(e)}")
            raise

    async def _get_student_info(self, student_id):
        """Get basic student information"""
        try:
            return await self.firebase.get_student_info(student_id)
        except Exception as e:
            print(f"Error getting student info: {str(e)}")
            raise

    async def _get_academic_progress(self, student_id):
        """Get academic progress data"""
        try:
            return await self.firebase.get_academic_progress(student_id)
        except Exception as e:
            print(f"Error getting academic progress: {str(e)}")
            raise

    async def _get_recent_activities(self, student_id):
        """Get recent learning activities"""
        try:
            return await self.firebase.get_recent_activities(student_id)
        except Exception as e:
            print(f"Error getting recent activities: {str(e)}")
            raise

    async def _get_performance_metrics(self, student_id):
        """Get detailed performance metrics"""
        try:
            return await self.firebase.get_performance_metrics(student_id)
        except Exception as e:
            print(f"Error getting performance metrics: {str(e)}")
            raise

    async def _get_upcoming_tasks(self, student_id):
        """Get upcoming learning tasks"""
        try:
            return await self.firebase.get_upcoming_tasks(student_id)
        except Exception as e:
            print(f"Error getting upcoming tasks: {str(e)}")
            raise

    async def _identify_concerns(self, student_id):
        """Identify areas of concern"""
        try:
            performance = await self._get_performance_metrics(student_id)
            concerns = []
            
            for subject, data in performance.items():
                if data['average_score'] < 70:
                    concerns.append({
                        'type': 'low_performance',
                        'subject': subject,
                        'score': data['average_score'],
                        'trend': data['trend']
                    })
            
            return concerns
        except Exception as e:
            print(f"Error identifying concerns: {str(e)}")
            raise

    async def _generate_recommendations(self, student_id):
        """Generate personalized recommendations"""
        try:
            concerns = await self._identify_concerns(student_id)
            return [
                {
                    'concern': concern['type'],
                    'subject': concern['subject'],
                    'recommendations': [
                        'Schedule additional practice sessions',
                        'Review fundamental concepts',
                        'Consider one-on-one tutoring'
                    ]
                }
                for concern in concerns
            ]
        except Exception as e:
            print(f"Error generating recommendations: {str(e)}")
            raise