from typing import List, Optional
from datetime import datetime
from firebase_admin import firestore
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.course import Course

class CourseService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.courses_ref = self.db.collection('courses')

    async def create_course(self, course_data: dict) -> Course:
        """Create a new course"""
        course_data.update({
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        })
        doc_ref = self.courses_ref.document()
        course_data['id'] = doc_ref.id
        course = Course.from_dict(course_data)
        await doc_ref.set(course.to_dict())
        return course

    async def get_course(self, course_id: str) -> Optional[Course]:
        """Get a course by ID"""
        doc = await self.courses_ref.document(course_id).get()
        return Course.from_dict(doc.to_dict()) if doc.exists else None

    async def update_course(self, course_id: str, updates: dict) -> bool:
        """Update a course"""
        updates['updated_at'] = datetime.utcnow()
        try:
            await self.courses_ref.document(course_id).update(updates)
            return True
        except Exception as e:
            print(f"Error updating course: {e}")
            return False

    async def delete_course(self, course_id: str) -> bool:
        """Delete a course"""
        try:
            await self.courses_ref.document(course_id).delete()
            return True
        except Exception as e:
            print(f"Error deleting course: {e}")
            return False

    async def list_courses(self, creator_id: Optional[str] = None) -> List[Course]:
        """List all courses, optionally filtered by creator"""
        query = self.courses_ref
        if creator_id:
            query = query.where('creator_id', '==', creator_id)
        
        docs = await query.get()
        return [Course.from_dict(doc.to_dict()) for doc in docs]