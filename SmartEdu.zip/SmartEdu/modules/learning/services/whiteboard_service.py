from typing import List, Tuple, Dict
import json
import base64
from dataclasses import dataclass, asdict
from datetime import datetime
from kivy.graphics import Color, Line, InstructionGroup
from kivy.core.image import Image as CoreImage
from io import BytesIO

@dataclass
class DrawingData:
    points: List[Tuple[float, float]]
    color: Tuple[float, float, float, float]
    thickness: float
    tool_type: str
    text_content: str = ""
    font_size: float = 14.0

class WhiteboardService:
    def __init__(self):
        self.history: List[DrawingData] = []
        self.current_drawing: DrawingData = None
        self.current_tool = "pen"
        self.current_color = (0, 0, 0, 1)  # Black
        self.current_thickness = 2.0
        self.shape_start_pos = None
        self.current_shape = None
        self.thickness_levels = [1.0, 2.0, 4.0, 6.0, 8.0]
        self.thickness_index = 1
        self.font_sizes = [12.0, 14.0, 16.0, 18.0, 24.0]
        self.font_size_index = 1

    def start_drawing(self, x: float, y: float):
        self.current_drawing = DrawingData(
            points=[(x, y)],
            color=self.current_color,
            thickness=self.current_thickness,
            tool_type=self.current_tool
        )

    def add_point(self, x: float, y: float):
        if self.current_drawing:
            self.current_drawing.points.append((x, y))

    def end_drawing(self):
        if self.current_drawing:
            self.history.append(self.current_drawing)
            self.current_drawing = None

    def start_shape(self, x: float, y: float, shape_type: str):
        self.shape_start_pos = (x, y)
        self.current_shape = shape_type

    def end_shape(self, end_x: float, end_y: float):
        if self.shape_start_pos:
            shape_data = DrawingData(
                points=[self.shape_start_pos, (end_x, end_y)],
                color=self.current_color,
                thickness=self.current_thickness,
                tool_type=self.current_shape
            )
            self.history.append(shape_data)
            self.shape_start_pos = None
            self.current_shape = None
            return shape_data
        return None

    def undo(self) -> bool:
        if self.history:
            self.history.pop()
            return True
        return False

    def clear(self):
        self.history.clear()
        self.current_drawing = None

    def set_tool(self, tool_type: str):
        self.current_tool = tool_type

    def set_color(self, color: Tuple[float, float, float, float]):
        self.current_color = color

    def set_thickness(self, thickness: float):
        self.current_thickness = thickness

    def cycle_thickness(self, forward=True):
        if forward:
            self.thickness_index = (self.thickness_index + 1) % len(self.thickness_levels)
        else:
            self.thickness_index = (self.thickness_index - 1) % len(self.thickness_levels)
        self.current_thickness = self.thickness_levels[self.thickness_index]
        return self.current_thickness

    def cycle_font_size(self, forward=True):
        if forward:
            self.font_size_index = (self.font_size_index + 1) % len(self.font_sizes)
        else:
            self.font_size_index = (self.font_size_index - 1) % len(self.font_sizes)
        return self.font_sizes[self.font_size_index]

    def add_text(self, x: float, y: float, text: str):
        text_data = DrawingData(
            points=[(x, y)],
            color=self.current_color,
            thickness=self.current_thickness,
            tool_type="text",
            text_content=text,
            font_size=self.font_sizes[self.font_size_index]
        )
        self.history.append(text_data)
        return text_data

    def save_whiteboard(self, filename: str) -> Dict:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        data = {
            "timestamp": timestamp,
            "drawings": [asdict(drawing) for drawing in self.history]
        }
        with open(f"{filename}_{timestamp}.json", "w") as f:
            json.dump(data, f)
        return data

    def load_whiteboard(self, filename: str) -> bool:
        try:
            with open(filename, "r") as f:
                data = json.load(f)
                self.history = [DrawingData(**drawing_data) for drawing_data in data["drawings"]]
                return True
        except Exception as e:
            print(f"Error loading whiteboard: {e}")
            return False

    def export_as_image(self, widget) -> str:
        texture = widget.export_as_image().texture
        image_bytes_io = BytesIO()
        CoreImage(texture).save(image_bytes_io, fmt='png')
        image_bytes = image_bytes_io.getvalue()
        return base64.b64encode(image_bytes).decode()

    def draw_shape_preview(self, canvas, end_x: float, end_y: float):
        if not self.shape_start_pos:
            return

        with canvas:
            Color(*self.current_color)
            if self.current_shape == 'rectangle':
                x1, y1 = self.shape_start_pos
                Line(rectangle=[x1, y1, end_x - x1, end_y - y1], width=self.current_thickness)
            elif self.current_shape == 'circle':
                import math
                x1, y1 = self.shape_start_pos
                radius = math.sqrt((end_x - x1)**2 + (end_y - y1)**2)
                Line(circle=(x1, y1, radius), width=self.current_thickness)
            elif self.current_shape == 'line':
                x1, y1 = self.shape_start_pos
                Line(points=[x1, y1, end_x, end_y], width=self.current_thickness)