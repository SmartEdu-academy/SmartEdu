from typing import List, Dict, Optional
from modules.learning.models.study_room import StudyRoom, RoomStatus, RoomType
from modules.core.local_db_manager import LocalDBManager
from modules.core.firebase_manager import FirebaseManager

class RoomService:
    def __init__(self):
        self.local_db = LocalDBManager()
        self.firebase = FirebaseManager()

    async def create_room(
        self,
        title: str,
        creator_id: str,
        room_type: RoomType,
        max_participants: int = 10,
        course_id: Optional[str] = None,
        description: Optional[str] = None,
        password: Optional[str] = None
    ) -> StudyRoom:
        room_id = self.firebase.generate_id()
        room = StudyRoom(
            room_id=room_id,
            title=title,
            creator_id=creator_id,
            room_type=room_type,
            max_participants=max_participants,
            course_id=course_id,
            description=description,
            password=password
        )
        await self.local_db.save_room(room.to_dict())
        await self.firebase.save_room(room.to_dict())
        return room

    async def get_room(self, room_id: str) -> Optional[StudyRoom]:
        room_data = await self.local_db.get_room(room_id)
        if not room_data:
            room_data = await self.firebase.get_room(room_id)
            if room_data:
                await self.local_db.save_room(room_data)
        if room_data:
            return StudyRoom(**room_data)
        return None

    async def update_room(self, room: StudyRoom) -> None:
        await self.local_db.save_room(room.to_dict())
        await self.firebase.save_room(room.to_dict())

    async def delete_room(self, room_id: str) -> bool:
        await self.local_db.delete_room(room_id)
        await self.firebase.delete_room(room_id)
        return True

    async def list_rooms(self, filter_params: Dict) -> List<StudyRoom]:
        room_list = await self.firebase.list_rooms(filter_params)
        for room_data in room_list:
            await self.local_db.save_room(room_data)
        return [StudyRoom(**room_data) for room_data in room_list]