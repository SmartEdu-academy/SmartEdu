from typing import List, Dict, Optional
import asyncio
import subprocess
import os
from datetime import datetime
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.media import Media

class VideoTranscodingService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.storage = storage.bucket()
        self.media_ref = self.db.collection('media')
        self.qualities = {
            '1080p': {'width': 1920, 'height': 1080, 'bitrate': '5000k'},
            '720p': {'width': 1280, 'height': 720, 'bitrate': '2500k'},
            '480p': {'width': 854, 'height': 480, 'bitrate': '1000k'},
            '360p': {'width': 640, 'height': 360, 'bitrate': '750k'}
        }
        self.output_path = '/tmp/transcoded_videos'
        os.makedirs(self.output_path, exist_ok=True)
    
    async def process_video(self, media_id: str) -> bool:
        """Process video into multiple qualities"""
        try:
            media = await self.get_media(media_id)
            if not media or media.type != 'video':
                raise ValueError("Invalid media or not a video")
            
            # Update status to processing
            await self.update_media_status(media_id, 'processing')
            
            # Download original video
            original_path = await self._download_video(media.url)
            
            # Get video metadata
            metadata = await self._get_video_metadata(original_path)
            
            # Determine available qualities based on original resolution
            available_qualities = self._get_available_qualities(
                metadata['width'],
                metadata['height']
            )
            
            # Transcode to different qualities
            transcoded_urls = {}
            for quality, params in available_qualities.items():
                output_path = f"{self.output_path}/{media_id}_{quality}.mp4"
                success = await self._transcode_video(
                    original_path,
                    output_path,
                    params
                )
                if success:
                    url = await self._upload_transcoded_video(
                        output_path,
                        media_id,
                        quality
                    )
                    transcoded_urls[quality] = url
            
            # Update media with transcoded URLs and metadata
            updates = {
                'transcoded_urls': transcoded_urls,
                'metadata': {
                    **media.metadata,
                    'duration_seconds': metadata['duration'],
                    'original_width': metadata['width'],
                    'original_height': metadata['height'],
                    'available_qualities': list(transcoded_urls.keys())
                },
                'encoding_status': 'completed'
            }
            
            await self.update_media(media_id, updates)
            
            # Cleanup temporary files
            self._cleanup_files(original_path)
            return True
            
        except Exception as e:
            print(f"Error processing video: {e}")
            await self.update_media_status(media_id, 'failed')
            return False
    
    async def _download_video(self, url: str) -> str:
        """Download video from URL to local path"""
        local_path = f"{self.output_path}/original_{datetime.now().timestamp()}.mp4"
        # Implementation for downloading video
        return local_path
    
    async def _get_video_metadata(self, video_path: str) -> Dict:
        """Get video metadata using ffprobe"""
        cmd = [
            'ffprobe',
            '-v', 'quiet',
            '-print_format', 'json',
            '-show_format',
            '-show_streams',
            video_path
        ]
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            raise Exception(f"Error getting video metadata: {stderr.decode()}")
            
        metadata = json.loads(stdout.decode())
        video_stream = next(
            s for s in metadata['streams'] if s['codec_type'] == 'video'
        )
        
        return {
            'width': int(video_stream['width']),
            'height': int(video_stream['height']),
            'duration': float(metadata['format']['duration'])
        }
    
    def _get_available_qualities(self, width: int, height: int) -> Dict:
        """Determine available qualities based on original resolution"""
        available = {}
        original_res = max(width, height)
        
        for quality, params in self.qualities.items():
            quality_res = max(params['width'], params['height'])
            if quality_res <= original_res:
                available[quality] = params
        
        return available
    
    async def _transcode_video(self, input_path: str, output_path: str, params: Dict) -> bool:
        """Transcode video to specific quality"""
        cmd = [
            'ffmpeg',
            '-i', input_path,
            '-c:v', 'libx264',
            '-b:v', params['bitrate'],
            '-maxrate', params['bitrate'],
            '-bufsize', f"{int(params['bitrate'][:-1])*2}k",
            '-vf', f"scale={params['width']}:{params['height']}",
            '-c:a', 'aac',
            '-b:a', '128k',
            '-preset', 'medium',
            '-y',
            output_path
        ]
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        return process.returncode == 0
    
    async def _upload_transcoded_video(self, video_path: str, media_id: str, quality: str) -> str:
        """Upload transcoded video to storage"""
        filename = f"{media_id}_{quality}.mp4"
        blob = self.storage.blob(f"media/videos/transcoded/{filename}")
        
        with open(video_path, 'rb') as file:
            blob.upload_from_file(file)
        
        blob.make_public()
        return blob.public_url
    
    def _cleanup_files(self, *paths: str):
        """Clean up temporary files"""
        for path in paths:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception as e:
                print(f"Error cleaning up file {path}: {e}")