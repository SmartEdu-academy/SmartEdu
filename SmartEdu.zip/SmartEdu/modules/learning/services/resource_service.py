from typing import List, Optional
from datetime import datetime
import mimetypes
from firebase_admin import storage
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.resource import Resource

class ResourceService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.storage = storage.bucket()
        self.resources_ref = self.db.collection('resources')
    
    async def create_resource(self, resource_data: dict, file_path: Optional[str] = None) -> Resource:
        """Create a new resource with optional file upload"""
        # Handle file upload if provided
        if file_path:
            url = await self._upload_file(file_path)
            resource_data['url'] = url
            resource_data['mime_type'] = mimetypes.guess_type(file_path)[0]
        
        resource_data.update({
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        })
        
        doc_ref = self.resources_ref.document()
        resource_data['id'] = doc_ref.id
        resource = Resource.from_dict(resource_data)
        await doc_ref.set(resource.to_dict())
        return resource
    
    async def get_resource(self, resource_id: str) -> Optional[Resource]:
        """Get a resource by ID"""
        doc = await self.resources_ref.document(resource_id).get()
        return Resource.from_dict(doc.to_dict()) if doc.exists else None
    
    async def update_resource(self, resource_id: str, updates: dict) -> bool:
        """Update a resource"""
        updates['updated_at'] = datetime.utcnow()
        try:
            await self.resources_ref.document(resource_id).update(updates)
            return True
        except Exception as e:
            print(f"Error updating resource: {e}")
            return False
    
    async def delete_resource(self, resource_id: str) -> bool:
        """Soft delete a resource by marking it as deleted"""
        try:
            await self.update_resource(resource_id, {'status': 'deleted'})
            return True
        except Exception as e:
            print(f"Error deleting resource: {e}")
            return False
    
    async def list_resources(self, filters: dict = None) -> List[Resource]:
        """List all active resources with optional filters"""
        query = self.resources_ref.where('status', '==', 'active')
        
        if filters:
            for key, value in filters.items():
                query = query.where(key, '==', value)
        
        docs = await query.get()
        return [Resource.from_dict(doc.to_dict()) for doc in docs]
    
    async def increment_download_count(self, resource_id: str) -> bool:
        """Increment the download count for a resource"""
        try:
            await self.resources_ref.document(resource_id).update({
                'download_count': firestore.Increment(1)
            })
            return True
        except Exception as e:
            print(f"Error incrementing download count: {e}")
            return False
    
    async def _upload_file(self, file_path: str) -> str:
        """Upload a file to Firebase Storage and return its public URL"""
        try:
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            filename = f"{timestamp}_{file_path.split('/')[-1]}"
            blob = self.storage.blob(f"resources/{filename}")
            
            with open(file_path, 'rb') as file:
                blob.upload_from_file(file)
            
            blob.make_public()
            return blob.public_url
        except Exception as e:
            raise Exception(f"Error uploading file: {str(e)}")