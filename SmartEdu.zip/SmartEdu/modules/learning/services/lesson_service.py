from typing import List, Optional
from datetime import datetime
from firebase_admin import firestore
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.lesson import Lesson

class LessonService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.lessons_ref = self.db.collection('lessons')
    
    async def create_lesson(self, lesson_data: dict) -> Lesson:
        """Create a new lesson"""
        lesson_data.update({
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        })
        doc_ref = self.lessons_ref.document()
        lesson_data['id'] = doc_ref.id
        lesson = Lesson.from_dict(lesson_data)
        await doc_ref.set(lesson.to_dict())
        return lesson
    
    async def get_lesson(self, lesson_id: str) -> Optional[Lesson]:
        """Get a lesson by ID"""
        doc = await self.lessons_ref.document(lesson_id).get()
        return Lesson.from_dict(doc.to_dict()) if doc.exists else None
    
    async def update_lesson(self, lesson_id: str, updates: dict) -> bool:
        """Update a lesson"""
        updates['updated_at'] = datetime.utcnow()
        try:
            await self.lessons_ref.document(lesson_id).update(updates)
            return True
        except Exception as e:
            print(f"Error updating lesson: {e}")
            return False
    
    async def delete_lesson(self, lesson_id: str) -> bool:
        """Delete a lesson"""
        try:
            await self.lessons_ref.document(lesson_id).delete()
            return True
        except Exception as e:
            print(f"Error deleting lesson: {e}")
            return False
    
    async def list_course_lessons(self, course_id: str) -> List[Lesson]:
        """List all lessons for a course, ordered by their sequence"""
        docs = await self.lessons_ref.where(
            'course_id', '==', course_id
        ).order_by('order').get()
        return [Lesson.from_dict(doc.to_dict()) for doc in docs]