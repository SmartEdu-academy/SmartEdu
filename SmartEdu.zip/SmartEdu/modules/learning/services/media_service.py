from typing import List, Optional
from datetime import datetime
import mimetypes
import os
from firebase_admin import storage
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.media import Media

class MediaService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.storage = storage.bucket()
        self.media_ref = self.db.collection('media')
        self.supported_types = {
            'video': ['.mp4', '.webm', '.mov'],
            'audio': ['.mp3', '.wav', '.ogg'],
            'image': ['.jpg', '.jpeg', '.png', '.gif'],
            'document': ['.pdf', '.doc', '.docx', '.ppt', '.pptx']
        }
    
    async def upload_media(self, file_path: str, title: Optional[str] = None) -> Media:
        """Upload a media file and create its record"""
        file_ext = os.path.splitext(file_path)[1].lower()
        media_type = self._get_media_type(file_ext)
        
        if not media_type:
            raise ValueError(f"Unsupported file type: {file_ext}")
        
        try:
            # Upload file to Firebase Storage
            url = await self._upload_file(file_path, media_type)
            
            # Create media record
            media_data = {
                'title': title or os.path.basename(file_path),
                'type': media_type,
                'url': url,
                'created_by': 'system',  # TODO: Get from auth
                'size_bytes': os.path.getsize(file_path),
                'metadata': {
                    'original_name': os.path.basename(file_path),
                    'mime_type': mimetypes.guess_type(file_path)[0]
                }
            }
            
            if media_type == 'video':
                # TODO: Implement video processing for different qualities
                media_data['encoding_status'] = 'processing'
            
            return await self.create_media(media_data)
        except Exception as e:
            raise Exception(f"Error uploading media: {str(e)}")
    
    async def create_media(self, media_data: dict) -> Media:
        """Create a new media record"""
        media_data.update({
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        })
        doc_ref = self.media_ref.document()
        media_data['id'] = doc_ref.id
        media = Media.from_dict(media_data)
        await doc_ref.set(media.to_dict())
        return media
    
    async def get_media(self, media_id: str) -> Optional[Media]:
        """Get media by ID"""
        doc = await self.media_ref.document(media_id).get()
        return Media.from_dict(doc.to_dict()) if doc.exists else None
    
    async def update_media(self, media_id: str, updates: dict) -> bool:
        """Update media record"""
        updates['updated_at'] = datetime.utcnow()
        try:
            await self.media_ref.document(media_id).update(updates)
            return True
        except Exception as e:
            print(f"Error updating media: {e}")
            return False
    
    async def delete_media(self, media_id: str) -> bool:
        """Soft delete media by marking it as deleted"""
        try:
            await self.update_media(media_id, {'status': 'deleted'})
            return True
        except Exception as e:
            print(f"Error deleting media: {e}")
            return False
    
    async def list_media(self, media_type: Optional[str] = None) -> List[Media]:
        """List all active media, optionally filtered by type"""
        query = self.media_ref.where('status', '==', 'active')
        
        if media_type:
            query = query.where('type', '==', media_type)
        
        docs = await query.order_by('created_at', direction='desc').get()
        return [Media.from_dict(doc.to_dict()) for doc in docs]
    
    def _get_media_type(self, file_ext: str) -> Optional[str]:
        """Determine media type from file extension"""
        for media_type, extensions in self.supported_types.items():
            if file_ext in extensions:
                return media_type
        return None
    
    async def _upload_file(self, file_path: str, media_type: str) -> str:
        """Upload file to Firebase Storage and return its public URL"""
        try:
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            filename = f"{timestamp}_{os.path.basename(file_path)}"
            blob = self.storage.blob(f"media/{media_type}/{filename}")
            
            with open(file_path, 'rb') as file:
                blob.upload_from_file(file)
            
            blob.make_public()
            return blob.public_url
        except Exception as e:
            raise Exception(f"Error uploading file: {str(e)}")