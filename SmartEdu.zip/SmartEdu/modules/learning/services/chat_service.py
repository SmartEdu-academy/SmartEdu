from typing import List, Dict, Optional
from datetime import datetime
from modules.core.local_db_manager import LocalDBManager
from modules.core.firebase_manager import FirebaseManager

class ChatService:
    def __init__(self):
        self.local_db = LocalDBManager()
        self.firebase = FirebaseManager()

    async def send_message(
        self,
        session_id: str,
        room_id: str,
        user_id: str,
        message: str
    ) -> Dict:
        message_data = {
            'session_id': session_id,
            'room_id': room_id,
            'user_id': user_id,
            'message': message,
            'timestamp': datetime.utcnow().isoformat()
        }
        await self.local_db.save_message(message_data)
        await self.firebase.save_message(message_data)
        return message_data

    async def get_messages(self, session_id: str, room_id: str) -> List[Dict]:
        message_list = await self.firebase.get_messages(session_id, room_id)
        for message_data in message_list:
            await self.local_db.save_message(message_data)
        return message_list

    async def delete_message(self, message_id: str) -> bool:
        await self.local_db.delete_message(message_id)
        await self.firebase.delete_message(message_id)
        return True