from firebase_admin import firestore
from typing import List, Optional
from ..models.live_session import LiveSession

class LiveSessionService:
    def __init__(self):
        self.db = firestore.client()
        self.sessions = self.db.collection('live_sessions')

    async def create_session(self, title: str, host_id: str) -> str:
        session = LiveSession(title, host_id)
        await self.sessions.document(session.id).set(session.__dict__)
        return session.id

    async def get_session(self, session_id: str) -> Optional[LiveSession]:
        doc = await self.sessions.document(session_id).get()
        if doc.exists:
            return LiveSession(**doc.to_dict())
        return None

    async def start_session(self, session_id: str):
        session = await self.get_session(session_id)
        if session:
            session.start()
            await self.sessions.document(session_id).update(session.__dict__)

    async def end_session(self, session_id: str):
        session = await self.get_session(session_id)
        if session:
            session.end()
            await self.sessions.document(session_id).update(session.__dict__)

    # New methods for added features
    async def add_participant(self, session_id: str, user_id: str):
        session = await self.get_session(session_id)
        if session:
            session.add_participant(user_id)
            await self.sessions.document(session_id).update(session.__dict__)

    async def remove_participant(self, session_id: str, user_id: str):
        session = await self.get_session(session_id)
        if session:
            session.remove_participant(user_id)
            await self.sessions.document(session_id).update(session.__dict__)

    async def add_chat_message(self, session_id: str, user_id: str, message: str):
        session = await self.get_session(session_id)
        if session:
            session.add_chat_message(user_id, message)
            await self.sessions.document(session_id).update(session.__dict__)

    async def toggle_hand_raise(self, session_id: str, user_id: str):
        session = await self.get_session(session_id)
        if session:
            is_raised = session.toggle_hand_raise(user_id)
            await self.sessions.document(session_id).update(session.__dict__)
            return is_raised