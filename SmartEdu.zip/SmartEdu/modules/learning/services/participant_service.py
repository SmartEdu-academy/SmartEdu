from typing import List, Dict, Optional
from modules.learning.models.participant import RoomParticipant, ParticipantRole, ParticipantStatus
from modules.core.local_db_manager import LocalDBManager
from modules.core.firebase_manager import FirebaseManager

class ParticipantService:
    def __init__(self):
        self.local_db = LocalDBManager()
        self.firebase = FirebaseManager()

    async def add_participant(
        self,
        room_id: str,
        user_id: str,
        role: ParticipantRole = ParticipantRole.STUDENT,
        display_name: Optional[str] = None
    ) -> RoomParticipant:
        participant = RoomParticipant(
            user_id=user_id,
            room_id=room_id,
            role=role,
            display_name=display_name
        )
        await self.local_db.save_participant(participant.to_dict())
        await self.firebase.save_participant(participant.to_dict())
        return participant

    async def get_participant(self, room_id: str, user_id: str) -> Optional[RoomParticipant]:
        participant_data = await self.local_db.get_participant(room_id, user_id)
        if not participant_data:
            participant_data = await self.firebase.get_participant(room_id, user_id)
            if participant_data:
                await self.local_db.save_participant(participant_data)
        if participant_data:
            return RoomParticipant(**participant_data)
        return None

    async def update_participant(self, participant: RoomParticipant) -> None:
        await self.local_db.save_participant(participant.to_dict())
        await self.firebase.save_participant(participant.to_dict())

    async def remove_participant(self, room_id: str, user_id: str) -> bool:
        await self.local_db.delete_participant(room_id, user_id)
        await self.firebase.delete_participant(room_id, user_id)
        return True

    async def list_participants(self, room_id: str) -> List<RoomParticipant]:
        participant_list = await self.firebase.list_participants(room_id)
        for participant_data in participant_list:
            await self.local_db.save_participant(participant_data)
        return [RoomParticipant(**participant_data) for participant_data in participant_list]