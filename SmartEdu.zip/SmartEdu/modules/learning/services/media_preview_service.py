from typing import Dict, Optional
from PIL import Image
import os
from datetime import datetime
from modules.core.firebase_manager import FirebaseManager

class MediaPreviewService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.storage = storage.bucket()
        self.thumbnail_sizes = {
            'small': (150, 150),
            'medium': (300, 300),
            'large': (600, 600)
        }
        self.temp_path = '/tmp/media_previews'
        os.makedirs(self.temp_path, exist_ok=True)
    
    async def generate_preview(self, media_id: str) -> Dict[str, str]:
        """Generate previews for media"""
        try:
            media = await self.get_media(media_id)
            if not media:
                raise ValueError("Media not found")
            
            preview_urls = {}
            
            if media.type == 'image':
                preview_urls = await self._generate_image_previews(media)
            elif media.type == 'video':
                preview_urls = await self._generate_video_previews(media)
            elif media.type == 'document':
                preview_urls = await self._generate_document_previews(media)
            
            # Update media with preview URLs
            if preview_urls:
                await self.update_media(media_id, {
                    'preview_urls': preview_urls,
                    'updated_at': datetime.utcnow()
                })
            
            return preview_urls
            
        except Exception as e:
            print(f"Error generating preview: {e}")
            return {}
    
    async def _generate_image_previews(self, media: Media) -> Dict[str, str]:
        """Generate image thumbnails"""
        try:
            # Download original image
            local_path = await self._download_file(media.url)
            
            # Generate thumbnails
            preview_urls = {}
            with Image.open(local_path) as img:
                for size_name, dimensions in self.thumbnail_sizes.items():
                    thumbnail = self._create_thumbnail(img, dimensions)
                    output_path = f"{self.temp_path}/{media.id}_{size_name}.jpg"
                    thumbnail.save(output_path, 'JPEG')
                    
                    # Upload thumbnail
                    url = await self._upload_preview(
                        output_path,
                        f"previews/images/{media.id}_{size_name}.jpg"
                    )
                    preview_urls[size_name] = url
            
            # Cleanup
            self._cleanup_files(local_path)
            return preview_urls
            
        except Exception as e:
            print(f"Error generating image previews: {e}")
            return {}
    
    def _create_thumbnail(self, image: Image, size: tuple) -> Image:
        """Create a thumbnail maintaining aspect ratio"""
        image.thumbnail(size, Image.LANCZOS)
        return image
    
    async def _generate_video_previews(self, media: Media) -> Dict[str, str]:
        """Generate video thumbnails"""
        try:
            # Extract frame from middle of video
            frame_path = await self._extract_video_frame(media.url)
            
            # Generate thumbnails from frame
            preview_urls = {}
            with Image.open(frame_path) as img:
                for size_name, dimensions in self.thumbnail_sizes.items():
                    thumbnail = self._create_thumbnail(img, dimensions)
                    output_path = f"{self.temp_path}/{media.id}_{size_name}.jpg"
                    thumbnail.save(output_path, 'JPEG')
                    
                    # Upload thumbnail
                    url = await self._upload_preview(
                        output_path,
                        f"previews/videos/{media.id}_{size_name}.jpg"
                    )
                    preview_urls[size_name] = url
            
            # Cleanup
            self._cleanup_files(frame_path)
            return preview_urls
            
        except Exception as e:
            print(f"Error generating video previews: {e}")
            return {}
    
    async def _extract_video_frame(self, video_url: str) -> str:
        """Extract a frame from the middle of a video"""
        # Implementation for extracting video frame
        pass
    
    async def _generate_document_previews(self, media: Media) -> Dict[str, str]:
        """Generate document previews"""
        # Implementation for document preview generation
        pass