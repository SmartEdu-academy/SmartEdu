from PIL import Image
import io
import os

class ImageOptimizer:
    def __init__(self):
        self.supported_formats = ['JPEG', 'PNG', 'WebP']
        self.quality_presets = {
            'high': 95,
            'medium': 85,
            'low': 75
        }

    def optimize_image(self, image_path, quality='medium', max_size=(1920, 1080)):
        try:
            # Open image
            with Image.open(image_path) as img:
                # Convert to RGB if needed
                if img.mode in ('RGBA', 'P'):
                    img = img.convert('RGB')
                
                # Resize if larger than max_size
                if img.size[0] > max_size[0] or img.size[1] > max_size[1]:
                    img.thumbnail(max_size, Image.LANCZOS)

                # Prepare output path
                filename, ext = os.path.splitext(image_path)
                output_path = f"{filename}_optimized{ext}"

                # Save optimized image
                img.save(output_path, 
                        quality=self.quality_presets[quality],
                        optimize=True)

                return output_path

        except Exception as e:
            raise Exception(f"Image optimization failed: {str(e)}")