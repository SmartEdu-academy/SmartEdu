import os
from typing import List, Dict, Union
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import zipfile
import json

class ExportManager:
    def __init__(self):
        self.supported_formats = ['pdf', 'zip', 'json']
        self.export_dir = 'exports'
        
        if not os.path.exists(self.export_dir):
            os.makedirs(self.export_dir)

    def export_to_pdf(self, 
                     data: Dict[str, any], 
                     filename: str) -> str:
        """Export data to PDF format"""
        try:
            output_path = os.path.join(self.export_dir, f"{filename}.pdf")
            doc = SimpleDocTemplate(output_path, pagesize=letter)
            styles = getSampleStyleSheet()
            story = []

            # Add title
            story.append(Paragraph(data.get('title', 'Export Document'), 
                                 styles['Heading1']))
            story.append(Spacer(1, 12))

            # Add content
            for item in data.get('content', []):
                if isinstance(item, str):
                    story.append(Paragraph(item, styles['Normal']))
                    story.append(Spacer(1, 6))

            doc.build(story)
            return output_path

        except Exception as e:
            raise Exception(f"PDF export failed: {str(e)}")

    def create_zip_archive(self, 
                          files: List[str], 
                          archive_name: str) -> str:
        """Create ZIP archive from multiple files"""
        try:
            output_path = os.path.join(self.export_dir, f"{archive_name}.zip")
            
            with zipfile.ZipFile(output_path, 'w') as zipf:
                for file in files:
                    if os.path.exists(file):
                        zipf.write(file, os.path.basename(file))

            return output_path

        except Exception as e:
            raise Exception(f"ZIP archive creation failed: {str(e)}")

    def export_to_json(self, 
                      data: Dict[str, any], 
                      filename: str) -> str:
        """Export data to JSON format"""
        try:
            output_path = os.path.join(self.export_dir, f"{filename}.json")
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            return output_path

        except Exception as e:
            raise Exception(f"JSON export failed: {str(e)}")