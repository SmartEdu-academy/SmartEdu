from typing import List, Dict, Optional
from datetime import datetime
from modules.core.local_db_manager import LocalDBManager
from modules.core.firebase_manager import FirebaseManager

class CollaborationService:
    def __init__(self):
        self.local_db = LocalDBManager()
        self.firebase = FirebaseManager()

    async def share_resource(
        self,
        session_id: str,
        room_id: str,
        user_id: str,
        resource: Dict
    ) -> Dict:
        resource_data = {
            'session_id': session_id,
            'room_id': room_id,
            'user_id': user_id,
            'resource': resource,
            'shared_at': datetime.utcnow().isoformat()
        }
        await self.local_db.save_resource(resource_data)
        await self.firebase.save_resource(resource_data)
        return resource_data

    async def get_shared_resources(self, session_id: str, room_id: str) -> List[Dict]:
        resource_list = await self.firebase.get_shared_resources(session_id, room_id)
        for resource_data in resource_list:
            await self.local_db.save_resource(resource_data)
        return resource_list

    async def delete_resource(self, resource_id: str) -> bool:
        await self.local_db.delete_resource(resource_id)
        await self.firebase.delete_resource(resource_id)
        return True