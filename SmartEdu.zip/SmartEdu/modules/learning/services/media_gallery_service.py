from typing import List, Optional
from datetime import datetime
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.media_gallery import MediaGallery
from modules.learning.services.media_service import MediaService

class MediaGalleryService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.galleries_ref = self.db.collection('media_galleries')
        self.media_service = MediaService()
    
    async def create_gallery(self, gallery_data: dict) -> MediaGallery:
        """Create a new media gallery"""
        gallery_data.update({
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        })
        
        doc_ref = self.galleries_ref.document()
        gallery_data['id'] = doc_ref.id
        
        # Set thumbnail from first media if not provided
        if not gallery_data.get('thumbnail_url') and gallery_data.get('media_ids'):
            first_media = await self.media_service.get_media(gallery_data['media_ids'][0])
            if first_media:
                gallery_data['thumbnail_url'] = first_media.thumbnail_url
        
        gallery = MediaGallery.from_dict(gallery_data)
        await doc_ref.set(gallery.to_dict())
        return gallery
    
    async def get_gallery(self, gallery_id: str) -> Optional[MediaGallery]:
        """Get a gallery by ID"""
        doc = await self.galleries_ref.document(gallery_id).get()
        return MediaGallery.from_dict(doc.to_dict()) if doc.exists else None
    
    async def update_gallery(self, gallery_id: str, updates: dict) -> bool:
        """Update a gallery"""
        updates['updated_at'] = datetime.utcnow()
        try:
            await self.galleries_ref.document(gallery_id).update(updates)
            return True
        except Exception as e:
            print(f"Error updating gallery: {e}")
            return False
    
    async def delete_gallery(self, gallery_id: str) -> bool:
        """Soft delete a gallery"""
        try:
            await self.update_gallery(gallery_id, {'status': 'deleted'})
            return True
        except Exception as e:
            print(f"Error deleting gallery: {e}")
            return False
    
    async def list_galleries(self, user_id: str = None, visibility: str = None) -> List[MediaGallery]:
        """List galleries with optional filters"""
        query = self.galleries_ref.where('status', '==', 'active')
        
        if user_id:
            query = query.where('created_by', '==', user_id)
        if visibility:
            query = query.where('visibility', '==', visibility)
        
        docs = await query.order_by('created_at', direction='desc').get()
        return [MediaGallery.from_dict(doc.to_dict()) for doc in docs]
    
    async def add_media_to_gallery(self, gallery_id: str, media_id: str) -> bool:
        """Add media to gallery"""
        try:
            gallery = await self.get_gallery(gallery_id)
            if not gallery:
                return False
            
            media_ids = gallery.media_ids or []
            if media_id not in media_ids:
                media_ids.append(media_id)
                await self.update_gallery(gallery_id, {'media_ids': media_ids})
            return True
        except Exception as e:
            print(f"Error adding media to gallery: {e}")
            return False
    
    async def remove_media_from_gallery(self, gallery_id: str, media_id: str) -> bool:
        """Remove media from gallery"""
        try:
            gallery = await self.get_gallery(gallery_id)
            if not gallery or not gallery.media_ids:
                return False
            
            if media_id in gallery.media_ids:
                gallery.media_ids.remove(media_id)
                await self.update_gallery(gallery_id, {'media_ids': gallery.media_ids})
            return True
        except Exception as e:
            print(f"Error removing media from gallery: {e}")
            return False