import ffmpeg
import os

class VideoOptimizer:
    def __init__(self):
        self.quality_presets = {
            'high': {'crf': '18', 'preset': 'slow'},
            'medium': {'crf': '23', 'preset': 'medium'},
            'low': {'crf': '28', 'preset': 'fast'}
        }

    def optimize_video(self, video_path, quality='medium', max_resolution='1080p'):
        try:
            # Prepare output path
            filename, ext = os.path.splitext(video_path)
            output_path = f"{filename}_optimized{ext}"

            # Get video info
            probe = ffmpeg.probe(video_path)
            video_info = next(s for s in probe['streams'] if s['codec_type'] == 'video')
            
            # Set resolution
            width = int(video_info['width'])
            height = int(video_info['height'])
            
            if max_resolution == '1080p' and height > 1080:
                height = 1080
                width = width * 1080 // height

            # Run optimization
            stream = ffmpeg.input(video_path)
            stream = ffmpeg.output(stream, output_path,
                                 vcodec='libx264',
                                 acodec='aac',
                                 **self.quality_presets[quality],
                                 video_bitrate='2000k',
                                 audio_bitrate='128k',
                                 s=f'{width}x{height}')
            
            ffmpeg.run(stream, overwrite_output=True)
            return output_path

        except Exception as e:
            raise Exception(f"Video optimization failed: {str(e)}")