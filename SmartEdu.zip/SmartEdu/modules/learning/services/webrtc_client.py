import asyncio
from aiortc import MediaStreamTrack, RTCPeerConnection, RTCSessionDescription
from aiortc.contrib.media import MediaPlayer, MediaRecorder

class WebRTCClient:
    def __init__(self, screen):
        self.screen = screen
        self.pc = None
        self.local_track = None
        self.remote_track = None

    async def start(self):
        self.pc = RTCPeerConnection()
        
        # Set up local media
        self.local_track = MediaStreamTrack.from_camera()
        self.pc.addTrack(self.local_track)

        # Handle incoming media
        @self.pc.on("track")
        async def on_track(track):
            self.remote_track = track
            # Handle remote track

        # Connection state changes
        @self.pc.on("connectionstatechange")
        async def on_connectionstatechange():
            self.screen.on_connection_state(self.pc.connectionState)

    def toggle_audio(self, enabled):
        if self.local_track:
            self.local_track.enabled = enabled

    def toggle_video(self, enabled):
        if self.local_track:
            self.local_track.enabled = enabled

    async def stop(self):
        if self.pc:
            await self.pc.close()
            self.pc = None
        if self.local_track:
            self.local_track.stop()
            self.local_track = None