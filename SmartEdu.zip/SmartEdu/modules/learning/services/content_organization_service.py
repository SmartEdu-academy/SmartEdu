from typing import List, Dict, Optional
from datetime import datetime
from firebase_admin import firestore
from modules.core.firebase_manager import FirebaseManager
from modules.learning.models.content_organization import ContentSection

class ContentOrganizationService:
    def __init__(self):
        self.db = FirebaseManager().db
        self.sections_ref = self.db.collection('content_sections')
    
    async def create_section(self, section_data: dict) -> ContentSection:
        """Create a new content section"""
        section_data.update({
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        })
        doc_ref = self.sections_ref.document()
        section_data['id'] = doc_ref.id
        section = ContentSection.from_dict(section_data)
        await doc_ref.set(section.to_dict())
        return section
    
    async def get_section(self, section_id: str) -> Optional[ContentSection]:
        """Get a section by ID"""
        doc = await self.sections_ref.document(section_id).get()
        return ContentSection.from_dict(doc.to_dict()) if doc.exists else None
    
    async def update_section(self, section_id: str, updates: dict) -> bool:
        """Update a section"""
        updates['updated_at'] = datetime.utcnow()
        try:
            await self.sections_ref.document(section_id).update(updates)
            return True
        except Exception as e:
            print(f"Error updating section: {e}")
            return False
    
    async def delete_section(self, section_id: str) -> bool:
        """Soft delete a section"""
        try:
            await self.update_section(section_id, {'status': 'deleted'})
            return True
        except Exception as e:
            print(f"Error deleting section: {e}")
            return False
    
    async def list_course_sections(self, course_id: str) -> List[ContentSection]:
        """List all sections for a course, ordered by their sequence"""
        docs = await self.sections_ref.where(
            'course_id', '==', course_id
        ).where(
            'status', '==', 'active'
        ).order_by('order').get()
        return [ContentSection.from_dict(doc.to_dict()) for doc in docs]
    
    async def reorder_sections(self, course_id: str, section_orders: Dict[str, int]) -> bool:
        """Update the order of multiple sections"""
        batch = self.db.batch()
        try:
            for section_id, order in section_orders.items():
                section_ref = self.sections_ref.document(section_id)
                batch.update(section_ref, {
                    'order': order,
                    'updated_at': datetime.utcnow()
                })
            await batch.commit()
            return True
        except Exception as e:
            print(f"Error reordering sections: {e}")
            return False