import redis
import json
import hashlib
from datetime import timedelta

class CacheManager:
    def __init__(self):
        self.redis_client = redis.Redis(
            host='localhost',
            port=6379,
            db=0,
            decode_responses=True
        )
        self.default_expiry = timedelta(hours=24)

    def generate_key(self, data):
        """Generate a unique cache key"""
        if isinstance(data, dict):
            data = json.dumps(data, sort_keys=True)
        return hashlib.md5(str(data).encode()).hexdigest()

    def set_cache(self, key, data, expiry=None):
        """Store data in cache"""
        try:
            if expiry is None:
                expiry = self.default_expiry
            
            serialized_data = json.dumps(data)
            self.redis_client.setex(
                key,
                expiry,
                serialized_data
            )
            return True
        except Exception as e:
            print(f"Cache storage failed: {str(e)}")
            return False

    def get_cache(self, key):
        """Retrieve data from cache"""
        try:
            data = self.redis_client.get(key)
            if data:
                return json.loads(data)
            return None
        except Exception as e:
            print(f"Cache retrieval failed: {str(e)}")
            return None

    def clear_cache(self, pattern="*"):
        """Clear cache entries matching pattern"""
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                self.redis_client.delete(*keys)
            return True
        except Exception as e:
            print(f"Cache clearing failed: {str(e)}")
            return False