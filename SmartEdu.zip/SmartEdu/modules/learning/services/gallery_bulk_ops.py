from typing import List, Dict, Union
from .media_service import MediaService
from .media_gallery_service import MediaGalleryService
from ..models.media import Media
from ..models.media_gallery import MediaGallery

class GalleryBulkOperations:
    def __init__(self):
        self.media_service = MediaService()
        self.gallery_service = MediaGalleryService()

    async def bulk_move(self, 
                       media_ids: List[str], 
                       source_gallery_id: str, 
                       target_gallery_id: str) -> Dict[str, Union[bool, str]]:
        """Move multiple media items between galleries"""
        try:
            # Verify source and target galleries exist
            source_gallery = await self.gallery_service.get_gallery(source_gallery_id)
            target_gallery = await self.gallery_service.get_gallery(target_gallery_id)

            if not source_gallery or not target_gallery:
                raise ValueError("Source or target gallery not found")

            # Move each media item
            results = []
            for media_id in media_ids:
                result = await self.media_service.move_media(
                    media_id=media_id,
                    source_gallery_id=source_gallery_id,
                    target_gallery_id=target_gallery_id
                )
                results.append(result)

            return {
                "success": all(r.get("success", False) for r in results),
                "message": f"Moved {len(results)} items successfully",
                "details": results
            }

        except Exception as e:
            return {
                "success": False,
                "message": str(e),
                "details": []
            }

    async def bulk_delete(self, 
                         media_ids: List[str], 
                         gallery_id: str) -> Dict[str, Union[bool, str]]:
        """Delete multiple media items from a gallery"""
        try:
            results = []
            for media_id in media_ids:
                result = await self.media_service.delete_media(
                    media_id=media_id,
                    gallery_id=gallery_id
                )
                results.append(result)

            return {
                "success": all(r.get("success", False) for r in results),
                "message": f"Deleted {len(results)} items successfully",
                "details": results
            }

        except Exception as e:
            return {
                "success": False,
                "message": str(e),
                "details": []
            }

    async def bulk_tag(self, 
                      media_ids: List[str], 
                      tags: List[str]) -> Dict[str, Union[bool, str]]:
        """Add tags to multiple media items"""
        try:
            results = []
            for media_id in media_ids:
                result = await self.media_service.add_tags(
                    media_id=media_id,
                    tags=tags
                )
                results.append(result)

            return {
                "success": all(r.get("success", False) for r in results),
                "message": f"Tagged {len(results)} items successfully",
                "details": results
            }

        except Exception as e:
            return {
                "success": False,
                "message": str(e),
                "details": []
            }