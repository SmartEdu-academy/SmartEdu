from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.list import MDList
from kivymd.uix.card import MDCard
from kivymd.toast import toast
from modules.learning.services.content_organization_service import ContentOrganizationService
from modules.auth.auth_middleware import AuthMiddleware

class ContentSectionItem(MDCard):
    def __init__(self, section_data: dict, **kwargs):
        super().__init__(**kwargs)
        self.section_id = section_data.get('id')
        self.title = section_data.get('title')
        self.lesson_ids = section_data.get('lesson_ids', [])
        self.resource_ids = section_data.get('resource_ids', [])
        self.parent_screen = None
    
    def edit_section(self):
        """Show edit section dialog"""
        if self.parent_screen:
            self.parent_screen.show_edit_section_dialog(self.section_id)
    
    def delete_section(self):
        """Delete the section"""
        if self.parent_screen:
            self.parent_screen.delete_section(self.section_id)

class ContentOrganizerScreen(MDScreen):
    def __init__(self, course_id: str, **kwargs):
        super().__init__(**kwargs)
        self.course_id = course_id
        self.content_organization_service = ContentOrganizationService()
        self.load_sections()
    
    def on_enter(self):
        """Called when the screen is entered"""
        if not AuthMiddleware.is_authenticated():
            self.go_back()
            toast("Please login to organize content")
    
    def go_back(self):
        """Navigate back to course screen"""
        self.manager.current = 'course_view'
    
    async def load_sections(self):
        """Load course sections"""
        try:
            sections = await self.content_organization_service.list_course_sections(self.course_id)
            sections_list = self.ids.sections_list
            sections_list.clear_widgets()
            
            for section in sections:
                section_item = ContentSectionItem(section.to_dict())
                section_item.parent_screen = self
                sections_list.add_widget(section_item)
        except Exception as e:
            toast(f"Error loading sections: {str(e)}")
    
    def show_add_section_dialog(self):
        """Show dialog to add new section"""
        self.dialog = MDDialog(
            title="Add Section",
            type="custom",
            content_cls=MDList(),
            buttons=[
                MDFlatButton(
                    text="SAVE",
                    on_release=self.create_section
                ),
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
            ],
        )
        self.dialog.open()
    
    async def create_section(self, *args):
        """Create a new section"""
        # Get data from dialog
        section_data = {
            'course_id': self.course_id,
            'title': 'New Section',  # TODO: Get from dialog input
            'description': '',
            'order': await self._get_next_order(),
        }
        
        try:
            await self.content_organization_service.create_section(section_data)
            self.dialog.dismiss()
            await self.load_sections()
            toast("Section created successfully")
        except Exception as e:
            toast(f"Error creating section: {str(e)}")
    
    async def _get_next_order(self) -> int:
        """Get the next order number for a new section"""
        sections = await self.content_organization_service.list_course_sections(self.course_id)
        return len(sections)
    
    def show_edit_section_dialog(self, section_id: str):
        """Show dialog to edit section"""
        # TODO: Implement edit section dialog
        pass
    
    async def delete_section(self, section_id: str):
        """Delete a section"""
        try:
            await self.content_organization_service.delete_section(section_id)
            await self.load_sections()
            toast("Section deleted successfully")
        except Exception as e:
            toast(f"Error deleting section: {str(e)}")