from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.filemanager import MDFileManager
from kivymd.uix.list import OneLineListItem
from kivymd.toast import toast
from modules.learning.services.media_service import MediaService
from modules.auth.auth_middleware import AuthMiddleware
import os
import asyncio

class MediaUploadItem(OneLineListItem):
    def __init__(self, filepath: str, **kwargs):
        super().__init__(**kwargs)
        self.filepath = filepath
        self.filename = os.path.basename(filepath)
        self.progress = 0
        self.status_text = "Queued"
        self.upload_completed = False
        self.upload_task = None
    
    def get_icon(self) -> str:
        """Get icon based on file type"""
        ext = os.path.splitext(self.filepath)[1].lower()
        icons = {
            '.mp4': 'video',
            '.mov': 'video',
            '.mp3': 'music',
            '.wav': 'music',
            '.jpg': 'image',
            '.png': 'image',
            '.pdf': 'file-pdf-box',
            '.doc': 'file-word-box',
            '.docx': 'file-word-box'
        }
        return icons.get(ext, 'file')
    
    def cancel_upload(self):
        """Cancel ongoing upload"""
        if self.upload_task and not self.upload_completed:
            self.upload_task.cancel()
            self.status_text = "Cancelled"

class MediaUploaderScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.media_service = MediaService()
        self.file_manager = MDFileManager(
            exit_manager=self.exit_file_manager,
            select_path=self.select_file,
            preview=True,
        )
    
    def on_enter(self):
        """Called when the screen is entered"""
        if not AuthMiddleware.is_authenticated():
            self.go_back()
            toast("Please login to upload media")
    
    def go_back(self):
        """Navigate back to previous screen"""
        self.manager.current = 'previous_screen'
    
    def show_file_picker(self):
        """Show file picker dialog"""
        self.file_manager.show('/')
    
    def exit_file_manager(self, *args):
        """Called when file manager is closed"""
        self.file_manager.close()
    
    def select_file(self, path: str):
        """Handle file selection"""
        self.file_manager.close()
        self.add_to_upload_queue(path)
    
    def add_to_upload_queue(self, filepath: str):
        """Add file to upload queue"""
        upload_item = MediaUploadItem(filepath)
        self.ids.upload_queue.add_widget(upload_item)
        upload_item.upload_task = asyncio.create_task(self.upload_file(upload_item))
    
    async def upload_file(self, upload_item: MediaUploadItem):
        """Upload file and update progress"""
        try:
            upload_item.status_text = "Uploading..."
            upload_item.progress = 0
            
            # Simulate upload progress
            for i in range(1, 101):
                if upload_item.upload_task.cancelled():
                    return
                
                upload_item.progress = i
                await asyncio.sleep(0.1)
            
            # Perform actual upload
            await self.media_service.upload_media(upload_item.filepath)
            
            upload_item.status_text = "Completed"
            upload_item.upload_completed = True
            toast(f"Successfully uploaded {upload_item.filename}")
        
        except Exception as e:
            upload_item.status_text = "Failed"
            toast(f"Error uploading {upload_item.filename}: {str(e)}")