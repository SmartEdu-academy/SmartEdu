from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.toast import toast
from modules.learning.services.lesson_service import LessonService
from modules.auth.auth_middleware import AuthMiddleware

class LessonBuilderScreen(MDScreen):
    def __init__(self, course_id: str, **kwargs):
        super().__init__(**kwargs)
        self.course_id = course_id
        self.lesson_service = LessonService()
        self.media_urls = []
        self.prerequisites = []
    
    def on_enter(self):
        """Called when the screen is entered"""
        if not AuthMiddleware.is_authenticated():
            self.go_back()
            toast("Please login to create lessons")
    
    def go_back(self):
        """Navigate back to course screen"""
        self.manager.current = 'course_view'
    
    def add_media(self):
        """Handle media upload"""
        # TODO: Implement media upload dialog
        pass
    
    def add_prerequisite(self):
        """Handle prerequisite lesson selection"""
        # TODO: Implement prerequisite selection dialog
        pass
    
    async def save_lesson(self, status: str = "draft"):
        """Save the lesson with the given status"""
        if not self.validate_fields():
            return
        
        lesson_data = self.get_lesson_data()
        lesson_data['status'] = status
        
        try:
            await self.lesson_service.create_lesson(lesson_data)
            toast(f"Lesson {status} successfully")
            self.go_back()
        except Exception as e:
            toast(f"Error saving lesson: {str(e)}")
    
    async def save_as_draft(self):
        """Save lesson as draft"""
        await self.save_lesson("draft")
    
    async def publish_lesson(self):
        """Publish the lesson"""
        await self.save_lesson("published")
    
    def validate_fields(self) -> bool:
        """Validate required fields"""
        title = self.ids.title_field.text.strip()
        content = self.ids.content_field.text.strip()
        
        if not title:
            toast("Please enter a lesson title")
            return False
        
        if not content:
            toast("Please enter lesson content")
            return False
        
        return True
    
    def get_lesson_data(self) -> dict:
        """Get lesson data from form fields"""
        return {
            "course_id": self.course_id,
            "title": self.ids.title_field.text.strip(),
            "content": self.ids.content_field.text.strip(),
            "duration_minutes": int(self.ids.duration_field.text or 0),
            "media_urls": self.media_urls,
            "prerequisites": self.prerequisites,
            "order": 0  # TODO: Implement proper ordering
        }