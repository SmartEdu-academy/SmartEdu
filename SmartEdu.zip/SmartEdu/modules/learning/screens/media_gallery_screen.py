from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.menu import MDDropdownMenu
from kivymd.toast import toast
from typing import List
from modules.learning.services.media_gallery_service import MediaGalleryService
from modules.auth.auth_middleware import AuthMiddleware

class MediaGalleryItem(MDCard):
    def __init__(self, gallery_data: dict, **kwargs):
        super().__init__(**kwargs)
        self.gallery_id = gallery_data.get('id')
        self.title = gallery_data.get('title')
        self.thumbnail_url = gallery_data.get('thumbnail_url')
        self.media_ids = gallery_data.get('media_ids', [])
        self.parent_screen = None
    
    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self.parent_screen.open_gallery(self.gallery_id)
            return True
        return super().on_touch_down(touch)

class MediaPlayer(MDBoxLayout):
    def __init__(self, media_data: dict, **kwargs):
        super().__init__(**kwargs)
        self.media_id = media_data.get('id')
        self.video_url = media_data.get('url')
        self.transcoded_urls = media_data.get('transcoded_urls', {})
        self.current_quality = list(self.transcoded_urls.keys())[0] if self.transcoded_urls else 'original'
        self.duration = 0
        self.progress = 0
        self.state = 'stop'
        self._update_clock = None
    
    def on_kv_post(self, base_widget):
        """Setup after kv file is loaded"""
        self.video_player = self.ids.video_player
        self.progress_slider = self.ids.progress_slider
        self._setup_quality_menu()
        self._start_progress_tracking()
    
    def _setup_quality_menu(self):
        """Setup quality selection menu"""
        qualities = list(self.transcoded_urls.keys()) + ['original']
        menu_items = [
            {
                "text": quality,
                "viewclass": "OneLineListItem",
                "on_release": lambda q=quality: self.change_quality(q)
            } for quality in qualities
        ]
        self.quality_menu = MDDropdownMenu(
            caller=self,
            items=menu_items,
            width_mult=2
        )
    
    def _start_progress_tracking(self):
        """Start tracking video progress"""
        from kivy.clock import Clock
        self._update_clock = Clock.schedule_interval(self._update_progress, 1/30)
    
    def _update_progress(self, dt):
        """Update progress bar and time labels"""
        if self.video_player.state == 'play':
            self.progress = self.video_player.position
            self.current_time = self._format_time(self.progress)
            self.duration = self.video_player.duration
            self.duration_text = self._format_time(self.duration)
    
    def _format_time(self, seconds: float) -> str:
        """Format seconds to MM:SS"""
        minutes = int(seconds // 60)
        seconds = int(seconds % 60)
        return f"{minutes:02d}:{seconds:02d}"
    
    def toggle_playback(self):
        """Toggle video playback"""
        if self.video_player.state == 'play':
            self.video_player.state = 'pause'
        else:
            self.video_player.state = 'play'
        self.state = self.video_player.state
    
    def seek(self, value):
        """Seek to position"""
        self.video_player.seek(value)
    
    def change_quality(self, quality: str):
        """Change video quality"""
        self.current_quality = quality
        current_position = self.video_player.position
        self.video_player.source = (
            self.transcoded_urls.get(quality, self.video_url)
        )
        self.video_player.seek(current_position)
        self.quality_menu.dismiss()
    
    def show_quality_menu(self):
        """Show quality selection menu"""
        self.quality_menu.open()
    
    def previous_quality(self):
        """Switch to previous quality"""
        qualities = list(self.transcoded_urls.keys()) + ['original']
        current_index = qualities.index(self.current_quality)
        new_index = (current_index - 1) % len(qualities)
        self.change_quality(qualities[new_index])
    
    def next_quality(self):
        """Switch to next quality"""
        qualities = list(self.transcoded_urls.keys()) + ['original']
        current_index = qualities.index(self.current_quality)
        new_index = (current_index + 1) % len(qualities)
        self.change_quality(qualities[new_index])

class CreateGalleryContent(MDBoxLayout):
    """Custom content for create gallery dialog"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = "12dp"
        self.size_hint_y = None
        self.height = "200dp"
        self.padding = "16dp"
        
        self.add_widget(MDTextField(
            id="title_field",
            hint_text="Gallery Title",
            required=True,
            helper_text="Required",
            helper_text_mode="on_error",
        ))
        
        self.add_widget(MDTextField(
            id="description_field",
            hint_text="Description",
            multiline=True,
        ))
        
        self.add_widget(MDTextField(
            id="visibility_field",
            hint_text="Visibility",
            text="public",
            helper_text="public, private, or shared",
        ))

class MediaGalleryScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.media_gallery_service = MediaGalleryService()
        self.is_grid_view = True
        self.current_filter = ""
        self.load_galleries()
    
    def on_enter(self):
        """Called when the screen is entered"""
        if not AuthMiddleware.is_authenticated():
            self.go_back()
            toast("Please login to access media gallery")
    
    def go_back(self):
        """Navigate back to previous screen"""
        self.manager.current = 'previous_screen'
    
    async def load_galleries(self):
        """Load media galleries"""
        try:
            galleries = await self.media_gallery_service.list_galleries()
            self.display_galleries(galleries)
        except Exception as e:
            toast(f"Error loading galleries: {str(e)}")
    
    def display_galleries(self, galleries: List[MediaGallery]):
        """Display galleries in grid/list"""
        grid = self.ids.gallery_grid
        grid.clear_widgets()
        
        for gallery in galleries:
            if self.current_filter and self.current_filter.lower() not in gallery.title.lower():
                continue
                
            gallery_item = MediaGalleryItem(gallery.to_dict())
            gallery_item.parent_screen = self
            grid.add_widget(gallery_item)
    
    def filter_media(self, query: str):
        """Filter galleries by search query"""
        self.current_filter = query
        self.load_galleries()
    
    def toggle_view(self):
        """Toggle between grid and list view"""
        self.is_grid_view = not self.is_grid_view
        self.ids.gallery_grid.cols = 2 if self.is_grid_view else 1
        self.load_galleries()
    
    def show_create_gallery_dialog(self):
        """Show dialog to create new gallery"""
        self.dialog = MDDialog(
            title="Create Gallery",
            type="custom",
            content_cls=CreateGalleryContent(),
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="CREATE",
                    on_release=self.create_gallery
                ),
            ],
        )
        self.dialog.open()
    
    async def create_gallery(self, *args):
        """Create new gallery"""
        content = self.dialog.content_cls
        gallery_data = {
            'title': content.ids.title_field.text,
            'description': content.ids.description_field.text,
            'created_by': AuthMiddleware.get_current_user().id,
            'media_ids': [],
            'visibility': content.ids.visibility_field.text
        }
        
        try:
            await self.media_gallery_service.create_gallery(gallery_data)
            self.dialog.dismiss()
            await self.load_galleries()
            toast("Gallery created successfully")
        except Exception as e:
            toast(f"Error creating gallery: {str(e)}")
    
    def open_gallery(self, gallery_id: str):
        """Open gallery detail view"""
        self.manager.transition.direction = 'left'
        self.manager.current = 'gallery_detail'
        self.manager.get_screen('gallery_detail').load_gallery(gallery_id)
        
# Add to existing MediaGalleryScreen class

    def show_batch_metadata_dialog(self):
        """Show dialog for batch metadata editing"""
        if not self.selected_media:
            toast("No media selected")
            return
        
        selected_items = [
            media for media in self.media_items 
            if media['id'] in self.selected_media
        ]
        
        self.dialog = MDDialog(
            title="Edit Batch Metadata",
            type="custom",
            content_cls=BatchMetadataEditor(selected_items),
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="APPLY",
                    on_release=self.apply_batch_metadata
                ),
            ],
        )
        self.dialog.open()
    
    async def apply_batch_metadata(self, *args):
        """Apply batch metadata updates"""
        try:
            updates = self.dialog.content_cls.get_updates()
            if not updates:
                toast("No updates to apply")
                return
            
            results = await self.media_batch_service.batch_update(updates)
            
            if results.get('error'):
                toast(f"Error updating metadata: {results['error']}")
            else:
                success_count = len(results['successful'])
                fail_count = len(results['failed'])
                toast(f"Updated {success_count} items, {fail_count} failed")
            
            self.dialog.dismiss()
            await self.load_galleries()
            
        except Exception as e:
            toast(f"Error applying updates: {str(e)}")
    
    def handle_item_drop(self, item):
        """Handle dropped media item"""
        if hasattr(self, 'current_gallery'):
            source_gallery = item.gallery_id
            if source_gallery != self.current_gallery.id:
                self.move_media_items([item.media_id], source_gallery)
    
    async def move_media_items(self, media_ids: List[str], source_gallery_id: str):
        """Move media items between galleries"""
        try:
            results = await self.media_batch_service.batch_move(
                media_ids,
                self.current_gallery.id,
                source_gallery_id
            )
            
            if results.get('error'):
                toast(f"Error moving items: {results['error']}")
            else:
                success_count = len(results['successful'])
                fail_count = len(results['failed'])
                toast(f"Moved {success_count} items, {fail_count} failed")
            
            await self.load_galleries()
            
        except Exception as e:
            toast(f"Error moving items: {str(e)}")