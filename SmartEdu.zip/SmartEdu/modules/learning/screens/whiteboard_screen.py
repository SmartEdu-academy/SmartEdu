from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.graphics import Color, Line, InstructionGroup
from kivy.properties import ObjectProperty, ListProperty, NumericProperty
from kivy.uix.label import Label
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.textfield import MDTextField
from ..services.whiteboard_service import WhiteboardService

Builder.load_file('modules/learning/screens/whiteboard_screen.kv')

class TextInputDialog(MDDialog):
    def __init__(self, **kwargs):
        super().__init__(
            title="Add Text",
            type="custom",
            content_cls=MDTextField(
                hint_text="Enter your text",
                multiline=False
            ),
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    theme_text_color="Custom",
                ),
                MDFlatButton(
                    text="OK",
                    theme_text_color="Custom",
                ),
            ],
        )

class WhiteboardScreen(MDScreen):
    preview_widget = ObjectProperty(None)
    current_color = ListProperty([0, 0, 0, 1])
    current_font_size = NumericProperty(14.0)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.whiteboard_service = WhiteboardService()
        self.text_dialog = None
        self.text_pos = None

    def on_touch_down(self, touch):
        if self.ids.drawing_area.collide_point(*touch.pos):
            tool = self.whiteboard_service.current_tool
            if tool == 'text':
                self.show_text_dialog(touch.pos)
            elif tool in ['rectangle', 'circle', 'line']:
                self.whiteboard_service.start_shape(*touch.pos, tool)
            else:
                self.whiteboard_service.start_drawing(*touch.pos)
                self.draw_current_point(*touch.pos)
        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if self.ids.drawing_area.collide_point(*touch.pos):
            tool = self.whiteboard_service.current_tool
            if tool in ['rectangle', 'circle', 'line']:
                self.preview_shape(*touch.pos)
            else:
                self.whiteboard_service.add_point(*touch.pos)
                self.draw_current_point(*touch.pos)
        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        if self.ids.drawing_area.collide_point(*touch.pos):
            tool = self.whiteboard_service.current_tool
            if tool in ['rectangle', 'circle', 'line']:
                self.whiteboard_service.end_shape(*touch.pos)
                self.redraw_canvas()
            else:
                self.whiteboard_service.end_drawing()
        return super().on_touch_up(touch)

    def draw_current_point(self, x, y):
        with self.ids.drawing_area.canvas:
            Color(*self.current_color)
            Line(points=[x, y], width=self.whiteboard_service.current_thickness)

    def preview_shape(self, x, y):
        if self.preview_widget:
            self.ids.drawing_area.canvas.remove(self.preview_widget)
        self.preview_widget = InstructionGroup()
        self.whiteboard_service.draw_shape_preview(self.preview_widget, x, y)
        self.ids.drawing_area.canvas.add(self.preview_widget)

    def show_text_dialog(self, pos):
        self.text_pos = pos
        if not self.text_dialog:
            self.text_dialog = TextInputDialog()
            self.text_dialog.buttons[0].bind(
                on_release=self.text_dialog.dismiss
            )
            self.text_dialog.buttons[1].bind(
                on_release=self._add_text
            )
        self.text_dialog.open()

    def _add_text(self, *args):
        text = self.text_dialog.content_cls.text
        if text and self.text_pos:
            self.whiteboard_service.add_text(*self.text_pos, text)
            self.redraw_canvas()
        self.text_dialog.dismiss()
        self.text_pos = None
        self.text_dialog.content_cls.text = ""

    def clear_canvas(self):
        self.whiteboard_service.clear()
        self.ids.drawing_area.canvas.clear()

    def undo_last(self):
        if self.whiteboard_service.undo():
            self.redraw_canvas()

    def save_whiteboard(self):
        data = self.whiteboard_service.save_whiteboard("whiteboard")
        self.ids.status_label.text = "Whiteboard saved!"

    def load_whiteboard(self, filename):
        if self.whiteboard_service.load_whiteboard(filename):
            self.redraw_canvas()
            self.ids.status_label.text = "Whiteboard loaded!"
        else:
            self.ids.status_label.text = "Error loading whiteboard"

    def share_whiteboard(self):
        image_data = self.whiteboard_service.export_as_image(self.ids.drawing_area)
        self.ids.status_label.text = "Whiteboard shared!"

    def change_thickness(self, forward=True):
        thickness = self.whiteboard_service.cycle_thickness(forward)
        self.ids.thickness_label.text = f"{thickness:.1f}"

    def change_font_size(self, forward=True):
        font_size = self.whiteboard_service.cycle_font_size(forward)
        self.current_font_size = font_size
        self.ids.font_size_label.text = f"{font_size:.1f}"

    def redraw_canvas(self):
        self.ids.drawing_area.canvas.clear()
        for drawing in self.whiteboard_service.history:
            with self.ids.drawing_area.canvas:
                Color(*drawing.color)
                if drawing.tool_type == "text":
                    Label(
                        text=drawing.text_content,
                        pos=drawing.points[0],
                        color=drawing.color,
                        font_size=drawing.font_size
                    )
                elif drawing.tool_type in ["rectangle", "circle", "line"]:
                    if drawing.tool_type == "rectangle":
                        x1, y1 = drawing.points[0]
                        x2, y2 = drawing.points[1]
                        Line(rectangle=[x1, y1, x2-x1, y2-y1], width=drawing.thickness)
                    elif drawing.tool_type == "circle":
                        import math
                        x1, y1 = drawing.points[0]
                        x2, y2 = drawing.points[1]
                        radius = math.sqrt((x2-x1)**2 + (y2-y1)**2)
                        Line(circle=(x1, y1, radius), width=drawing.thickness)
                    else:  # line
                        Line(points=[*drawing.points[0], *drawing.points[1]], width=drawing.thickness)
                else:
                    points = []
                    for point in drawing.points:
                        points.extend([point[0], point[1]])
                    Line(points=points, width=drawing.thickness)