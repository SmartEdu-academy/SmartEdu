from kivymd.uix.screen import MDScreen
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.list import MDList, OneLineIconListItem
from kivymd.uix.textfield import MDTextField
from ..services.live_session_service import LiveSessionService

class LiveSessionScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.service = LiveSessionService()
        self.session_id = None
        self.setup_ui()

    def setup_ui(self):
        self.layout = MDBoxLayout(orientation='vertical')
        
        # Info section
        self.info_section = MDBoxLayout(
            orientation='vertical',
            size_hint_y=0.2
        )
        self.title_label = MDLabel(
            text="Live Session",
            font_style="H5",
            halign="center"
        )
        self.participants_label = MDLabel(
            text="Participants: 0",
            halign="center"
        )
        self.info_section.add_widget(self.title_label)
        self.info_section.add_widget(self.participants_label)

        # Controls section
        self.controls = MDBoxLayout(
            orientation='horizontal',
            size_hint_y=0.1,
            spacing=10,
            padding=10
        )
        
        self.mic_btn = MDIconButton(
            icon="microphone",
            on_release=self.toggle_mic
        )
        self.camera_btn = MDIconButton(
            icon="camera",
            on_release=self.toggle_camera
        )
        self.hand_btn = MDIconButton(
            icon="hand-right",
            on_release=self.toggle_hand
        )
        
        for btn in [self.mic_btn, self.camera_btn, self.hand_btn]:
            self.controls.add_widget(btn)

        # Chat section
        self.chat_section = MDBoxLayout(
            orientation='vertical',
            size_hint_y=0.7
        )
        self.chat_list = MDList()
        self.message_input = MDTextField(
            hint_text="Type a message...",
            multiline=False,
            size_hint_y=None,
            height=50,
            on_text_validate=self.send_message
        )
        
        self.chat_section.add_widget(self.chat_list)
        self.chat_section.add_widget(self.message_input)

        # Add all sections to main layout
        self.layout.add_widget(self.info_section)
        self.layout.add_widget(self.controls)
        self.layout.add_widget(self.chat_section)
        self.add_widget(self.layout)

    async def start_session(self):
        self.session_id = await self.service.create_session(
            title="New Session",
            host_id="current_user_id"  # Replace with actual user ID
        )
        await self.service.start_session(self.session_id)
        self.title_label.text = "Live Session (Active)"

    def toggle_mic(self, *args):
        self.mic_btn.icon = "microphone-off" \
            if self.mic_btn.icon == "microphone" else "microphone"

    def toggle_camera(self, *args):
        self.camera_btn.icon = "camera-off" \
            if self.camera_btn.icon == "camera" else "camera"

    async def toggle_hand(self, *args):
        if self.session_id:
            is_raised = await self.service.toggle_hand_raise(
                self.session_id,
                "current_user_id"  # Replace with actual user ID
            )
            self.hand_btn.icon = "hand-back-right" if is_raised else "hand-right"

    async def send_message(self, *args):
        if self.session_id and self.message_input.text:
            await self.service.add_chat_message(
                self.session_id,
                "current_user_id",  # Replace with actual user ID
                self.message_input.text
            )
            self.message_input.text = ""
            await self.update_chat()

    async def update_chat(self):
        session = await self.service.get_session(self.session_id)
        if session:
            self.chat_list.clear_widgets()
            for msg in session.chat_messages:
                self.chat_list.add_widget(
                    OneLineIconListItem(
                        text=f"{msg['message']} ({msg['timestamp']})"
                    )
                )