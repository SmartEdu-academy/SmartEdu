from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.uix.filemanager import MDFileManager
from kivymd.toast import toast
from modules.learning.services.resource_service import ResourceService
from modules.auth.auth_middleware import AuthMiddleware

class ResourceManagerScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.resource_service = ResourceService()
        self.current_filter = "all"
        self.file_manager = MDFileManager(
            exit_manager=self.exit_file_manager,
            select_path=self.select_file,
            preview=True
        )
        self.load_resources()
    
    def on_enter(self):
        """Called when the screen is entered"""
        if not AuthMiddleware.is_authenticated():
            self.go_back()
            toast("Please login to manage resources")
    
    def go_back(self):
        """Navigate back to previous screen"""
        self.manager.current = 'previous_screen'
    
    async def load_resources(self):
        """Load resources based on current filter"""
        filters = {}
        if self.current_filter != "all":
            filters['type'] = self.current_filter
            
        try:
            resources = await self.resource_service.list_resources(filters)
            self.ids.resources_list.data = [
                {
                    'title': r.title,
                    'type': r.type,
                    'thumbnail_url': r.thumbnail_url,
                    'download_count': r.download_count,
                    'resource_id': r.id
                }
                for r in resources
            ]
        except Exception as e:
            toast(f"Error loading resources: {str(e)}")
    
    def filter_resources(self, search_text: str):
        """Filter resources based on search text"""
        # TODO: Implement client-side filtering
        pass
    
    def filter_by_type(self, resource_type: str):
        """Filter resources by type"""
        self.current_filter = resource_type
        self.load_resources()
    
    def show_add_resource_dialog(self):
        """Show dialog to add new resource"""
        self.dialog = MDDialog(
            title="Add Resource",
            buttons=[
                MDFlatButton(
                    text="UPLOAD FILE",
                    on_release=lambda x: self.show_file_manager()
                ),
                MDFlatButton(
                    text="ADD LINK",
                    on_release=lambda x: self.show_link_dialog()
                ),
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
            ],
        )
        self.dialog.open()
    
    def show_file_manager(self):
        """Show file manager for uploading files"""
        self.dialog.dismiss()
        self.file_manager.show('/')
    
    def exit_file_manager(self, *args):
        """Called when file manager is closed"""
        self.file_manager.close()
    
    async def select_file(self, path: str):
        """Handle file selection"""
        self.file_manager.close()
        
        try:
            resource_data = {
                'title': path.split('/')[-1],
                'type': 'file',
                'created_by': AuthMiddleware.get_current_user_id(),
            }
            
            await self.resource_service.create_resource(resource_data, path)
            toast("Resource uploaded successfully")
            self.load_resources()
        except Exception as e:
            toast(f"Error uploading resource: {str(e)}")
    
    def show_link_dialog(self):
        """Show dialog to add link resource"""
        # TODO: Implement link resource dialog
        pass