from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivymd.toast import toast
from modules.learning.services.media_gallery_service import MediaGalleryService
from modules.learning.services.media_service import MediaService
from modules.auth.auth_middleware import AuthMiddleware

class GalleryDetailScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.gallery_service = MediaGalleryService()
        self.media_service = MediaService()
        self.current_gallery = None
        self.current_media = None
    
    async def load_gallery(self, gallery_id: str):
        """Load gallery and its media"""
        try:
            self.current_gallery = await self.gallery_service.get_gallery(gallery_id)
            if not self.current_gallery:
                toast("Gallery not found")
                self.go_back()
                return
            
            self.ids.gallery_title.text = self.current_gallery.title
            self.ids.gallery_description.text = self.current_gallery.description or ""
            
            await self.load_media_items()
        except Exception as e:
            toast(f"Error loading gallery: {str(e)}")
            self.go_back()
    
    async def load_media_items(self):
        """Load media items in gallery"""
        if not self.current_gallery or not self.current_gallery.media_ids:
            return
        
        try:
            media_grid = self.ids.media_grid
            media_grid.clear_widgets()
            
            for media_id in self.current_gallery.media_ids:
                media = await self.media_service.get_media(media_id)
                if media:
                    media_item = MediaItem(media.to_dict())
                    media_item.parent_screen = self
                    media_grid.add_widget(media_item)
        except Exception as e:
            toast(f"Error loading media items: {str(e)}")
    
    def show_media(self, media_id: str):
        """Show media in player/viewer"""
        self.current_media = media_id
        media = await self.media_service.get_media(media_id)
        
        if media.type == 'video':
            self.ids.media_player.opacity = 1
            self.ids.media_player.media_data = media.to_dict()
        else:
            # Handle other media types
            pass
    
    def go_back(self):
        """Navigate back to gallery list"""
        self.manager.transition.direction = 'right'
        self.manager.current = 'media_gallery'
    
    def show_add_media_dialog(self):
        """Show dialog to add media to gallery"""
        self.dialog = MDDialog(
            title="Add Media",
            type="custom",
            content_cls=MediaSelectorContent(self.current_gallery.media_ids),
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="ADD",
                    on_release=self.add_media
                ),
            ],
        )
        self.dialog.open()
    
    async def add_media(self, *args):
        """Add selected media to gallery"""
        content = self.dialog.content_cls
        selected_media = content.get_selected_media()
        
        try:
            for media_id in selected_media:
                await self.gallery_service.add_media_to_gallery(
                    self.current_gallery.id,
                    media_id
                )
            
            self.dialog.dismiss()
            await self.load_gallery(self.current_gallery.id)
            toast("Media added successfully")
        except Exception as e:
            toast(f"Error adding media: {str(e)}")