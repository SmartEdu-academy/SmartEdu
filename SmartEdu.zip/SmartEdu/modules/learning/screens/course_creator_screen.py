from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.toast import toast
from modules.learning.services.course_service import CourseService
from modules.auth.auth_middleware import AuthMiddleware

class CourseCreatorScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.course_service = CourseService()
        self.thumbnail_path = None

    def on_enter(self):
        """Called when the screen is entered"""
        if not AuthMiddleware.is_authenticated():
            self.go_back()
            toast("Please login to create courses")

    def go_back(self):
        """Navigate back to previous screen"""
        self.manager.current = 'previous_screen'

    def upload_thumbnail(self):
        """Handle thumbnail upload"""
        # TODO: Implement file picker and upload logic
        pass

    async def save_draft(self):
        """Save course as draft"""
        if not self.validate_fields():
            return

        course_data = self.get_course_data()
        course_data['published'] = False
        
        try:
            await self.course_service.create_course(course_data)
            toast("Course saved as draft")
            self.go_back()
        except Exception as e:
            toast(f"Error saving course: {str(e)}")

    async def publish_course(self):
        """Publish the course"""
        if not self.validate_fields():
            return

        course_data = self.get_course_data()
        course_data['published'] = True
        
        try:
            await self.course_service.create_course(course_data)
            toast("Course published successfully")
            self.go_back()
        except Exception as e:
            toast(f"Error publishing course: {str(e)}")

    def validate_fields(self) -> bool:
        """Validate required fields"""
        title = self.ids.title_field.text.strip()
        description = self.ids.description_field.text.strip()
        
        if not title:
            toast("Please enter a course title")
            return False
        
        if not description:
            toast("Please enter a course description")
            return False
            
        return True

    def get_course_data(self) -> dict:
        """Get course data from form fields"""
        return {
            "title": self.ids.title_field.text.strip(),
            "description": self.ids.description_field.text.strip(),
            "category": self.ids.category_field.text.strip() or "uncategorized",
            "duration_hours": float(self.ids.duration_field.text or 0),
            "thumbnail_url": self.thumbnail_path,
            "creator_id": AuthMiddleware.get_current_user_id(),
            "lessons": [],
            "tags": []
        }