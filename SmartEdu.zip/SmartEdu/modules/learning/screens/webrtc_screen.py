from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.properties import StringProperty, BooleanProperty
from webrtc import WebRTCClient

Builder.load_file('modules/learning/screens/webrtc_screen.kv')

class WebRTCScreen(MDScreen):
    peer_id = StringProperty("")
    is_connected = BooleanProperty(False)
    is_mic_on = BooleanProperty(True)
    is_camera_on = BooleanProperty(True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.webrtc = WebRTCClient(self)
        self.stream_started = False

    def on_enter(self):
        if not self.stream_started:
            self.start_stream()

    def start_stream(self):
        self.webrtc.start()
        self.stream_started = True

    def toggle_mic(self):
        self.is_mic_on = not self.is_mic_on
        self.webrtc.toggle_audio(self.is_mic_on)

    def toggle_camera(self):
        self.is_camera_on = not self.is_camera_on
        self.webrtc.toggle_video(self.is_camera_on)

    def end_call(self):
        self.webrtc.stop()
        self.stream_started = False
        self.manager.go_back()

    def on_connection_state(self, state):
        self.is_connected = state == "connected"
        if self.is_connected:
            self.ids.status_label.text = "Connected"
        else:
            self.ids.status_label.text = "Connecting..."