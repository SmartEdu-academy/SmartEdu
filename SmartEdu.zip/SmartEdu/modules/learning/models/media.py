from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

@dataclass
class Media:
    id: str
    title: str
    type: str  # video, audio, image, document
    url: str
    created_at: datetime
    updated_at: datetime
    created_by: str
    size_bytes: Optional[int] = None
    duration_seconds: Optional[int] = None
    thumbnail_url: Optional[str] = None
    metadata: dict = None
    status: str = "active"
    encoding_status: str = "completed"  # processing, completed, failed
    transcoded_urls: dict = None  # Different quality versions
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "type": self.type,
            "url": self.url,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "created_by": self.created_by,
            "size_bytes": self.size_bytes,
            "duration_seconds": self.duration_seconds,
            "thumbnail_url": self.thumbnail_url,
            "metadata": self.metadata or {},
            "status": self.status,
            "encoding_status": self.encoding_status,
            "transcoded_urls": self.transcoded_urls or {}
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Media':
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)