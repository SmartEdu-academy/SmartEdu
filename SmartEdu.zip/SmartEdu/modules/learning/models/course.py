from datetime import datetime
from typing import List, Optional
from dataclasses import dataclass

@dataclass
class Course:
    id: str
    title: str
    description: str
    creator_id: str
    created_at: datetime
    updated_at: datetime
    published: bool = False
    lessons: List[str] = None  # List of lesson IDs
    thumbnail_url: Optional[str] = None
    duration_hours: float = 0.0
    category: str = "uncategorized"
    tags: List[str] = None
    
    @property
    def lesson_count(self) -> int:
        return len(self.lessons) if self.lessons else 0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "creator_id": self.creator_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "published": self.published,
            "lessons": self.lessons,
            "thumbnail_url": self.thumbnail_url,
            "duration_hours": self.duration_hours,
            "category": self.category,
            "tags": self.tags
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Course':
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)