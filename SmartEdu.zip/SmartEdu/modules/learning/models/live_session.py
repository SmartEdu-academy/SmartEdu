from datetime import datetime
from typing import Dict, List
from uuid import uuid4

class LiveSession:
    def __init__(self, title: str, host_id: str):
        self.id = str(uuid4())
        self.title = title
        self.host_id = host_id
        self.status = 'scheduled'  # scheduled, live, ended
        self.created_at = datetime.utcnow()
        self.started_at = None
        self.ended_at = None
        self.participants = []
        self.settings = {
            'chat_enabled': True,
            'whiteboard_enabled': True,
            'recording_enabled': True,
            'max_participants': 50,
            'allow_participant_audio': True,
            'allow_participant_video': True,
            'mute_on_join': True
        }
        # New feature additions
        self.chat_messages = []
        self.hand_raises = []
        self.shared_resources = []
        self.attendance_log = {}

    def start(self):
        self.status = 'live'
        self.started_at = datetime.utcnow()

    def end(self):
        self.status = 'ended'
        self.ended_at = datetime.utcnow()

    # New methods for added features
    def add_participant(self, user_id: str):
        if user_id not in self.participants:
            self.participants.append(user_id)
            self.attendance_log[user_id] = {
                'joined_at': datetime.utcnow(),
                'left_at': None
            }

    def remove_participant(self, user_id: str):
        if user_id in self.participants:
            self.participants.remove(user_id)
            if user_id in self.attendance_log:
                self.attendance_log[user_id]['left_at'] = datetime.utcnow()

    def add_chat_message(self, user_id: str, message: str):
        self.chat_messages.append({
            'id': str(uuid4()),
            'user_id': user_id,
            'message': message,
            'timestamp': datetime.utcnow()
        })

    def toggle_hand_raise(self, user_id: str):
        if user_id in self.hand_raises:
            self.hand_raises.remove(user_id)
            return False
        else:
            self.hand_raises.append(user_id)
            return True

    def add_shared_resource(self, resource_url: str, resource_type: str):
        self.shared_resources.append({
            'id': str(uuid4()),
            'url': resource_url,
            'type': resource_type,
            'shared_at': datetime.utcnow(),
            'shared_by': self.host_id
        })