from datetime import datetime
from typing import Dict, Optional
from enum import Enum

class ParticipantRole(Enum):
    STUDENT = "student"
    MODERATOR = "moderator"
    OBSERVER = "observer"  # For parents or teachers observing

class ParticipantStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    AWAY = "away"

class RoomParticipant:
    def __init__(
        self,
        user_id: str,
        room_id: str,
        role: ParticipantRole = ParticipantRole.STUDENT,
        display_name: Optional[str] = None
    ):
        self.user_id = user_id
        self.room_id = room_id
        self.role = role
        self.display_name = display_name
        self.status = ParticipantStatus.ACTIVE
        self.joined_at = datetime.utcnow()
        self.last_active = datetime.utcnow()
        self.settings = {
            'video_enabled': True,
            'audio_enabled': True,
            'screen_sharing_enabled': False,
            'raise_hand': False
        }
        self.activity_log = []

    def update_status(self, new_status: ParticipantStatus) -> None:
        self.status = new_status
        self.last_active = datetime.utcnow()
        self._log_activity(f"Status changed to {new_status.value}")

    def update_settings(self, new_settings: Dict) -> None:
        self.settings.update(new_settings)
        self._log_activity("Settings updated")

    def toggle_hand(self) -> bool:
        self.settings['raise_hand'] = not self.settings['raise_hand']
        self._log_activity(
            f"Hand {'raised' if self.settings['raise_hand'] else 'lowered'}"
        )
        return self.settings['raise_hand']

    def _log_activity(self, action: str) -> None:
        self.activity_log.append({
            'timestamp': datetime.utcnow().isoformat(),
            'action': action
        })

    def to_dict(self) -> Dict:
        return {
            'user_id': self.user_id,
            'room_id': self.room_id,
            'role': self.role.value,
            'display_name': self.display_name,
            'status': self.status.value,
            'joined_at': self.joined_at.isoformat(),
            'last_active': self.last_active.isoformat(),
            'settings': self.settings,
            'activity_log': self.activity_log
        }