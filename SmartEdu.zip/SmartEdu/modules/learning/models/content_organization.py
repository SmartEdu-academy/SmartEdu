from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Dict

@dataclass
class ContentSection:
    id: str
    course_id: str
    title: str
    description: Optional[str]
    order: int
    created_at: datetime
    updated_at: datetime
    lesson_ids: List[str] = None
    resource_ids: List[str] = None
    status: str = "active"
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "course_id": self.course_id,
            "title": self.title,
            "description": self.description,
            "order": self.order,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "lesson_ids": self.lesson_ids or [],
            "resource_ids": self.resource_ids or [],
            "status": self.status
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ContentSection':
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)