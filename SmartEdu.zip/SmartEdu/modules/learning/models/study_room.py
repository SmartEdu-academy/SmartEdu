from datetime import datetime
from typing import List, Dict, Optional
from enum import Enum

class RoomStatus(Enum):
    SCHEDULED = "scheduled"
    ACTIVE = "active"
    ENDED = "ended"
    CANCELLED = "cancelled"

class RoomType(Enum):
    PUBLIC = "public"
    PRIVATE = "private"
    COURSE_SPECIFIC = "course_specific"

class StudyRoom:
    def __init__(
        self,
        room_id: str,
        title: str,
        creator_id: str,
        room_type: RoomType,
        max_participants: int = 10,
        course_id: Optional[str] = None,
        description: Optional[str] = None,
        password: Optional[str] = None
    ):
        self.room_id = room_id
        self.title = title
        self.creator_id = creator_id
        self.room_type = room_type
        self.max_participants = max_participants
        self.course_id = course_id
        self.description = description
        self.password = password
        self.status = RoomStatus.SCHEDULED
        self.created_at = datetime.utcnow()
        self.started_at: Optional[datetime] = None
        self.ended_at: Optional[datetime] = None
        self.participants: List[str] = []  # List of participant IDs
        self.moderators: List[str] = [creator_id]
        self.settings: Dict = {
            'enable_chat': True,
            'enable_video': True,
            'enable_whiteboard': True,
            'enable_screen_sharing': True,
            'mute_participants_on_join': False
        }
        self.resources: List[Dict] = []  # Shared resources in the room

    def add_participant(self, participant_id: str) -> bool:
        if len(self.participants) >= self.max_participants:
            return False
        if participant_id not in self.participants:
            self.participants.append(participant_id)
        return True

    def remove_participant(self, participant_id: str) -> bool:
        if participant_id in self.participants:
            self.participants.remove(participant_id)
            return True
        return False

    def add_moderator(self, user_id: str) -> None:
        if user_id not in self.moderators:
            self.moderators.append(user_id)

    def remove_moderator(self, user_id: str) -> bool:
        if user_id in self.moderators and user_id != self.creator_id:
            self.moderators.remove(user_id)
            return True
        return False

    def start_session(self) -> None:
        if self.status == RoomStatus.SCHEDULED:
            self.status = RoomStatus.ACTIVE
            self.started_at = datetime.utcnow()

    def end_session(self) -> None:
        if self.status == RoomStatus.ACTIVE:
            self.status = RoomStatus.ENDED
            self.ended_at = datetime.utcnow()

    def update_settings(self, new_settings: Dict) -> None:
        self.settings.update(new_settings)

    def add_resource(self, resource: Dict) -> None:
        self.resources.append(resource)

    def remove_resource(self, resource_id: str) -> bool:
        for i, resource in enumerate(self.resources):
            if resource['id'] == resource_id:
                self.resources.pop(i)
                return True
        return False

    def to_dict(self) -> Dict:
        return {
            'room_id': self.room_id,
            'title': self.title,
            'creator_id': self.creator_id,
            'room_type': self.room_type.value,
            'max_participants': self.max_participants,
            'course_id': self.course_id,
            'description': self.description,
            'status': self.status.value,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'ended_at': self.ended_at.isoformat() if self.ended_at else None,
            'participants': self.participants,
            'moderators': self.moderators,
            'settings': self.settings,
            'resources': self.resources
        }