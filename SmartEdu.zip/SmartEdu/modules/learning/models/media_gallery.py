from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime

@dataclass
class MediaGallery:
    id: str
    title: str
    description: Optional[str]
    created_by: str
    created_at: datetime
    updated_at: datetime
    media_ids: List[str]
    thumbnail_url: Optional[str]
    status: str = "active"
    visibility: str = "public"  # public, private, shared
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "media_ids": self.media_ids,
            "thumbnail_url": self.thumbnail_url,
            "status": self.status,
            "visibility": self.visibility
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MediaGallery':
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)