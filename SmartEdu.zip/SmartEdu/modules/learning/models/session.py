from datetime import datetime
from typing import Dict, List, Optional
from enum import Enum

class SessionType(Enum):
    GROUP_STUDY = "group_study"
    TUTORING = "tutoring"
    DISCUSSION = "discussion"
    PRESENTATION = "presentation"

class StudySession:
    def __init__(
        self,
        session_id: str,
        room_id: str,
        session_type: SessionType,
        scheduled_start: datetime,
        scheduled_duration: int  # in minutes
    ):
        self.session_id = session_id
        self.room_id = room_id
        self.session_type = session_type
        self.scheduled_start = scheduled_start
        self.scheduled_duration = scheduled_duration
        self.actual_start: Optional[datetime] = None
        self.actual_end: Optional[datetime] = None
        self.attendance: List[Dict] = []
        self.chat_logs: List[Dict] = []
        self.shared_resources: List[Dict] = []
        self.activities: List[Dict] = []
        self.notes: List[Dict] = []
        self.recording_url: Optional[str] = None

    def start_session(self) -> None:
        self.actual_start = datetime.utcnow()
        self._log_activity("Session started")

    def end_session(self) -> None:
        self.actual_end = datetime.utcnow()
        self._log_activity("Session ended")

    def add_attendance(self, user_id: str, join_time: datetime) -> None:
        self.attendance.append({
            'user_id': user_id,
            'join_time': join_time,
            'leave_time': None
        })

    def update_attendance(self, user_id: str, leave_time: datetime) -> None:
        for record in self.attendance:
            if record['user_id'] == user_id and record['leave_time'] is None:
                record['leave_time'] = leave_time
                break

    def add_chat_message(self, message: Dict) -> None:
        self.chat_logs.append({
            **message,
            'timestamp': datetime.utcnow().isoformat()
        })

    def add_shared_resource(self, resource: Dict) -> None:
        self.shared_resources.append({
            **resource,
            'shared_at': datetime.utcnow().isoformat()
        })

    def add_note(self, note: Dict) -> None:
        self.notes.append({
            **note,
            'created_at': datetime.utcnow().isoformat()
        })

    def set_recording_url(self, url: str) -> None:
        self.recording_url = url
        self._log_activity("Recording saved")

    def _log_activity(self, action: str) -> None:
        self.activities.append({
            'timestamp': datetime.utcnow().isoformat(),
            'action': action
        })

    def to_dict(self) -> Dict:
        return {
            'session_id': self.session_id,
            'room_id': self.room_id,
            'session_type': self.session_type.value,
            'scheduled_start': self.scheduled_start.isoformat(),
            'scheduled_duration': self.scheduled_duration,
            'actual_start': self.actual_start.isoformat() if self.actual_start else None,
            'actual_end': self.actual_end.isoformat() if self.actual_end else None,
            'attendance': self.attendance,
            'chat_logs': self.chat_logs,
            'shared_resources': self.shared_resources,
            'activities': self.activities,
            'notes': self.notes,
            'recording_url': self.recording_url
        }