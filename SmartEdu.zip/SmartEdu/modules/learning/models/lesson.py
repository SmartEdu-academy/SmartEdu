from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

@dataclass
class Lesson:
    id: str
    course_id: str
    title: str
    content: str
    order: int
    created_at: datetime
    updated_at: datetime
    duration_minutes: int = 0
    resources: List[str] = None  # List of resource IDs
    prerequisites: List[str] = None  # List of lesson IDs
    status: str = "draft"  # draft, published, archived
    media_urls: List[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "course_id": self.course_id,
            "title": self.title,
            "content": self.content,
            "order": self.order,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "duration_minutes": self.duration_minutes,
            "resources": self.resources or [],
            "prerequisites": self.prerequisites or [],
            "status": self.status,
            "media_urls": self.media_urls or []
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Lesson':
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)