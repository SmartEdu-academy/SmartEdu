from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

@dataclass
class Resource:
    id: str
    title: str
    type: str  # file, link, document, video, etc.
    url: str
    created_at: datetime
    updated_at: datetime
    created_by: str
    size_bytes: Optional[int] = None
    description: Optional[str] = None
    tags: List[str] = None
    mime_type: Optional[str] = None
    thumbnail_url: Optional[str] = None
    download_count: int = 0
    status: str = "active"  # active, archived, deleted
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "type": self.type,
            "url": self.url,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "created_by": self.created_by,
            "size_bytes": self.size_bytes,
            "description": self.description,
            "tags": self.tags or [],
            "mime_type": self.mime_type,
            "thumbnail_url": self.thumbnail_url,
            "download_count": self.download_count,
            "status": self.status
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Resource':
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)