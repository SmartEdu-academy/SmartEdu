from kivy.uix.behaviors import DragBehavior
from kivy.uix.gridlayout import GridLayout
from kivy.properties import BooleanProperty, ObjectProperty
from kivy.clock import Clock

class DragDropGrid(DragBehavior, GridLayout):
    """Grid layout with drag and drop support"""
    
    allow_drag = BooleanProperty(True)
    drop_target = ObjectProperty(None, allownone=True)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.drag_started = False
        self.original_pos = None
    
    def on_touch_down(self, touch):
        """Handle touch down event"""
        if self.collide_point(*touch.pos) and self.allow_drag:
            self.original_pos = self.pos
            return super().on_touch_down(touch)
        return False
    
    def on_touch_move(self, touch):
        """Handle drag movement"""
        if self.collide_point(*touch.pos) and self.allow_drag:
            if not self.drag_started:
                self.drag_started = True
                self.parent.remove_widget(self)
                self.parent.add_widget(self)
            return super().on_touch_move(touch)
        return False
    
    def on_touch_up(self, touch):
        """Handle drop event"""
        if self.drag_started:
            self.drag_started = False
            if self.drop_target and self.drop_target.collide_point(*touch.pos):
                self.handle_drop()
            else:
                self.pos = self.original_pos
        return super().on_touch_up(touch)
    
    def handle_drop(self):
        """Process the drop action"""
        if hasattr(self.parent, 'handle_item_drop'):
            self.parent.handle_item_drop(self)
        self.pos = self.original_pos