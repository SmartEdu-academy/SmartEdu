from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty, NumericProperty, BooleanProperty
from kivy.animation import Animation
from neu_widgets import NeuWidget

class NeuContentItem(ButtonBehavior, BoxLayout, NeuWidget):
    title = StringProperty("")
    content_type = StringProperty("")
    item_id = StringProperty("")
    order = NumericProperty(0)
    is_dark_mode = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.register_event_type('on_press_animation')
        self.register_event_type('on_release_animation')
        self.update_style()

    def update_style(self):
        if self.is_dark_mode:
            self.neu_style = {
                'background_color': (0.2, 0.2, 0.2, 1),
                'shadow_color': (0.1, 0.1, 0.1, 1),
                'highlight_color': (0.3, 0.3, 0.3, 1),
                'radius': 15,
                'offset': 5
            }
        else:
            self.neu_style = {
                'background_color': (0.92, 0.92, 0.92, 1),
                'shadow_color': (0.75, 0.75, 0.75, 1),
                'highlight_color': (1, 1, 1, 1),
                'radius': 15,
                'offset': 5
            }

    def on_press_animation(self, *args):
        anim = Animation(offset=2, duration=0.1)
        anim.start(self)

    def on_release_animation(self, *args):
        anim = Animation(offset=5, duration=0.1)
        anim.start(self)