from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import BooleanProperty, ListProperty
from kivymd.uix.card import MDCard

class MultiSelectItem(ButtonBehavior, MDCard):
    selected = BooleanProperty(False)
    
    def on_press(self):
        self.selected = not self.selected
        self.parent.update_selection(self)

class MultiSelectGrid(BoxLayout):
    selection = ListProperty([])
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = 10
        self.padding = 10

    def update_selection(self, item):
        if item.selected:
            if item not in self.selection:
                self.selection.append(item)
        else:
            if item in self.selection:
                self.selection.remove(item)

    def select_all(self):
        for child in self.children:
            if isinstance(child, MultiSelectItem):
                child.selected = True

    def deselect_all(self):
        for child in self.children:
            if isinstance(child, MultiSelectItem):
                child.selected = False

    def get_selected_ids(self):
        return [item.id for item in self.selection]