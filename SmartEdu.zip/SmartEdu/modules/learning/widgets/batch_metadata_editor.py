from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.dialog import MDDialog
from kivymd.uix.chip import MDChip
from kivymd.uix.textfield import MDTextField
from kivymd.toast import toast
from typing import List, Dict
from datetime import datetime

class BatchMetadataEditor(MDBoxLayout):
    def __init__(self, media_items: List[Dict], **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = "12dp"
        self.padding = "16dp"
        self.media_items = media_items
        self.setup_ui()
    
    def setup_ui(self):
        """Setup metadata editing UI"""
        # Common fields that can be batch edited
        self.common_fields = {
            'tags': MDTextField(
                hint_text="Tags (comma-separated)",
                helper_text="Apply to all selected items",
                multiline=False
            ),
            'category': MDTextField(
                hint_text="Category",
                helper_text="Apply to all selected items"
            ),
            'description': MDTextField(
                hint_text="Description",
                helper_text="Apply to all selected items",
                multiline=True
            ),
            'access_level': MDTextField(
                hint_text="Access Level",
                helper_text="public, private, or restricted"
            )
        }
        
        # Add fields to UI
        for field in self.common_fields.values():
            self.add_widget(field)
        
        # Add chips for bulk actions
        self.add_widget(MDChip(
            text="Clear All Tags",
            on_release=lambda x: self.clear_field('tags')
        ))
        
        self.add_widget(MDChip(
            text="Reset Access Levels",
            on_release=lambda x: self.set_field('access_level', 'public')
        ))
    
    def get_updates(self) -> List[Dict]:
        """Get updates for all selected items"""
        updates = []
        for item in self.media_items:
            item_update = {'media_id': item['id']}
            
            # Collect non-empty field values
            for field_name, field in self.common_fields.items():
                if field.text:
                    if field_name == 'tags':
                        item_update[field_name] = [
                            tag.strip() for tag in field.text.split(',')
                        ]
                    else:
                        item_update[field_name] = field.text
            
            if len(item_update) > 1:  # More than just media_id
                item_update['updated_at'] = datetime.utcnow().isoformat()
                updates.append(item_update)
        
        return updates
    
    def clear_field(self, field_name: str):
        """Clear a specific field for all items"""
        self.common_fields[field_name].text = ""
    
    def set_field(self, field_name: str, value: str):
        """Set a specific field value for all items"""
        self.common_fields[field_name].text = value