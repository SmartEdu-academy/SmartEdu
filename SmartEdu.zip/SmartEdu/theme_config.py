from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivymd.app import MDApp

class ThemeConfig:
    # Primary Colors (Teal-Green Gradient)
    PRIMARY_LIGHT = "#4DB6AC"  # Teal Light
    PRIMARY_DARK = "#009688"   # Teal Dark
    
    # Secondary Colors
    BACKGROUND = "#E0E5EC"     # Light Gray
    WHITE = "#FFFFFF"
    
    # Neumorphic Shadow Colors
    LIGHT_SHADOW = "#FFFFFF"
    DARK_SHADOW = "#A3B1C6"
    
    # Font Configurations
    FONTS = {
        'bn': {
            'regular': 'assets/fonts/NotoSansBengali-Regular.ttf',
            'medium': 'assets/fonts/NotoSansBengali-Medium.ttf',
            'bold': 'assets/fonts/NotoSansBengali-Bold.ttf'
        },
        'ar': {
            'regular': 'assets/fonts/Amiri-Regular.ttf',
            'bold': 'assets/fonts/Amiri-Bold.ttf'
        },
        'hi': {
            'regular': 'assets/fonts/NotoSansDevanagari-Regular.ttf',
            'medium': 'assets/fonts/NotoSansDevanagari-Medium.ttf',
            'bold': 'assets/fonts/NotoSansDevanagari-Bold.ttf'
        }
    }

    @staticmethod
    def init_theme():
        # Register Fonts
        for lang, fonts in ThemeConfig.FONTS.items():
            for style, path in fonts.items():
                LabelBase.register(f"{lang}_{style}", path)

        # Set Window Background
        Window.clearcolor = ThemeConfig.hex_to_float(ThemeConfig.BACKGROUND)

    @staticmethod
    def hex_to_float(hex_color):
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16)/255 for i in (0, 2, 4)) + (1,)