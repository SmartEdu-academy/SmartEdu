# Essential imports
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window
from kivymd.app import MDApp
from datetime import datetime

# Core imports
try:
    from modules.core.config import Config as AppConfig
    from modules.core.api_client import ApiClient
    from modules.core.firebase_manager import FirebaseManager
except ImportError as e:
    print(f"Core module import error: {e}")

# Auth imports
try:
    from modules.auth.auth_state import AuthState
    from modules.auth.auth_middleware import AuthMiddleware
    from modules.auth.screens.login_screen import LoginScreen
    from modules.auth.screens.register_screen import RegisterScreen
    from modules.auth.screens.password_reset_screen import PasswordResetScreen
except ImportError as e:
    print(f"Auth module import error: {e}")

class SplashScreen(Screen):
    """Initial loading screen"""
    pass

class SmartEduApp(MDApp):
    __version__ = '1.0.0'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "SmartEdu Academy"
        
        # Initialize core components with error handling
        try:
            self.config = AppConfig()
            self.api_client = ApiClient()
            self.firebase = FirebaseManager()
            self.auth_state = AuthState()
        except Exception as e:
            print(f"Initialization error: {e}")
        
        self.sm = None
        self.start_time = datetime.utcnow()

    def build(self):
        """Build and return the app's UI"""
        # Set theme (KivyMD 1.2.0 compatible)
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.accent_palette = "Amber"
        self.theme_cls.theme_style = "Light"
        
        # Create screen manager
        self.sm = ScreenManager()
        
        # Basic screens that should always be available
        basic_screens = [
            SplashScreen(name='splash')
        ]
        
        # Try to add basic screens
        for screen in basic_screens:
            try:
                self.sm.add_widget(screen)
            except Exception as e:
                print(f"Error adding {screen.__class__.__name__}: {e}")
        
        # Try to add auth screens if available
        try:
            self.sm.add_widget(LoginScreen(name='login'))
            self.sm.add_widget(RegisterScreen(name='register'))
            self.sm.add_widget(PasswordResetScreen(name='password_reset'))
        except Exception as e:
            print(f"Error adding auth screens: {e}")
        
        # Set initial screen
        self.sm.current = 'splash'
        
        return self.sm

    def on_start(self):
        """Called when the application starts"""
        print(f"SmartEdu v{self.__version__} started at {self.start_time}")
        try:
            # Initialize Firebase if available
            if hasattr(self, 'firebase'):
                self.firebase.initialize_app()
            
            # Check auth state and redirect if needed
            if hasattr(self, 'auth_state') and not self.auth_state.is_authenticated():
                self.sm.current = 'login'
        except Exception as e:
            print(f"Startup error: {e}")

    def on_stop(self):
        """Called when the application stops"""
        try:
            if hasattr(self, 'firebase'):
                self.firebase.close_connection()
            print(f"SmartEdu stopped at {datetime.utcnow()}")
        except Exception as e:
            print(f"Shutdown error: {e}")

    def switch_screen(self, screen_name):
        """Safely switch to another screen"""
        try:
            if screen_name in [screen.name for screen in self.sm.screens]:
                self.sm.current = screen_name
            else:
                print(f"Screen {screen_name} not found")
        except Exception as e:
            print(f"Error switching screens: {e}")

    def logout(self):
        """Handle user logout"""
        try:
            if hasattr(self, 'auth_state'):
                self.auth_state.clear()
            self.switch_screen('login')
        except Exception as e:
            print(f"Logout error: {e}")

if __name__ == '__main__':
    try:
        SmartEduApp().run()
    except Exception as e:
        print(f"Fatal error: {e}")