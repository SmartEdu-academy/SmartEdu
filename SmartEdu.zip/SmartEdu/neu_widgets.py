from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.metrics import dp

Builder.load_string('''
<NeuButton>:
    canvas.before:
        # Light shadow
        Color:
            rgba: app.theme_cls.light_shadow
        RoundedRectangle:
            pos: self.pos[0] + dp(3), self.pos[1] - dp(3)
            size: self.size
            radius: [dp(10)]
        # Dark shadow
        Color:
            rgba: app.theme_cls.dark_shadow
        RoundedRectangle:
            pos: self.pos[0] - dp(3), self.pos[1] + dp(3)
            size: self.size
            radius: [dp(10)]
        # Main surface
        Color:
            rgba: app.theme_cls.background_color
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]

<NeuTextInput>:
    canvas.before:
        # Inset effect
        Color:
            rgba: app.theme_cls.dark_shadow
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(10)]
        Color:
            rgba: app.theme_cls.light_shadow
        RoundedRectangle:
            pos: self.pos[0] + dp(2), self.pos[1] + dp(2)
            size: self.width - dp(4), self.height - dp(4)
            radius: [dp(8)]
''')

class NeuButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_color = (0, 0, 0, 0)
        self.background_normal = ''
        self.padding = dp(15)
        self.font_name = 'bn_medium'  # Default to Bengali

class NeuTextInput(TextInput):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_color = (0, 0, 0, 0)
        self.padding = [dp(15), dp(10)]
        self.font_name = 'bn_regular'  # Default to Bengali