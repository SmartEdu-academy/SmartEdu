import re
import hashlib
import random
import string
from datetime import datetime
import os

class Validators:
    @staticmethod
    def validate_email(email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def validate_password(password):
        """
        Validate password strength
        Must be at least 8 characters long
        Must contain at least one uppercase letter
        Must contain at least one lowercase letter
        Must contain at least one number
        Must contain at least one special character
        """
        if len(password) < 8:
            return False
        if not re.search(r'[A-Z]', password):
            return False
        if not re.search(r'[a-z]', password):
            return False
        if not re.search(r'[0-9]', password):
            return False
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return False
        return True

class Security:
    @staticmethod
    def generate_salt():
        """Generate a random salt"""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    
    @staticmethod
    def hash_password(password, salt):
        """Hash password with salt"""
        return hashlib.sha256(f"{password}{salt}".encode()).hexdigest()
    
    @staticmethod
    def generate_otp():
        """Generate a 6-digit OTP"""
        return ''.join(random.choices(string.digits, k=6))

class IDGenerator:
    @staticmethod
    def generate_user_id(user_type):
        """Generate unique user ID based on type"""
        timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
        random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
        return f"SMART_{user_type.upper()}_{timestamp}_{random_str}"

class FileHandler:
    @staticmethod
    def is_valid_file_size(file_size, max_size=10485760):  # 10MB default
        """Check if file size is within limit"""
        return file_size <= max_size
    
    @staticmethod
    def get_file_extension(filename):
        """Get file extension"""
        return os.path.splitext(filename)[1].lower()
    
    @staticmethod
    def generate_filename(original_filename):
        """Generate unique filename"""
        timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
        random_str = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        extension = FileHandler.get_file_extension(original_filename)
        return f"{timestamp}_{random_str}{extension}"