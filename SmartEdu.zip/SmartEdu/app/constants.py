# App Constants
APP_CONSTANTS = {
    'MAX_LOGIN_ATTEMPTS': 3,
    'SESSION_TIMEOUT': 3600,  # 1 hour in seconds
    'MAX_FILE_SIZE': 10485760,  # 10MB in bytes
    'SUPPORTED_LANGUAGES': ['en', 'bn'],
    'DEFAULT_LANGUAGE': 'en',
}

# User Types
USER_TYPES = {
    'STUDENT': 'student',
    'TEACHER': 'teacher',
    'PARENT': 'parent',
    'ADMIN': 'admin'
}

# Error Messages
ERROR_MESSAGES = {
    'AUTH': {
        'INVALID_CREDENTIALS': 'Invalid email or password',
        'ACCOUNT_LOCKED': 'Account has been locked. Please contact support',
        'EMAIL_EXISTS': 'Email already exists',
        'WEAK_PASSWORD': 'Password must be at least 8 characters long'
    },
    'NETWORK': {
        'NO_INTERNET': 'No internet connection',
        'SERVER_ERROR': 'Server is not responding',
        'TIMEOUT': 'Request timed out'
    }
}

# Success Messages
SUCCESS_MESSAGES = {
    'AUTH': {
        'LOGIN_SUCCESS': 'Successfully logged in',
        'REGISTER_SUCCESS': 'Registration successful',
        'PASSWORD_RESET': 'Password reset successful'
    }
}

# API Endpoints
API_ENDPOINTS = {
    'AUTH': {
        'LOGIN': '/auth/login',
        'REGISTER': '/auth/register',
        'RESET_PASSWORD': '/auth/reset-password',
        'VERIFY_EMAIL': '/auth/verify-email'
    },
    'USER': {
        'PROFILE': '/user/profile',
        'UPDATE': '/user/update',
        'DELETE': '/user/delete'
    }
}

# File Types
FILE_TYPES = {
    'IMAGE': ['jpg', 'jpeg', 'png', 'gif'],
    'DOCUMENT': ['pdf', 'doc', 'docx', 'txt'],
    'VIDEO': ['mp4', 'avi', 'mov'],
    'AUDIO': ['mp3', 'wav']
}

# Screen Names
SCREEN_NAMES = {
    'SPLASH': 'splash',
    'LOGIN': 'login',
    'REGISTER': 'register',
    'HOME': 'home',
    'PROFILE': 'profile',
    'SETTINGS': 'settings'
}