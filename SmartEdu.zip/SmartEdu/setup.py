from setuptools import setup, find_packages

setup(
    name="smartedu",
    version="1.0.0",
    author="SmartEdu-academy",
    author_email="contact@smartedu-academy.com",
    description="AI-powered Learning Management System",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/SmartEdu-academy/SmartEdu",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.9",
    install_requires=[
        line.strip()
        for line in open("requirements.txt")
        if line.strip() and not line.startswith("#")
    ],
    entry_points={
        "console_scripts": [
            "smartedu=app.main:main",
        ],
    },
)

# Created by: SmartEdu-academy
# Last updated: 2025-02-15 20:51:47